"""Catalogue Discover: a natural-language search front end for Koha."""
from __future__ import annotations

import asyncio
import time
import logging
import re
import secrets
from contextlib import asynccontextmanager
from datetime import date, timedelta
from pathlib import Path

from fastapi import Body, FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware

from . import ai, alerts, courses, dewey, exports, reports, reviews
from .semantic import Semantic
from .catalog import Catalog
from .config import settings
from .koha import SAMPLE, KohaError, make_backend
from .search import picks_for, coborrow_counts, explain, facets, one_line, parse, recommend, run_search, spellcheck

log = logging.getLogger("discover")
STATIC = Path(__file__).parent / "static"
state: dict = {}


async def refresh_coborrow():
    try:
        state["co"] = coborrow_counts(await state["koha"].coborrow_histories())
    except Exception as e:
        log.warning("Could not load borrowing history for recommendations: %s", e)
        state["co"] = {}


async def background_sync():
    from .sync import sync_koha
    try:
        await sync_koha(state["cat"])
        await refresh_coborrow()
        await refresh_meaning()
    except Exception as e:
        log.error("Catalogue sync failed: %s", e)
    finally:
        state["syncing"] = False


async def refresh_meaning():
    """Build or top up the meaning index in a worker thread; searches use word matching until it is ready."""
    sem: Semantic = state["sem"]
    if sem.building or not state["cat"].books:
        return
    try:
        await asyncio.to_thread(sem.build, state["cat"].books)
    except Exception as e:
        log.error("Meaning index could not be built (word search still works): %s", e)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logging.basicConfig(level=logging.INFO)
    cat = Catalog()
    courses.setup(cat)
    state.update(cat=cat, koha=make_backend(), co={}, syncing=False)
    if hasattr(state["koha"], "local_item_biblio"):
        state["koha"].local_item_biblio = cat.item_biblio
    if settings.demo:
        from .sync import load_demo
        load_demo(cat)
        if not cat.reviews(status=None):
            for bid, revs in SAMPLE["member_reviews"].items():
                for r in revs:
                    cat.add_review(int(bid), None, r["who"], r["r"], r["text"])
            for r in cat.reviews(status=None):
                cat.moderate(r["rid"], "approve")
        if not courses.semesters(cat):  # sample course readings (made-up courses over the sample books)
            courses.import_csv(cat, (Path(__file__).parent / "sample_courses.csv").read_bytes(), "Sample semester", "sample_courses.csv")
        from .sync import sync_circulation
        await sync_circulation(cat, (date.today().replace(day=1) - timedelta(days=730)).isoformat(), k=state["koha"])
    elif cat.count() == 0:
        log.info("The local catalogue is empty, so a first sync from Koha is starting in the background.")
        state["syncing"] = True
        asyncio.create_task(background_sync())
    await refresh_coborrow()
    sem = state["sem"] = cat.sem = Semantic()
    if settings.semantic != "off" and not sem.load():
        if settings.demo:
            await refresh_meaning()
        else:
            asyncio.create_task(refresh_meaning())
    yield


app = FastAPI(title="Catalogue Discover", lifespan=lifespan)
if not settings.secret_key:
    log.warning("SECRET_KEY is not set; sign-ins will reset whenever the app restarts.")
app.add_middleware(SessionMiddleware, secret_key=settings.secret_key or secrets.token_hex(32),
                   https_only=settings.secure_cookies, same_site="lax", max_age=60 * 60 * 8)


@app.exception_handler(KohaError)
async def koha_error(_, e: KohaError):
    return JSONResponse({"error": str(e)}, status_code=e.status)


# ---------------------------------------------------------------- helpers
def cat() -> Catalog:
    return state["cat"]


def card(b: dict) -> dict:
    keys = ("id", "t", "st", "a", "y", "f", "l", "aud", "fic", "call", "av", "tot", "isbn", "hue", "ser", "g", "cd", "r", "dd", "pub")
    return {k: b.get(k) for k in keys} | {"about": one_line(b)}


def get_book(bid: int) -> dict:
    b = cat().books.get(bid)
    if not b:
        raise HTTPException(404, "That title isn't in the catalogue.")
    return b


_fresh: dict[int, float] = {}
_bg: set = set()  # biblio id -> when its availability was last read live


async def live_availability(ids: list[int], wait: float = 0):
    """Refresh availability from Koha for these titles (at most every 5 minutes each).
    Search results don't wait (wait=0): they show the last known status and the refresh lands for the next view.
    A title page waits up to `wait` seconds, then shows the last known status."""
    if settings.demo:
        return
    now = time.time()
    todo = [i for i in ids if now - _fresh.get(i, 0) > 300]
    if not todo:
        return
    for i in todo:
        _fresh[i] = now

    async def one(i):
        try:
            cat().books[i].update(await state["koha"].availability(i))
        except Exception:
            _fresh.pop(i, None)

    task = asyncio.gather(*(one(i) for i in todo))
    _bg.add(task)
    task.add_done_callback(_bg.discard)
    if wait:
        try:
            await asyncio.wait_for(asyncio.shield(task), wait)
        except asyncio.TimeoutError:
            pass


def understand(q: str) -> tuple[dict, dict | None]:
    """Parse the query with Claude when configured, else rules. Returns (parsed, spelling note)."""
    c = cat()
    if settings.ai_enabled and settings.ai_query_parsing and q:
        key = "q:" + q.lower()
        got = c.cache_get(key)
        if got is None:
            got = ai.parse_query(q, date.today().year)
            if got is not None:
                c.cache_set(key, got, ttl=86400)
        if got:
            parsed = ai.ai_to_parsed(c, got)
            corr = got.get("corrected_query")
            note = {"kind": "auto", "corr": corr, "raw": q} if corr and corr.lower() != q.lower() else None
            return parsed, note
    parsed = parse(c, q)
    corr = spellcheck(c, q)
    if corr:
        p2 = parse(c, corr)
        words_only = lambda p: run_search(c, p, meaning=False)  # noqa: E731  spelling is judged on word matches
        if not words_only(parsed) and words_only(p2):
            if run_search(c, parsed):  # found by meaning as typed: keep it, and only offer the spelling fix
                return parsed, {"kind": "suggest", "corr": corr}
            return p2, {"kind": "auto", "corr": corr, "raw": q}
        if words_only(p2):
            return parsed, {"kind": "suggest", "corr": corr}
    return parsed, None


def require_user(request: Request) -> int:
    pid = request.session.get("pid")
    if not pid:
        raise HTTPException(401, "Please sign in first.")
    return pid


# ---------------------------------------------------------------- API
@app.get("/api/config")
async def config():
    return {"library": settings.library_name, "demo": settings.demo, "currency": settings.currency, "opac": settings.koha_opac_url,
            "ai": settings.ai_enabled, "ask": settings.ai_enabled, "courses": bool(courses.current_id(cat())), "records": cat().count(), "syncing": state.get("syncing", False), "alerts": alerts.smtp_ready(),
            "ddc_notice": dewey.NOTICE if dewey.OFFICIAL else ""}


LINK_FILTERS = ("who", "pub", "subj", "ddc")


async def search_core(q="", rm="", format="", aud="", lang="", avail=False, who="", pub="", subj="", ddc="", theme=""):
    """Run a search from the same parameters the page sends. Returns (results, filters, parsed, note, main query)."""
    q = (q or "").strip()[:300]
    parsed, note = await asyncio.to_thread(understand, q)
    f = dict(parsed["f"])
    for k in filter(None, (rm or "").split(",")):
        f.pop(k, None)
        if k == "ymin":
            f.pop("ymax", None)
    for k, v in (("format", format), ("aud", aud), ("lang", lang), ("who", who), ("pub", pub), ("subj", subj),
                 ("ddc", re.sub(r"\D", "", ddc or "")[:6])):
        if v:
            f[k] = v
    if avail:
        f["avail"] = True
    if str(theme).isdigit():
        f["theme"] = int(theme)
    main_q = {"f": f, "kw": parsed["kw"]}
    return run_search(cat(), main_q), f, parsed, note, main_q


@app.get("/api/search")
async def search(q: str = "", rm: str = "", format: str = "", aud: str = "", lang: str = "", avail: bool = False,
                 who: str = "", pub: str = "", subj: str = "", ddc: str = "", theme: str = "", course_code: str = ""):
    res, f, parsed, note, main_q = await search_core(q, rm, format, aud, lang, avail, who, pub, subj, ddc, theme)
    course = None
    if course_code or (q.strip() and not (who or pub or subj or ddc or theme)):
        ci = ({"code": courses.code_norm(course_code), "strong": True, "sem": courses.current_id(cat())} if course_code
              else courses.understand(cat(), q))
        if ci and ci.get("sem"):
            course = courses.answer(cat(), ci)
            if course["strong"] and course["items"]:
                seen, res = set(), []
                for e in course["items"]:
                    if e["in_catalogue"] and e["biblio_id"] not in seen:
                        seen.add(e["biblio_id"])
                        res.append({"id": e["biblio_id"], "score": 0,
                                    "why": [[f"{e['code'] or e['course']} {e['kind'].lower()}".strip(), "course readings"]]})
                main_q = {"f": {}, "kw": []}
    facet_keys = ("format", "aud", "lang", "avail") + LINK_FILTERS
    base = {"f": {k: v for k, v in f.items() if k not in facet_keys}, "kw": parsed["kw"]}
    for k, v in (("who", who), ("pub", pub), ("subj", subj), ("theme", f.get("theme"))):  # a followed link stays in the pool
        if v:
            base["f"][k] = v
    await live_availability([r["id"] for r in res[:10]])  # refreshes in the background
    pool = [r["id"] for r in res] if course and course["strong"] and course["items"] else [r["id"] for r in run_search(cat(), base)]
    books = cat().books
    onto = cat().onto
    if q.strip() or who or pub or subj or ddc or theme:
        try:
            th = state["sem"].theme(f["theme"]) if "theme" in f else None
            reports.log_search(cat(), q or " ".join(x for x in (who, pub, subj, ddc, th["name"] if th else "") if x), len(res),
                               {k: v for k, v in f.items() if k not in ("similar",)})
        except Exception as e:  # the log must never break a search
            log.warning("search log: %s", e)
    return {"q": q, "understood": {"f": f, "kw": parsed["kw"],
                                   "similar_title": books[f["similar"]]["t"] if f.get("similar") in books else None,
                                   "ddc_name": f"{onto.name(f['ddc'][:3])}" if f.get("ddc") else None,
                                   "theme_name": (state["sem"].theme(f["theme"]) or {}).get("name") if "theme" in f else None},
            "related": main_q.get("related", []), "choices": parsed.get("choices", []), "intents": parsed.get("intents", []),
            "semantic": main_q.get("semantic", False), "course": course_out(course),
            "note": note, "count": len(res), "facets": facets(cat(), pool),
            "results": [card(books[r["id"]]) | {"why": r["why"]} for r in res[:100]]}


def new_arrivals(n=18) -> list[dict]:
    """Newest copies by accession date (from Koha's items); newest record numbers when dates are missing."""
    books = list(cat().books.values())
    dated = [b for b in books if b.get("acq") and b.get("tot")]
    if len(dated) >= n:
        pick = sorted(dated, key=lambda b: (b["acq"], b["id"]), reverse=True)[:n]
    else:
        pick = sorted((b for b in books if b.get("tot", 1)), key=lambda b: b["id"], reverse=True)[:n]
    return [card(b) | {"note": ("Added " + b["acq"]) if b.get("acq") else ""} for b in pick]


@app.get("/api/home")
async def home():
    c = cat()
    return {"new": new_arrivals(), "classes": c.onto.children("", c.books), "themes": theme_list(24)}


def course_out(course: dict | None) -> dict | None:
    """Course readings card: the titles with their catalogue card (cover, live shelf status) when Koha has them."""
    if not course:
        return None
    books = cat().books
    for e in course.get("items", []):
        if e["in_catalogue"]:
            e["card"] = card(books[e["biblio_id"]])
    return course


def theme_list(n: int | None = None) -> list[dict]:
    """Themes found in the collection, largest first (empty until the meaning index is ready)."""
    sem = state.get("sem")
    if not sem or not sem.ready:
        return []
    return [{"id": t["id"], "name": t["name"], "size": t["size"], "words": t["words"][:4]} for t in sem.themes[:n]]


@app.get("/api/themes")
async def themes():
    return {"themes": theme_list(), "status": state["sem"].status()}


@app.get("/api/browse")
async def browse(ddc: str = ""):
    """One level of the subject map: classes, divisions or sections, with book counts."""
    code = re.sub(r"\D", "", ddc)[:3]
    c = cat()
    return {"code": code, "path": c.onto.path(code) if code else [], "children": c.onto.children(code, c.books) if len(code) < 3 else []}


@app.get("/api/records/{bid}")
async def record(bid: int, request: Request):
    b = get_book(bid)
    try:
        reports.log_view(cat(), bid)
    except Exception as e:
        log.warning("view log: %s", e)
    await live_availability([bid], wait=settings.live_wait)
    recs = recommend(cat(), b, state["co"])
    books = cat().books
    for r in recs:
        r["items"] = [card(books[i]) | {"note": note} for i, note in r["items"]]
    pid = request.session.get("pid")
    member = [{"rid": r["rid"], "who": r["who"], "r": r["rating"], "text": r["text"], "when": r["created"][:10],
               "pending": r["status"] != "approved"} for r in cat().reviews(bid, "approved", pid)]
    return card(b) | {"pg": b.get("pg"), "loc": b.get("loc", ""), "subj": b.get("subj", []), "n": b.get("n", {}),
                      "au": b.get("au", []), "cite": exports.apa(b), "opac": exports.opac_link(b), "pub": b.get("pub", ""), "dd": b.get("dd", ""), "ddc_path": cat().onto.path(b.get("dd", "")),
                      "explain": explain(b), "explain_ai": bool(b.get("ai_explain")), "recs": recs, "theme": book_theme(bid),
                      "sources": await reviews.sources(cat(), b), "member_reviews": member}


def book_theme(bid: int) -> dict | None:
    sem = state.get("sem")
    t = sem.theme(sem.theme_of.get(bid, -1)) if sem and sem.ready else None
    return {"id": t["id"], "name": t["name"]} if t else None


@app.post("/api/login")
async def login(request: Request, body: dict = Body(...)):
    ident, pin = str(body.get("card", "")).strip(), str(body.get("pin", ""))
    if not ident or not pin:
        raise HTTPException(400, "Enter your library card number and PIN.")
    pid = await state["koha"].authenticate(ident, pin)
    if not pid:
        raise HTTPException(401, "That card number and PIN don't match. Check both and try again.")
    request.session.clear()
    request.session["pid"] = pid
    patron = await state["koha"].patron(pid)
    request.session["patron"] = patron
    return patron


@app.post("/api/logout")
async def logout(request: Request):
    request.session.clear()
    return {"ok": True}


def _with_book(rows, key="biblio_id"):
    books = cat().books
    return [r | {"book": card(books[r[key]]) if r.get(key) in books else None} for r in rows]


@app.get("/api/me/who")
async def who(request: Request):
    """Who is signed in, without asking Koha (used when a page opens)."""
    pid = require_user(request)
    return request.session.get("patron") or await state["koha"].patron(pid)


@app.get("/api/me")
async def me(request: Request):
    """Loans, holds and fines, read from Koha at the same time. Reading history is separate (/api/me/history)."""
    pid = require_user(request)
    k = state["koha"]
    patron = request.session.get("patron")
    loans, holds, fines, p = await asyncio.gather(k.loans(pid), k.holds(pid), k.fines(pid),
                                                  asyncio.sleep(0, patron) if patron else k.patron(pid),
                                                  return_exceptions=True)
    if isinstance(loans, Exception):
        raise loans
    problems = []
    if isinstance(holds, Exception):
        log.warning("Holds unavailable for the account page: %s", holds)
        holds, _ = [], problems.append("holds")
    if isinstance(fines, Exception):  # usually the API account lacks the "updatecharges" permission
        log.warning("Fines unavailable for the account page: %s", fines)
        fines, _ = [], problems.append("fines")
    if isinstance(p, Exception):
        p = {"name": "", "card": "", "branch": ""}
    return {"patron": p, "loans": _with_book(loans), "holds": _with_book(holds), "fines": fines, "unavailable": problems}


@app.get("/api/me/picks")
async def my_picks(request: Request):
    """Suggestions from the signed-in reader's own borrowing (kept for 12 hours, never shown to anyone else)."""
    pid = require_user(request)
    key = f"picks:{pid}"
    ids = cat().cache_get(key)
    if ids is None:
        k = state["koha"]
        hist, loans = await asyncio.gather(k.history(pid), k.loans(pid))
        read = [h["biblio_id"] for h in loans + hist if h.get("biblio_id")]
        ids = picks_for(cat(), read)
        cat().cache_set(key, ids, ttl=12 * 3600)
    books = cat().books
    return [card(books[i]) | {"note": why} for i, why in ids if i in books]


@app.get("/api/me/history")
async def my_history(request: Request):
    return _with_book(await state["koha"].history(require_user(request)))


@app.post("/api/me/renew/{checkout_id}")
async def renew(checkout_id: int, request: Request):
    return {"due": await state["koha"].renew(require_user(request), checkout_id)}


@app.post("/api/me/holds")
async def place_hold(request: Request, body: dict = Body(...)):
    pid = require_user(request)
    bid = int(body.get("biblio_id", 0))
    get_book(bid)
    await state["koha"].place_hold(pid, bid, body.get("pickup"))
    return {"ok": True}


@app.delete("/api/me/holds/{hold_id}")
async def cancel_hold(hold_id: int, request: Request):
    await state["koha"].cancel_hold(require_user(request), hold_id)
    return {"ok": True}


@app.post("/api/records/{bid}/reviews")
async def add_review(bid: int, request: Request, body: dict = Body(...)):
    pid = require_user(request)
    get_book(bid)
    text = str(body.get("text", "")).strip()[:2000]
    rating = int(body.get("rating", 0))
    if not text or not 1 <= rating <= 5:
        raise HTTPException(400, "Add a rating from 1 to 5 and a few words.")
    p = await state["koha"].patron(pid)
    parts = (p.get("name") or "Member").split()
    who = parts[0] + (f" {parts[-1][0]}." if len(parts) > 1 else "")
    cat().add_review(bid, pid, who, rating, text)
    return {"ok": True}


@app.post("/api/photo")
async def photo(file: UploadFile = File(...)):
    data = await file.read()
    if len(data) > 8 * 1024 * 1024:
        raise HTTPException(413, "That photo is over 8 MB. Try a smaller one.")
    media = file.content_type if file.content_type in ("image/jpeg", "image/png", "image/gif", "image/webp") else "image/jpeg"
    isbn = None
    try:  # barcode first: fast, free, works offline
        from io import BytesIO

        from PIL import Image
        from pyzbar.pyzbar import decode
        for code in decode(Image.open(BytesIO(data))):
            v = code.data.decode(errors="ignore")
            if re.fullmatch(r"97[89]\d{10}", v):
                isbn = v
                break
    except Exception:
        pass
    read = None
    if not isbn and settings.ai_enabled:
        read = await asyncio.to_thread(ai.read_photo, data, media)
        if read and read.get("isbn"):
            isbn = re.sub(r"[^0-9xX]", "", read["isbn"]).lower()
    books = cat().books
    if isbn:
        res = run_search(cat(), {"f": {"isbn": isbn}, "kw": []})
        if res:
            return {"isbn": isbn, "match": books[res[0]["id"]]["id"]}
    if read and (read.get("title") or read.get("author")):
        q = " ".join(x for x in [read.get("title"), read.get("author")] if x)
        parsed, _ = parse(cat(), q), None
        res = run_search(cat(), parsed)
        if res:
            return {"isbn": isbn, "read": read, "match": res[0]["id"]}
        return {"isbn": isbn, "read": read, "message": f"We read “{q}” but it isn't in our catalogue. You could ask the library to buy it."}
    if isbn:
        return {"isbn": isbn, "message": f"ISBN {isbn} isn't in our catalogue. You could ask the library to buy it."}
    msg = ("We couldn't read a barcode or title in that photo. Try a closer, sharper shot, or type the ISBN."
           if settings.ai_enabled else "We couldn't find a barcode in that photo. Try a closer shot of the barcode, or type the ISBN.")
    return {"message": msg}


# ---------------------------------------------------------------- staff
def require_admin(token: str | None):
    if not settings.admin_token or not token or not secrets.compare_digest(token, settings.admin_token):
        raise HTTPException(401, "Staff token required. Set ADMIN_TOKEN in the app's settings.")


@app.get("/api/admin/reviews")
async def admin_reviews(x_admin_token: str | None = Header(None)):
    require_admin(x_admin_token)
    books = cat().books
    return [r | {"title": books.get(r["biblio_id"], {}).get("t")} for r in cat().reviews(status="pending")]


@app.post("/api/admin/reviews/{rid}/{action}")
async def admin_moderate(rid: int, action: str, x_admin_token: str | None = Header(None)):
    require_admin(x_admin_token)
    if action not in ("approve", "delete"):
        raise HTTPException(400, "Action must be approve or delete.")
    cat().moderate(rid, action)
    return {"ok": True}


@app.post("/api/admin/sync")
async def admin_sync(x_admin_token: str | None = Header(None)):
    require_admin(x_admin_token)
    if settings.demo:
        return {"ok": True, "message": "Demo mode uses the sample catalogue, so there is nothing to sync."}
    if state.get("syncing"):
        return {"ok": True, "message": "A sync is already running."}
    state["syncing"] = True
    asyncio.create_task(background_sync())
    return {"ok": True, "message": "Sync started. Large catalogues can take a while."}


@app.get("/healthz")
async def health():
    return {"ok": True, "records": cat().count(), "meaning": state["sem"].status()}


# ---------------------------------------------------------------- v3: export, reading lists, saved searches, reports
import json as _json  # noqa: E402

FILE_TYPES = {"csv": ("text/csv; charset=utf-8", "csv"),
              "xlsx": ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "xlsx"),
              "ris": ("application/x-research-info-systems", "ris"), "bib": ("application/x-bibtex", "bib")}


def _file(data: bytes, fmt: str, name: str) -> Response:
    ctype, ext = FILE_TYPES[fmt]
    safe = re.sub(r"[^A-Za-z0-9._-]+", "-", name).strip("-")[:60] or "export"
    return Response(data, media_type=ctype, headers={"Content-Disposition": f'attachment; filename="{safe}.{ext}"'})


def _books_file(books: list[dict], fmt: str, name: str) -> Response:
    if fmt not in FILE_TYPES:
        raise HTTPException(400, "Choose csv, xlsx, ris or bib.")
    if fmt == "ris":
        return _file(exports.to_ris(books), fmt, name)
    if fmt == "bib":
        return _file(exports.to_bibtex(books), fmt, name)
    rows = [exports.book_row(b) for b in books]
    data = exports.to_csv(exports.ROW_COLUMNS, rows) if fmt == "csv" else exports.to_xlsx(exports.ROW_COLUMNS, rows, name)
    return _file(data, fmt, name)


@app.get("/api/export")
async def export(fmt: str = "csv", ids: str = "", q: str = "", rm: str = "", format: str = "", aud: str = "", lang: str = "",
                 avail: bool = False, who: str = "", pub: str = "", subj: str = "", ddc: str = "", theme: str = ""):
    """Download the current results (first 1,000) or the given titles as CSV, Excel, RIS or BibTeX."""
    books = cat().books
    if ids:
        chosen = [books[int(i)] for i in ids.split(",")[:1000] if i.isdigit() and int(i) in books]
        name = "titles"
    else:
        res, *_ = await search_core(q, rm, format, aud, lang, avail, who, pub, subj, ddc, theme)
        chosen = [books[r["id"]] for r in res[:1000]]
        name = "search-" + (q or who or pub or subj or ddc or "results")
    return _books_file(chosen, fmt, name)


# reading lists: anyone can make one; the creator's browser keeps a private edit key; the link shows it read-only
def _list_out(row, books, with_key=False):
    lid, key, name, note, items, created, updated = row
    ids = [i for i in _json.loads(items or "[]") if i in books]
    out = {"id": lid, "name": name, "note": note or "", "items": [card(books[i]) for i in ids],
           "updated": date.fromtimestamp(updated).isoformat()}
    return out | ({"key": key} if with_key else {})


def _get_list(lid: str):
    rows = cat().run("SELECT id, edit_key, name, note, items, created, updated FROM lists WHERE id=?", (lid,))
    if not rows:
        raise HTTPException(404, "That reading list doesn't exist (it may have been deleted).")
    return rows[0]


@app.post("/api/lists")
async def new_list(body: dict = Body(...)):
    name = str(body.get("name") or "My reading list").strip()[:120]
    lid, key, now = secrets.token_urlsafe(6), secrets.token_urlsafe(16), time.time()
    first = [int(body["biblio_id"])] if str(body.get("biblio_id", "")).isdigit() else []
    cat().run("INSERT INTO lists VALUES(?,?,?,?,?,?,?)", (lid, key, name, "", _json.dumps(first), now, now), commit=True)
    return _list_out(_get_list(lid), cat().books, with_key=True)


@app.get("/api/lists/{lid}")
async def show_list(lid: str):
    return _list_out(_get_list(lid), cat().books)


@app.post("/api/lists/{lid}")
async def edit_list(lid: str, body: dict = Body(...)):
    row = _get_list(lid)
    if not secrets.compare_digest(str(body.get("key", "")), row[1]):
        raise HTTPException(403, "Only the person who made this list can change it.")
    if body.get("delete"):
        cat().run("DELETE FROM lists WHERE id=?", (lid,), commit=True)
        return {"ok": True}
    items = _json.loads(row[4] or "[]")
    if str(body.get("add", "")).isdigit() and int(body["add"]) not in items:
        items.append(int(body["add"]))
    if str(body.get("remove", "")).isdigit():
        items = [i for i in items if i != int(body["remove"])]
    name = str(body.get("name") or row[2]).strip()[:120]
    note = str(body.get("note") if body.get("note") is not None else (row[3] or ""))[:1000]
    cat().run("UPDATE lists SET name=?, note=?, items=?, updated=? WHERE id=?", (name, note, _json.dumps(items[:500]), time.time(), lid), commit=True)
    return _list_out(_get_list(lid), cat().books, with_key=True)


@app.get("/api/lists/{lid}/export")
async def export_list(lid: str, fmt: str = "csv"):
    row = _get_list(lid)
    books = cat().books
    return _books_file([books[i] for i in _json.loads(row[4] or "[]") if i in books], fmt, row[2])


# saved searches: for signed-in readers; "new" means added to the catalogue after the search was saved
SEARCH_KEYS = alerts.SEARCH_KEYS


async def _saved_new(row) -> tuple[list[int], int]:
    base_id, base_date = row[5], row[6]
    ids = await asyncio.to_thread(alerts.run_params, cat(), _json.loads(row[4]))
    books = cat().books
    return [i for i in ids if alerts.is_new(books[i], base_id, base_date)], len(ids)


@app.get("/api/me/saved")
async def my_saved(request: Request):
    pid = require_user(request)
    rows = cat().run("SELECT * FROM saved_searches WHERE pid=? ORDER BY created DESC", (pid,))
    out = []
    for row in rows:
        new, total = await _saved_new(row)
        out.append({"id": row[0], "name": row[3], "params": _json.loads(row[4]), "email": bool(row[2]),
                    "total": total, "new": len(new)})
    return out


@app.post("/api/me/saved")
async def save_search(request: Request, body: dict = Body(...)):
    pid = require_user(request)
    params = {k: v for k, v in (body.get("params") or {}).items() if k in SEARCH_KEYS and v not in ("", None, False)}
    if not params:
        raise HTTPException(400, "Search for something first, then save it.")
    name = str(body.get("name") or params.get("q") or "My search").strip()[:120]
    email = (request.session.get("patron") or {}).get("email", "") if body.get("alert") else ""
    if body.get("alert") and not email:
        raise HTTPException(400, "Your library account has no email address, so we can't send alerts. Ask the library to add one.")
    bid, bdate = alerts.baseline(cat())
    cat().run("INSERT INTO saved_searches(pid,email,name,params,base_id,base_date,alerted_id,alerted_date,created) VALUES(?,?,?,?,?,?,?,?,?)",
              (pid, email, name, _json.dumps(params), bid, bdate, bid, bdate, time.time()), commit=True)
    return {"ok": True, "email": bool(email), "alerts_on": alerts.smtp_ready()}


@app.post("/api/me/saved/{sid}/seen")
async def saved_seen(sid: int, request: Request):
    """Opening a saved search marks its new titles as seen."""
    pid = require_user(request)
    bid, bdate = alerts.baseline(cat())
    cat().run("UPDATE saved_searches SET base_id=?, base_date=? WHERE id=? AND pid=?", (bid, bdate, sid, pid), commit=True)
    return {"ok": True}


@app.delete("/api/me/saved/{sid}")
async def saved_delete(sid: int, request: Request):
    pid = require_user(request)
    cat().run("DELETE FROM saved_searches WHERE id=? AND pid=?", (sid, pid), commit=True)
    return {"ok": True}


# staff reports
def _admin(token):
    require_admin(token)


@app.get("/api/admin/reports")
async def report_list(x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    saved = [{"id": r[0], "name": r[1], "kind": r[2], "params": _json.loads(r[3]), "created": date.fromtimestamp(r[4]).isoformat()}
             for r in cat().run("SELECT id, name, kind, params, created FROM saved_reports ORDER BY created DESC")]
    n_search = cat().run("SELECT COUNT(*), MIN(ts) FROM searchlog")[0]
    n_circ = cat().run("SELECT COUNT(*) FROM circ")[0][0]
    return {"reports": [{"kind": k, "title": reports.REPORTS[k], "group": g} for g, ks in reports.GROUPS.items() for k in ks],
            "saved": saved, "logged_searches": n_search[0],
            "logging_since": date.fromtimestamp(n_search[1]).isoformat() if n_search[1] else None,
            "loans": n_circ, "loans_copied": cat().cache_get("circ_synced")}


def _period(days, start, end):
    try:
        return reports.period(days, start or None, end or None)
    except ValueError:
        raise HTTPException(400, "Dates must look like 2025-07-31.")


@app.get("/api/admin/reports/{kind}")
async def report(kind: str, days: int = 30, start: str = "", end: str = "", fmt: str = "json",
                 x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    if kind not in reports.REPORTS:
        raise HTTPException(404, "No such report.")
    P = _period(max(1, min(days, 3650)), start, end)
    extra = None
    k = state["koha"]
    if kind == "borrowers":
        from .circulation import top_borrower_ids
        ids = await asyncio.to_thread(top_borrower_ids, cat(), P)
        got = await asyncio.gather(*(k.patron_card(i) for i in ids), return_exceptions=True)
        extra = {"names": {i: g for i, g in zip(ids, got) if isinstance(g, dict)}}
    elif kind == "fines":
        try:
            extra = {"rows": await k.fines_by_year()}
        except KohaError as e:
            raise HTTPException(502, str(e))
    r = await asyncio.to_thread(reports.build, cat(), kind, P, extra)
    if fmt == "json":
        return r
    name = f"{r['title']} - {P['label']}"
    if fmt == "csv":
        return _file(exports.to_csv(r["columns"], r["rows"]), "csv", name)
    if fmt == "xlsx":
        return _file(exports.to_xlsx(r["columns"], r["rows"], r["title"], f"{r['about']} Period: {P['label']}. Made {r['made']}."), "xlsx", name)
    raise HTTPException(400, "Choose json, csv or xlsx.")


@app.post("/api/admin/saved-reports")
async def save_report(body: dict = Body(...), x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    kind = body.get("kind")
    if kind not in reports.REPORTS:
        raise HTTPException(400, "No such report.")
    params = {"start": str(body["start"]), "end": str(body.get("end") or "")} if body.get("start") else \
        {"days": int(body.get("days") or 30)}
    rid = secrets.token_urlsafe(6)
    cat().run("INSERT INTO saved_reports VALUES(?,?,?,?,?)",
              (rid, str(body.get("name") or reports.REPORTS[kind])[:120], kind, _json.dumps(params), time.time()), commit=True)
    return {"id": rid}


@app.delete("/api/admin/saved-reports/{rid}")
async def delete_report(rid: str, x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    cat().run("DELETE FROM saved_reports WHERE id=?", (rid,), commit=True)
    return {"ok": True}


@app.get("/admin")
async def admin_page():
    return FileResponse(STATIC / "admin.html")


# ---------------------------------------------------------------- v5: course readings
@app.get("/api/courses")
async def course_page(sem: int | None = None, code: str = "", faculty: str = "", course: str = "", q: str = ""):
    """The course readings page: the three menus (faculty, course, code) and the matching titles."""
    c = cat()
    sid = sem or courses.current_id(c)
    items = courses.group(c, courses.select(c, sid, code, faculty, course, q)) if (code or faculty or course or q) else []
    out = course_out({"items": items})
    await live_availability([e["biblio_id"] for e in items if e["in_catalogue"]][:30])
    return {"semesters": [{"id": x["id"], "label": x["label"], "current": x["current"]} for x in courses.semesters(c)],
            "sem": sid, "label": courses.label(c, sid), "pickers": courses.pickers(c, sid), "items": out["items"],
            "policies": courses.POLICY}


@app.get("/api/courses/export")
async def course_export(sem: int | None = None, code: str = "", faculty: str = "", course: str = "", q: str = "", fmt: str = "csv"):
    c = cat()
    sid = sem or courses.current_id(c)
    items = courses.group(c, courses.select(c, sid, code, faculty, course, q))
    rows = courses.export_rows(items)
    name = "course-readings-" + (code or faculty or course or q or courses.label(c, sid) or "all")
    if fmt == "xlsx":
        return _file(exports.to_xlsx(courses.EXPORT_COLUMNS, rows, "Course readings"), "xlsx", name)
    return _file(exports.to_csv(courses.EXPORT_COLUMNS, rows), "csv", name)


@app.get("/api/admin/courses")
async def admin_courses(x_admin_token: str | None = Header(None)):
    require_admin(x_admin_token)
    c = cat()
    sid = courses.current_id(c)
    return {"semesters": courses.semesters(c), "current": courses.summary(c, sid) if sid else None,
            "ebook_links": settings.course_ebook_links}


@app.post("/api/admin/courses")
async def admin_courses_upload(file: UploadFile = File(...), label: str = Form(""), x_admin_token: str | None = Header(None)):
    require_admin(x_admin_token)
    data = await file.read()
    if len(data) > 20_000_000:
        raise HTTPException(413, "The file is larger than 20 MB.")
    try:
        return courses.import_csv(cat(), data, label, file.filename or "")
    except ValueError as e:
        raise HTTPException(400, str(e))


@app.post("/api/admin/courses/{sid}/current")
async def admin_courses_current(sid: int, x_admin_token: str | None = Header(None)):
    require_admin(x_admin_token)
    courses.set_current(cat(), sid)
    return {"ok": True}


@app.delete("/api/admin/courses/{sid}")
async def admin_courses_delete(sid: int, x_admin_token: str | None = Header(None)):
    require_admin(x_admin_token)
    courses.delete(cat(), sid)
    return {"ok": True}


# ---------------------------------------------------------------- v5: Ask the librarian (Claude, optional)
_ask_log: dict[str, list[float]] = {}


def _ask_allowed(key: str) -> bool:
    now = time.time()
    hits = [t for t in _ask_log.get(key, []) if now - t < 3600]
    if len(hits) >= settings.ask_per_hour:
        _ask_log[key] = hits
        return False
    _ask_log[key] = hits + [now]
    if len(_ask_log) > 5000:
        _ask_log.clear()
    return True


def _compact(b: dict, why: str = "") -> dict:
    n = b.get("n", {})
    out = {"id": b["id"], "title": b["t"] + (": " + b["st"] if b.get("st") else ""), "author": b["a"], "year": b.get("y"),
           "subjects": b.get("subj", [])[:5], "about": (n.get("520") or n.get("505") or "")[:300], "format": b["f"],
           "av": b.get("av", 1), "copies": b.get("tot", 1), "call": b.get("call", "")}
    if why:
        out["note"] = why
    return out


@app.post("/api/ask")
async def ask_librarian(request: Request, body: dict = Body(...)):
    """Chat: find candidates with the app's own search, then let Claude choose and explain from those titles only."""
    if not settings.ai_enabled:
        raise HTTPException(404, "Ask the librarian needs an Anthropic API key (ANTHROPIC_API_KEY in .env).")
    msgs = [{"role": m.get("role"), "content": str(m.get("content", ""))[:600]} for m in (body.get("messages") or [])
            if m.get("role") in ("user", "assistant") and str(m.get("content", "")).strip()][-8:]
    if not msgs or msgs[-1]["role"] != "user":
        raise HTTPException(400, "Please type a question.")
    while msgs[0]["role"] != "user":
        msgs.pop(0)
    key = request.client.host if request.client else "?"
    if not _ask_allowed(key):
        raise HTTPException(429, "You've asked a lot of questions this hour. Please try again a little later, or use the search box.")
    q = msgs[-1]["content"]
    users = [m["content"] for m in msgs if m["role"] == "user"]
    rq = (users[-2] + " " + q) if len(users) > 1 and len(re.findall(r"\w+", q)) < 6 else q
    books = cat().books
    cands: list[dict] = []
    ci = courses.understand(cat(), rq)
    if ci and ci.get("strong"):
        for e in courses.answer(cat(), ci)["items"]:
            if e["in_catalogue"] and all(c["id"] != e["biblio_id"] for c in cands):
                pol = ", ".join(f"{n} {p}" for p, n in e["copies"].items())
                cands.append(_compact(books[e["biblio_id"]], f"{e['code']} {e['course']} {e['kind']} ({pol})"))
    res, *_ = await search_core(rq)
    for r in res:
        if len(cands) >= settings.ask_candidates:
            break
        if all(c["id"] != r["id"] for c in cands):
            cands.append(_compact(books[r["id"]]))
    out = await asyncio.to_thread(ai.ask, msgs, cands, settings.library_name)
    try:
        reports.log_search(cat(), q, len(cands), {"ask": True})
    except Exception as e:
        log.warning("search log: %s", e)
    if out is None:
        raise HTTPException(503, "The librarian chat is unavailable just now. Please use the search box.")
    valid = {c["id"] for c in cands}
    picks = [card(books[p["id"]]) | {"why_ai": p["why"]} for p in out.get("picks", []) if p.get("id") in valid][:8]
    return {"reply": out.get("reply", ""), "picks": picks, "try_search": out.get("try_search"), "searched": rq}


app.mount("/", StaticFiles(directory=STATIC, html=True), name="static")

