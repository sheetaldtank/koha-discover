# Installing Catalogue Discover version 5 (port 8092)

Versions 1 to 4 are not touched. Run these in PowerShell on your PC.

1. Extract `koha-discover-v5.zip` into `C:\wamp64\www`. You get `C:\wamp64\www\koha-discover-v5`.
2. Stop version 4 (Ctrl+C in its window). Copy the `.env` file and the `data` folder from `koha-discover-v4` into `koha-discover-v5`, then start version 4 again if you want both running.
3. Open `koha-discover-v5\.env` in Notepad. Change `PUBLIC_URL` to `http://10.0.114.118:8092`, and change `AI_QUERY_PARSING` to `false` (add the line if it isn't there). The Ask the librarian section below explains why.
4. Install the two new libraries, NumPy and scikit-learn:

   ```powershell
   cd C:\wamp64\www\koha-discover-v5
   $env:PYTHONUTF8=1
   ..\koha-discover\.venv\Scripts\python -m pip install -r requirements.txt
   ```

5. **Recommended: install the meaning model.** This downloads PyTorch, about 200 MB.

   ```powershell
   ..\koha-discover\.venv\Scripts\python -m pip install -r requirements-semantic.txt
   ```

   If this step fails, carry on without it. The app then uses a simpler method (latent semantic analysis) and everything else still works.

6. Build the meaning index and themes once. With the model, the first run downloads it (about 470 MB) and then reads all 42,000 titles, which takes 15 to 40 minutes. Without the model it takes under a minute.

   ```powershell
   ..\koha-discover\.venv\Scripts\python -m app.semantic
   ```

   It ends with a line like `Meaning search ready (model): 42125 titles, 145 themes`. After this, the nightly sync updates only new or changed titles.

7. Start it:

   ```powershell
   ..\koha-discover\.venv\Scripts\python -m uvicorn app.main:app --host 0.0.0.0 --port 8092
   ```

   Readers: http://10.0.114.118:8092  ·  Staff: http://10.0.114.118:8092/admin

## Course readings

On the staff page, open **Course readings**, type the semester name (for example `Semester I (July–Nov, 2026)`), choose the CSV, and click **Upload**. It becomes the current semester. Earlier uploads are kept and can be made current again.

The page then lists any biblio numbers that aren't in the app's copy of the catalogue. Those titles still show, without shelf status. Titles catalogued since the last sync link up after the next sync.

E-book links in the CSV are hidden. Set `COURSE_EBOOK_LINKS=true` in `.env` only once every link points to a licensed copy.

## Ask the librarian (needs an Anthropic API key)

1. Someone with the library's budget approval signs in at https://console.anthropic.com, adds billing, and sets a **monthly spend limit** (Settings › Limits). ₹5,000 a month is a sensible start. Each question costs about ₹3 to ₹6, so ₹5,000 covers roughly 1,000 questions a month. When the limit is reached, the chat says it is unavailable and search keeps working.
2. **API keys › Create key**, then copy the key.
3. Paste it into `.env` on the app's computer as `ANTHROPIC_API_KEY=...`. Don't send it by email or chat.
4. Restart the app. **Ask the librarian** then appears at the top of the page.

Each computer can ask 30 questions an hour (`ASK_PER_HOUR`). Only the question and the catalogue records of the titles found are sent to Anthropic, never the reader's name or card number.

`AI_QUERY_PARSING=false` (already set in `deploy/iitgn.env`) keeps Claude out of ordinary searches, so you pay only for chat questions. Set it to `true` if you also want Claude to read every search box query. That handles very casual or misspelt questions better, but costs about ₹1 per new search.

## If the model can't be downloaded

If the PC or server can't reach huggingface.co, download the model folder on another computer and copy it across. On that computer, run:

```
python -c "from sentence_transformers import SentenceTransformer as S; S('sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2').save('mini-model')"
```

Then copy the `mini-model` folder into `koha-discover-v5`, set `EMBED_MODEL=mini-model` in `.env`, and run step 6 again.
