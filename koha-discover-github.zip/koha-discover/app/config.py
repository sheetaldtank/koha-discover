"""Settings, read from environment variables (see .env.example)."""
import os
from dataclasses import dataclass, field
from pathlib import Path


def _bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    return default if v is None else v.strip().lower() in {"1", "true", "yes", "on"}


def _load_env_file():
    """Read a .env file next to the app (KEY=value lines) when running without Docker. Real environment variables win."""
    path = Path(os.getenv("DISCOVER_ENV_FILE", Path(__file__).resolve().parent.parent / ".env"))
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        os.environ.setdefault(key.strip(), value)


_load_env_file()


@dataclass
class Settings:
    # "demo" uses the built-in sample catalogue; "koha" talks to a real Koha server.
    mode: str = field(default_factory=lambda: os.getenv("DISCOVER_MODE", "demo").lower())

    # Koha connection
    koha_url: str = field(default_factory=lambda: os.getenv("KOHA_URL", "").rstrip("/"))
    koha_opac_url: str = field(default_factory=lambda: os.getenv("KOHA_OPAC_URL", "").rstrip("/"))
    # "oauth" (API key from Koha) or "basic" (staff username and password; needs RESTBasicAuth on)
    koha_auth: str = field(default_factory=lambda: os.getenv("KOHA_AUTH", "oauth").lower())
    koha_api_user: str = field(default_factory=lambda: os.getenv("KOHA_API_USER", ""))
    koha_api_password: str = field(default_factory=lambda: os.getenv("KOHA_API_PASSWORD", ""))
    koha_client_id: str = field(default_factory=lambda: os.getenv("KOHA_CLIENT_ID", ""))
    koha_client_secret: str = field(default_factory=lambda: os.getenv("KOHA_CLIENT_SECRET", ""))
    koha_verify_tls: bool = field(default_factory=lambda: _bool("KOHA_VERIFY_TLS", True))
    koha_default_pickup: str = field(default_factory=lambda: os.getenv("KOHA_DEFAULT_PICKUP_LIBRARY", ""))
    # Seconds a title page waits for live availability from Koha before showing the last synced status
    live_wait: float = field(default_factory=lambda: float(os.getenv("KOHA_LIVE_WAIT", "4")))
    # Optional: id of a public Koha SQL report that returns anonymised co-borrowing pairs
    koha_coborrow_report_id: str = field(default_factory=lambda: os.getenv("KOHA_COBORROW_REPORT_ID", ""))

    # Optional: id of a public Koha SQL report with yearly fine totals (see docs/koha-setup.md)
    koha_fines_report_id: str = field(default_factory=lambda: os.getenv("KOHA_FINES_REPORT_ID", ""))
    # Patron field that holds the department, for the borrower reports: statistics_1 (Sort 1) or statistics_2 (Sort 2)
    patron_dept_field: str = field(default_factory=lambda: os.getenv("PATRON_DEPT_FIELD", "statistics_1"))
    # Claude (optional). Without a key the app uses its built-in rules.
    anthropic_api_key: str = field(default_factory=lambda: os.getenv("ANTHROPIC_API_KEY", ""))
    claude_model: str = field(default_factory=lambda: os.getenv("CLAUDE_MODEL", "claude-opus-5-5"))
    # Ask the librarian chat: questions per hour per computer, and how many catalogue titles Claude chooses from
    ask_per_hour: int = field(default_factory=lambda: int(os.getenv("ASK_PER_HOUR", "30") or 30))
    ask_candidates: int = field(default_factory=lambda: int(os.getenv("ASK_CANDIDATES", "25") or 25))
    ai_query_parsing: bool = field(default_factory=lambda: _bool("AI_QUERY_PARSING", True))

    # v5 meaning search and themes (see app/semantic.py): auto, model, lsa or off
    semantic: str = field(default_factory=lambda: os.getenv("SEMANTIC", "auto").lower())
    embed_model: str = field(default_factory=lambda: os.getenv("EMBED_MODEL", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"))
    semantic_min: float = field(default_factory=lambda: float(os.getenv("SEMANTIC_MIN_SCORE", "0") or 0))
    themes: int = field(default_factory=lambda: int(os.getenv("THEMES", "0") or 0))

    # Course readings: show the e-book links from the CSV (off by default; turn on only for licensed copies)
    course_ebook_links: bool = field(default_factory=lambda: _bool("COURSE_EBOOK_LINKS", False))

    # Reviews
    google_books_api_key: str = field(default_factory=lambda: os.getenv("GOOGLE_BOOKS_API_KEY", ""))
    amazon_domain: str = field(default_factory=lambda: os.getenv("AMAZON_DOMAIN", "www.amazon.in"))
    amazon_associate_tag: str = field(default_factory=lambda: os.getenv("AMAZON_ASSOCIATE_TAG", ""))

    # App
    library_name: str = field(default_factory=lambda: os.getenv("LIBRARY_NAME", "Your Library"))
    currency: str = field(default_factory=lambda: os.getenv("CURRENCY_SYMBOL", "₹"))
    secret_key: str = field(default_factory=lambda: os.getenv("SECRET_KEY", ""))
    admin_token: str = field(default_factory=lambda: os.getenv("ADMIN_TOKEN", ""))
    data_dir: Path = field(default_factory=lambda: Path(os.getenv("DATA_DIR", "./data")))
    # Saved-search email alerts (optional): the library's mail server
    smtp_host: str = field(default_factory=lambda: os.getenv("SMTP_HOST", ""))
    smtp_port: int = field(default_factory=lambda: int(os.getenv("SMTP_PORT", "587") or 587))
    smtp_user: str = field(default_factory=lambda: os.getenv("SMTP_USER", ""))
    smtp_password: str = field(default_factory=lambda: os.getenv("SMTP_PASSWORD", ""))
    smtp_from: str = field(default_factory=lambda: os.getenv("SMTP_FROM", ""))
    smtp_starttls: bool = field(default_factory=lambda: _bool("SMTP_STARTTLS", True))
    # The address readers use to open the app, for links in emails and shared links
    public_url: str = field(default_factory=lambda: os.getenv("PUBLIC_URL", ""))
    secure_cookies: bool = field(default_factory=lambda: _bool("SECURE_COOKIES", False))

    @property
    def demo(self) -> bool:
        return self.mode != "koha"

    @property
    def ai_enabled(self) -> bool:
        return bool(self.anthropic_api_key)


settings = Settings()
