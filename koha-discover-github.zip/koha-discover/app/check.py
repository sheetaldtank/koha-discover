"""Check the connection to Koha, step by step, and say what to fix.

Run:  docker compose run --rm discover python -m app.check
      docker compose run --rm discover python -m app.check --card 1234567 --password 'secret'   (also tests patron sign-in)
"""
import argparse
import asyncio
import time

from .config import settings
from .koha import KohaClient, KohaError
from .marc import marc_to_record


async def main(card, password):
    print(f"Koha staff URL: {settings.koha_url or '(not set)'}   sign-in method: {settings.koha_auth}")
    if settings.demo:
        print("DISCOVER_MODE is 'demo'. Set it to 'koha' in .env to use your catalogue."); return 1
    k = KohaClient()
    ok = True

    async def step(name, coro, hint):
        nonlocal ok
        t = time.time()
        try:
            out = await coro
            print(f"  ok    {name}   ({time.time() - t:.1f} s)")
            return out
        except (KohaError, Exception) as e:
            ok = False
            print(f"  FAIL  {name}\n        {e}\n        Fix: {hint}")
            return None

    libs = await step("API login and list of libraries", k.libraries(),
                      "check KOHA_URL, the API username/password or key, and that RESTBasicAuth or RESTOAuth2ClientCredentials is on")
    if libs:
        print(f"        branches: {', '.join(f'{c} ({n})' for c, n in list(libs.items())[:8])}")
        if settings.koha_default_pickup and settings.koha_default_pickup not in libs:
            print(f"  WARN  KOHA_DEFAULT_PICKUP_LIBRARY={settings.koha_default_pickup} is not one of these branch codes")
    first = await step("list catalogue records", k._req("GET", "/biblios", params={"_per_page": 1}),
                       "give the API account the 'catalogue' permission")
    if first is not None and first.json():
        bid = first.json()[0]["biblio_id"]
        marc = await step(f"read MARC record {bid}", k._req("GET", f"/biblios/{bid}", accept="application/marc-in-json"),
                          "give the API account the 'catalogue' permission")
        if marc is not None:
            r = marc_to_record(bid, marc.json())
            print(f"        read as: {r['t']} / {r['a']} / {r['y']} / {r['l']} / ISBN {r['isbn'] or '-'}")
        await step(f"read copies of record {bid}", k.availability(bid), "give the API account the 'catalogue' permission")
        await step("read 100 records in one request (used by the sync)",
                   k._req("GET", "/biblios", accept="application/marc-in-json", params={"_per_page": 100}),
                   "the sync will fall back to one request per record, which is much slower")
        await step("read 1000 copies in one request (used by the sync)", k._req("GET", "/items", params={"_per_page": 1000}),
                   "give the API account the 'catalogue' permission")
    if card:
        pid = await step("check a patron's card and password", k.authenticate(card, password or ""),
                         "give the API account the borrowers permissions in docs/koha-setup.md")
        if pid is None and ok:
            print("        Koha says that card and password don't match.")
        elif pid:
            for name, coro in (("patron details", k.patron(pid)), ("loans", k.loans(pid)), ("holds", k.holds(pid)),
                               ("fines", k.fines(pid)), ("reading history", k.history(pid))):
                await step(name, coro, "add the permission named in docs/koha-setup.md for this area")
    print("All checks passed." if ok else "Some checks failed. Fix those, then run this again.")
    return 0 if ok else 1


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--card"); p.add_argument("--password")
    a = p.parse_args()
    raise SystemExit(asyncio.run(main(a.card, a.password)))
