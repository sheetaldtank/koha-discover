"""Circulation reports for staff: use of the collection between two dates, and who borrows.

They read the loans copied from Koha by `python -m app.sync --circulation` (table circ), plus each title's copies,
lifetime checkouts and last-borrowed date from the item records. Loans keep Koha's borrower number only; names are
looked up from Koha when the Most active borrowers report is opened, and are never stored.

Use factor (Bonn's relative use) = a subject's share of the borrowing / its share of the collection.
Above 1 the subject is borrowed more than its size suggests; below 0.5 it is under-used.
"""
from __future__ import annotations

from collections import Counter, defaultdict

from .catalog import Catalog
from .config import settings
from .dewey import display

FINES_SQL = """SELECT YEAR(`date`) AS year,
  ROUND(SUM(CASE WHEN debit_type_code IS NOT NULL AND debit_type_code <> 'PAYOUT' THEN amount ELSE 0 END), 2) AS charged,
  ROUND(SUM(CASE WHEN debit_type_code = 'OVERDUE' THEN amount ELSE 0 END), 2) AS overdue_fines,
  ROUND(SUM(CASE WHEN credit_type_code = 'PAYMENT' AND (status IS NULL OR status <> 'VOID') THEN -amount ELSE 0 END), 2) AS collected,
  ROUND(SUM(CASE WHEN credit_type_code IN ('WRITEOFF','FORGIVEN','CANCELLATION') AND (status IS NULL OR status <> 'VOID')
                 THEN -amount ELSE 0 END), 2) AS waived,
  ROUND(SUM(CASE WHEN debit_type_code IS NOT NULL THEN amountoutstanding ELSE 0 END), 2) AS outstanding_now
FROM accountlines
WHERE `date` IS NOT NULL
GROUP BY YEAR(`date`)
ORDER BY year DESC"""


def _status(cat: Catalog) -> str:
    s = cat.cache_get("circ_synced")
    if not s:
        return (" No loans have been copied yet. On the app's computer run:  python -m app.sync --circulation "
                "--since 2023-01-01  (choose the first date you want reports for).")
    return f" Loans copied from {s['from']}, last updated {s['to']}."


def _loans(cat: Catalog, P: dict) -> list[tuple]:
    """(biblio_id, pid, out, back, renewals) for loans that went out in the period."""
    return cat.run("SELECT COALESCE(c.biblio_id, m.biblio_id), c.pid, c.out, c.back, c.renewals FROM circ c "
                   "LEFT JOIN item_map m ON m.item_id = c.item_id WHERE c.out >= ? AND c.out <= ?", (P["start"], P["end"]))


def _held(cat: Catalog, P: dict) -> list[dict]:
    """Titles the library held during the period (with copies, added before the period ended)."""
    books = [b for b in cat.books.values() if b.get("tot")] or list(cat.books.values())
    return [b for b in books if not b.get("acq") or b["acq"] <= P["end"]]


def _subject(cat: Catalog, b: dict, level: int = 2) -> str:
    d = (b.get("dd") or "")[:level]
    return f"{display(d)} {cat.onto.name(d)}".strip() if d else "No Dewey number"


def circ_summary(cat: Catalog, P: dict):
    loans = _loans(cat, P)
    returns = cat.run("SELECT substr(back, 1, 7), COUNT(*) FROM circ WHERE back >= ? AND back <= ? GROUP BY 1",
                      (P["start"], P["end"]))
    back_by_month = dict(returns)
    months = defaultdict(lambda: [0, 0, set(), set()])
    for bid, pid, out, back, ren in loans:
        m = months[out[:7]]
        m[0] += 1
        m[1] += ren or 0
        if bid:
            m[2].add(bid)
        if pid:
            m[3].add(pid)
    rows = [["All", len(loans), sum(r[4] or 0 for r in loans), sum(back_by_month.values()),
             len({r[0] for r in loans if r[0]}), len({r[1] for r in loans if r[1]})]]
    for k in sorted(months):
        c, ren, t, p = months[k]
        rows.append([k, c, ren, back_by_month.get(k, 0), len(t), len(p)])
    held = _held(cat, P)
    used = {r[0] for r in loans if r[0]}
    pct = round(100 * len(used & {b["id"] for b in held}) / len(held)) if held else 0
    return {"columns": ["Month", "Checkouts", "Renewals", "Returns", "Different titles", "Different borrowers"], "rows": rows,
            "about": f"{len(used):,} of {len(held):,} titles ({pct}%) were borrowed at least once in this period. "
                     "Borrowers whose history Koha anonymises are not counted as different borrowers." + _status(cat)}


def top_titles(cat: Catalog, P: dict):
    c, ren = Counter(), Counter()
    for bid, _, _, _, r in _loans(cat, P):
        if bid:
            c[bid] += 1
            ren[bid] += r or 0
    ranked = sorted(c, key=lambda b: (-(c[b] + ren[b]), -c[b]))[:20]
    rows = []
    for i, bid in enumerate(ranked, 1):
        b = cat.books.get(bid, {"t": f"Record {bid} (not in the catalogue copy)", "a": ""})
        copies = b.get("tot") or 0
        rows.append([i, b["t"], b.get("a", ""), b.get("call", ""), c[bid], ren[bid], copies,
                     round(c[bid] / copies, 1) if copies else "", _subject(cat, b) if b.get("id") else ""])
    return {"columns": ["Rank", "Title", "Author", "Call number", "Checkouts", "Renewals", "Copies", "Checkouts per copy",
                        "Subject area"], "rows": rows,
            "about": "Ranked by checkouts plus renewals. Many checkouts per copy suggests buying another copy." + _status(cat)}


def least_titles(cat: Catalog, P: dict):
    c = Counter(r[0] for r in _loans(cat, P) if r[0])
    last_local = dict(cat.run("SELECT COALESCE(c.biblio_id, m.biblio_id), MAX(c.out) FROM circ c "
                              "LEFT JOIN item_map m ON m.item_id = c.item_id GROUP BY 1"))
    # only titles the library already had when the period began, so new books don't look unused
    pool = [b for b in cat.books.values() if b.get("tot") and (not b.get("acq") or b["acq"] < P["start"])]
    zero = sum(1 for b in pool if not c[b["id"]])

    def last(b):
        return max(b.get("lastb") or "", last_local.get(b["id"]) or "")
    pool.sort(key=lambda b: (c[b["id"]], last(b), b.get("acq") or "9999", b.get("uses") or 0))
    rows = [[b["t"], b.get("a", ""), b.get("call", ""), b.get("y") or "", b.get("tot") or 0, c[b["id"]], b.get("uses", ""),
             last(b) or "Never", b.get("acq") or "", _subject(cat, b)] for b in pool[:20]]
    return {"columns": ["Title", "Author", "Call number", "Year", "Copies", "Checkouts in period", "Lifetime checkouts",
                        "Last borrowed", "Added", "Subject area"], "rows": rows,
            "about": f"{zero:,} of {len(pool):,} titles held before {P['start']} were not borrowed at all in this period. "
                     "Shown: the 20 unused the longest. Candidates for promotion, relocation or weeding." + _status(cat)}


def _use(cat: Catalog, P: dict, level: int):
    held = _held(cat, P)
    held_ids = {b["id"] for b in held}
    loans = Counter(r[0] for r in _loans(cat, P) if r[0] in held_ids)
    agg = defaultdict(lambda: [0, 0, 0, 0])  # titles, copies, checkouts, titles borrowed
    for b in held:
        a = agg[_subject(cat, b, level)]
        a[0] += 1
        a[1] += b.get("tot") or 0
        a[2] += loans[b["id"]]
        a[3] += 1 if loans[b["id"]] else 0
    T, L = len(held) or 1, sum(loans.values()) or 1
    rows = []
    for name, (t, cp, n, used) in agg.items():
        sc, sl = 100 * t / T, 100 * n / L
        f = round(sl / sc, 2) if sc else 0
        verdict = "Well used" if f > 1 else "Under-used" if f < 0.5 else "Average"
        rows.append([name, t, cp, n, round(n / t, 2), round(100 * used / t), round(sc, 1), round(sl, 1), f, verdict])
    rows.sort(key=lambda r: -r[8])
    return {"columns": ["Subject area", "Titles", "Copies", "Checkouts", "Checkouts per title", "% of titles borrowed",
                        "% of collection", "% of checkouts", "Use factor", "Verdict"], "rows": rows,
            "about": "Use factor = share of checkouts ÷ share of the collection. Above 1: borrowed more than its size "
                     "suggests (well used, consider buying more). Below 0.5: under-used (promote, relocate or weed)."
                     + _status(cat)}


def use_factor(cat: Catalog, P: dict):
    return _use(cat, P, 2)


def use_by_class(cat: Catalog, P: dict):
    return _use(cat, P, 1)


def _patrons(cat: Catalog) -> dict:
    return {p: (c, l, s1, s2) for p, c, l, s1, s2 in cat.run("SELECT pid, cat, lib, s1, s2 FROM patron_min")}


def _dept(row) -> str:
    return (row[3] if settings.patron_dept_field == "statistics_2" else row[2]) if row else ""


def top_borrower_ids(cat: Catalog, P: dict, n: int = 20) -> list[int]:
    c = Counter(r[1] for r in _loans(cat, P) if r[1])
    return [p for p, _ in c.most_common(n)]


def borrowers(cat: Catalog, P: dict, names: dict | None = None):
    names = names or {}
    cats = cat.cache_get("patron_categories") or {}
    pm = _patrons(cat)
    c, ren, titles, last = Counter(), Counter(), defaultdict(set), {}
    for bid, pid, out, _, r in _loans(cat, P):
        if pid:
            c[pid] += 1
            ren[pid] += r or 0
            if bid:
                titles[pid].add(bid)
            last[pid] = max(last.get(pid, ""), out)
    rows = []
    for i, (pid, n) in enumerate(c.most_common(20), 1):
        info, nm = pm.get(pid), names.get(pid) or names.get(str(pid)) or {}
        rows.append([i, nm.get("name") or f"Borrower {pid}", nm.get("card", ""), cats.get(info[0], info[0]) if info else "",
                     _dept(info), n, ren[pid], len(titles[pid]), last[pid]])
    return {"columns": ["Rank", "Name", "Card number", "Category", "Department", "Checkouts", "Renewals",
                        "Different titles", "Last checkout"], "rows": rows,
            "about": "Staff only: this report names patrons. Handle exports like any other patron data. Patrons who "
                     "chose not to keep their reading history in Koha are not included." + _status(cat)}


def _group(cat: Catalog, P: dict, key, label: str):
    pm = _patrons(cat)
    registered = Counter(key(v) or "Not recorded" for v in pm.values())
    c, ren, active = Counter(), Counter(), defaultdict(set)
    anon = 0
    for _, pid, _, _, r in _loans(cat, P):
        if not pid:
            anon += 1
            continue
        g = key(pm.get(pid)) or "Not recorded"
        c[g] += 1
        ren[g] += r or 0
        active[g].add(pid)
    rows = []
    for g in sorted(set(registered) | set(c), key=lambda g: -c[g]):
        a, reg = len(active[g]), registered.get(g, 0)
        rows.append([g, reg, a, round(100 * a / reg) if reg else "", c[g], ren[g], round(c[g] / a, 1) if a else 0])
    if anon:
        rows.append(["Anonymised history", "", "", "", anon, "", ""])
    return {"columns": [label, "Registered patrons", "Active borrowers", "% active", "Checkouts", "Renewals",
                        "Checkouts per active borrower"], "rows": rows,
            "about": f"Who uses the library, by {label.lower()}. Active = borrowed at least once in the period." + _status(cat)}


def by_category(cat: Catalog, P: dict):
    cats = cat.cache_get("patron_categories") or {}
    return _group(cat, P, lambda v: cats.get(v[0], v[0]) if v else "", "Patron category")


def by_department(cat: Catalog, P: dict):
    out = _group(cat, P, _dept, "Department")
    field = "Sort 2" if settings.patron_dept_field == "statistics_2" else "Sort 1"
    out["about"] += f" Department is read from the patron field {field} (PATRON_DEPT_FIELD in .env)."
    return out


def fines(cat: Catalog, P: dict, rows: list | None = None):
    cur = settings.currency
    if not settings.koha_fines_report_id and not settings.demo:
        return {"columns": ["Year", "Charged", "Of which overdue fines", "Collected", "Waived", "Still outstanding"],
                "rows": [], "about": "Not set up yet. Create the public SQL report in docs/koha-setup.md "
                                     "(\"Fines by year\") and put its number in .env as KOHA_FINES_REPORT_ID."}
    y0, y1 = int(P["start"][:4]), int(P["end"][:4])
    out = []
    for r in rows or []:
        r = list(r) + [0] * (6 - len(r))
        try:
            y = int(r[0])
        except (TypeError, ValueError):
            continue
        if y0 <= y <= y1:
            out.append([y] + [round(float(x or 0), 2) for x in r[1:6]])
    out.sort(key=lambda r: r[0])
    if len(out) > 1:
        out.append(["Total"] + [round(sum(x[i] for x in out), 2) for i in range(1, 6)])
    return {"columns": ["Year", f"Charged ({cur})", f"Of which overdue fines ({cur})", f"Collected ({cur})",
                        f"Waived ({cur})", f"Still outstanding ({cur})"], "rows": out,
            "about": "Totals from Koha's accounts, by calendar year of the charge or payment. "
                     "Whole years in the chosen period are shown. No patron details are read. "
                     "Koha's public reports return at most 10 rows (system preference SvcMaxReportRows), so the "
                     "report lists the newest years first."}
