"""Course readings (v5): the library's semester list of textbooks and reference books recommended by faculty.

Staff upload the semester's CSV on the admin page (the same file the library already makes). Each row is one copy:
faculty, course code and name, title, author, ISBN, call number, accession number, Textbook/Reference, lending policy
(CR = Course Reserve, not for issue; SL = Short Loan, 3-day issue) and Koha's biblio number, which links the row to
the catalogue for live shelf status. Older semesters are kept and can still be searched.
"""
from __future__ import annotations

import csv
import io
import re
import time
from collections import Counter, OrderedDict

from .catalog import Catalog, norm, words
from .config import settings

# header in the CSV (any spelling/case) -> our field
HEADERS = {
    "faculty": ["name of faculty", "faculty", "faculty name", "instructor", "professor"],
    "code": ["course code", "code", "course no", "course number"],
    "course": ["course name", "course", "course title"],
    "title": ["title", "book title"],
    "author": ["author", "authors"],
    "publisher": ["publisher"],
    "year": ["year", "pub year", "year of publication"],
    "isbn": ["print isbn", "isbn", "isbn13"],
    "call": ["call no", "call number", "call no."],
    "acc": ["acc no", "accession no", "accession number", "barcode", "acc. no."],
    "kind": ["textbook/reference books", "textbook/reference", "type", "textbook / reference books"],
    "policy": ["lending policy", "policy", "cr/sl"],
    "remarks": ["remarks", "remark"],
    "ebook": ["e-book link", "ebook link", "e-book", "ebook"],
    "biblio": ["biblio no", "biblio no.", "biblionumber", "biblio number", "biblio id"],
}
POLICY = {"CR": "Course Reserve (not for issue)", "SL": "Short Loan (3-day issue)", "REF": "Reference (in the library)"}
TRIGGER = re.compile(r"\b(course ?readings?|readings?|reading list|course ?books?|course ?reserves?|reserves?|text ?books?|"
                     r"prescribed|recommended|syllabus|courses?|short ?loan)\b")
CODE = re.compile(r"\b([a-z]{2,4})\s*-?\s*(\d{3}[a-z]?)\b")
SKIP = set("for of the a an in on by prof professor dr sir madam mam s my our books book list please show me give what are".split())


def setup(cat: Catalog):
    cat.db.executescript("""
        CREATE TABLE IF NOT EXISTS cr_semesters(id INTEGER PRIMARY KEY AUTOINCREMENT, label TEXT, uploaded REAL, rows INTEGER,
            filename TEXT, current INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS cr_rows(sem INTEGER, code TEXT, course TEXT, faculty TEXT, biblio_id INTEGER, title TEXT,
            author TEXT, publisher TEXT, year TEXT, isbn TEXT, call TEXT, acc TEXT, kind TEXT, policy TEXT, remarks TEXT, ebook TEXT);
        CREATE INDEX IF NOT EXISTS cr_rows_sem ON cr_rows(sem);
    """)
    cat.db.commit()


def _key(h: str) -> str:
    return re.sub(r"[^a-z0-9/]+", " ", (h or "").lower()).strip()


def _map_headers(header: list[str]) -> dict[str, int]:
    out = {}
    keys = [_key(h) for h in header]
    for field, names in HEADERS.items():
        for n in names:
            n = _key(n)
            for i, k in enumerate(keys):
                if k == n and field not in out:
                    out[field] = i
    return out


def code_norm(c: str) -> str:
    m = re.match(r"^\s*([A-Za-z]{2,4})\s*-?\s*(\d{3}[A-Za-z]?)\s*$", c or "")
    return f"{m.group(1).upper()} {m.group(2).upper()}" if m else (c or "").strip().upper()


def import_csv(cat: Catalog, data: bytes, label: str, filename: str = "") -> dict:
    """Read a semester's CSV, store it as a new semester and make it the current one."""
    text = data.decode("utf-8-sig", errors="replace")
    rows = list(csv.reader(io.StringIO(text)))
    if not rows:
        raise ValueError("The file is empty.")
    cols = _map_headers(rows[0])
    missing = [f for f in ("title", "biblio") if f not in cols]
    if "title" in missing or ("biblio" in missing and "isbn" not in cols):
        raise ValueError("The file needs at least a Title column and a Biblio no. (or ISBN) column. "
                         f"Columns found: {', '.join(h.strip() for h in rows[0])}")
    out = []
    by_isbn = {}
    for b in cat.books.values():
        if b.get("isbn"):
            by_isbn.setdefault(b["isbn"], b["id"])
    for r in rows[1:]:
        if not any(x.strip() for x in r):
            continue
        g = lambda f: (r[cols[f]].strip() if f in cols and cols[f] < len(r) else "")  # noqa: E731
        bib = re.sub(r"\D", "", g("biblio"))
        bid = int(bib) if bib else by_isbn.get(re.sub(r"[^0-9Xx]", "", g("isbn")))
        pol = g("policy").upper().replace(".", "")
        out.append((code_norm(g("code")), g("course"), re.sub(r"\s+", " ", g("faculty")), bid, g("title"), g("author"),
                    g("publisher"), g("year"), g("isbn"), g("call"), g("acc"), g("kind").title() or "Textbook",
                    "REF" if pol.startswith("REF") else pol, g("remarks"), g("ebook")))
    if not out:
        raise ValueError("No rows were found under the header.")
    with cat.lock:
        cur = cat.db.execute("INSERT INTO cr_semesters(label, uploaded, rows, filename, current) VALUES(?,?,?,?,0)",
                             (label.strip() or time.strftime("Uploaded %d %b %Y"), time.time(), len(out), filename))
        sid = cur.lastrowid
        cat.db.executemany("INSERT INTO cr_rows VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", [(sid,) + r for r in out])
        cat.db.execute("UPDATE cr_semesters SET current = (id = ?)", (sid,))
        cat.db.commit()
    return summary(cat, sid)


def summary(cat: Catalog, sid: int) -> dict:
    rows = _rows(cat, sid)
    missing = sorted({(r["biblio_id"], r["title"]) for r in rows if r["biblio_id"] not in cat.books}, key=lambda x: x[1])
    return {"id": sid, "rows": len(rows), "courses": len({r["code"] or r["course"] for r in rows if r["code"] or r["course"]}),
            "faculty": len({r["faculty"] for r in rows if r["faculty"]}), "titles": len({r["biblio_id"] or r["title"] for r in rows}),
            "not_in_catalogue": [{"biblio_id": b, "title": t} for b, t in missing][:200],
            "no_course_code": sum(1 for r in rows if not r["code"])}


def semesters(cat: Catalog) -> list[dict]:
    return [{"id": i, "label": lb, "uploaded": time.strftime("%Y-%m-%d", time.localtime(up)), "rows": n, "current": bool(c),
             "filename": fn}
            for i, lb, up, n, fn, c in cat.run("SELECT id, label, uploaded, rows, filename, current FROM cr_semesters ORDER BY id DESC")]


def current_id(cat: Catalog) -> int | None:
    r = cat.run("SELECT id FROM cr_semesters ORDER BY current DESC, id DESC LIMIT 1")
    return r[0][0] if r else None


def set_current(cat: Catalog, sid: int):
    cat.run("UPDATE cr_semesters SET current = (id = ?)", (sid,), commit=True)


def delete(cat: Catalog, sid: int):
    with cat.lock:
        cat.db.execute("DELETE FROM cr_rows WHERE sem=?", (sid,))
        cat.db.execute("DELETE FROM cr_semesters WHERE id=?", (sid,))
        cat.db.commit()


COLS = ["sem", "code", "course", "faculty", "biblio_id", "title", "author", "publisher", "year", "isbn", "call", "acc", "kind",
        "policy", "remarks", "ebook"]
_cache: dict = {}


def _rows(cat: Catalog, sid: int | None) -> list[dict]:
    if sid is None:
        return []
    stamp = cat.run("SELECT rows, uploaded FROM cr_semesters WHERE id=?", (sid,))
    key = (id(cat), sid, tuple(stamp[0]) if stamp else None)
    if key not in _cache:
        _cache.clear()
        _cache[key] = [dict(zip(COLS, r)) for r in cat.run("SELECT * FROM cr_rows WHERE sem=? ORDER BY rowid", (sid,))]
    return _cache[key]


def label(cat: Catalog, sid: int | None) -> str:
    r = cat.run("SELECT label FROM cr_semesters WHERE id=?", (sid,)) if sid else []
    return r[0][0] if r else ""


def pickers(cat: Catalog, sid: int | None) -> dict:
    """Faculty, course names and codes for the three menus, like the library's course readings page."""
    rows = _rows(cat, sid)
    courses = OrderedDict()
    for r in rows:
        k = r["code"] or ""
        c = courses.setdefault((k, r["course"]), {"code": k, "name": r["course"], "faculty": [], "titles": set()})
        if r["faculty"] and r["faculty"] not in c["faculty"]:
            c["faculty"].append(r["faculty"])
        c["titles"].add(r["biblio_id"] or r["title"])
    lst = [dict(c, titles=len(c["titles"])) for c in courses.values() if c["code"] or c["name"]]
    lst.sort(key=lambda c: (c["code"] or "~", c["name"]))
    return {"courses": lst, "faculty": sorted({r["faculty"] for r in rows if r["faculty"]}),
            "codes": sorted({r["code"] for r in rows if r["code"]})}


def select(cat: Catalog, sid: int | None, code="", faculty="", course="", text="") -> list[dict]:
    rows = _rows(cat, sid)
    code = code_norm(code) if code else ""
    tw = [w for w in words(text) if w not in SKIP] if text else []
    out = []
    for r in rows:
        if code and r["code"] != code:
            continue
        if faculty and norm(r["faculty"]) != norm(faculty):
            continue
        if course and norm(r["course"]) != norm(course):
            continue
        if tw:
            hay = set(words(" ".join([r["title"], r["author"], r["course"], r["faculty"], r["code"], r["isbn"]])))
            if not all(w in hay or any(h.startswith(w) for h in hay if len(w) >= 4) for w in tw):
                continue
        out.append(r)
    return out


def group(cat: Catalog, rows: list[dict]) -> list[dict]:
    """One entry per title per course, with its copies counted by lending policy."""
    g = OrderedDict()
    for r in rows:
        k = (r["code"], r["course"], r["biblio_id"] or r["title"])
        e = g.setdefault(k, {"code": r["code"], "course": r["course"], "faculty": [], "biblio_id": r["biblio_id"],
                             "title": r["title"], "author": r["author"], "publisher": r["publisher"], "year": r["year"],
                             "isbn": r["isbn"], "call": r["call"], "kind": r["kind"], "copies": Counter(), "acc": [],
                             "ebook": r["ebook"] if settings.course_ebook_links else "",
                             "in_catalogue": r["biblio_id"] in cat.books})
        if r["faculty"] and r["faculty"] not in e["faculty"]:
            e["faculty"].append(r["faculty"])
        e["copies"][r["policy"] or "?"] += 1
        if r["acc"]:
            e["acc"].append({"acc": r["acc"], "policy": r["policy"]})
        if r["kind"] == "Textbook":
            e["kind"] = "Textbook"
    out = list(g.values())
    for e in out:
        e["copies"] = dict(e["copies"])
    out.sort(key=lambda e: (e["code"] or "~", e["course"], e["kind"] != "Textbook", e["title"].lower()))
    return out


def understand(cat: Catalog, q: str) -> dict | None:
    """Is the search about course readings? Returns {"code"|"faculty"|"course": ..., "strong": bool} or None.

    strong: the reader clearly asked for course readings (a course code, or words like "readings", "course",
    "textbooks"), so the course list is shown first. Otherwise a matching course is only offered as a suggestion."""
    sid = current_id(cat)
    if sid is None or not q.strip():
        return None
    s = norm(q)
    rows = _rows(cat, sid)
    codes = {r["code"] for r in rows if r["code"]}
    for m in CODE.finditer(s):
        c = f"{m.group(1).upper()} {m.group(2).upper()}"
        if c in codes:
            return {"code": c, "strong": True, "sem": sid}
    trig = bool(TRIGGER.search(s))
    rest = [w for w in words(TRIGGER.sub(" ", s)) if w not in SKIP and len(w) > 1]
    if not rest:
        return {"all": True, "strong": True, "sem": sid} if trig else None
    # faculty: every word typed is in the faculty member's name
    fac = {r["faculty"] for r in rows if r["faculty"]}
    hits = [f for f in fac if all(w in words(f) for w in rest)]
    if len(hits) == 1 and (trig or len(rest) >= 2):
        return {"faculty": hits[0], "strong": trig, "sem": sid}
    # course name: the words typed make up the course name (or most of it)
    names = {r["course"] for r in rows if r["course"]}
    best, bs = None, 0.0
    for n in names:
        nw = [w for w in words(n) if w not in SKIP]
        if not nw:
            continue
        got = sum(1 for w in rest if w in nw or any(x.startswith(w) for x in nw if len(w) >= 4))
        sc = got / max(len(rest), 1) * (got / len(nw))
        if got == len(rest) and sc > bs:
            best, bs = n, sc
    if best and (bs >= 0.5 or (trig and bs > 0)):
        return {"course": best, "strong": trig, "sem": sid}
    return None


def answer(cat: Catalog, intent: dict) -> dict:
    """The course readings card shown above (or instead of) the search results."""
    sid = intent["sem"]
    rows = select(cat, sid, code=intent.get("code", ""), faculty=intent.get("faculty", ""), course=intent.get("course", ""))
    if intent.get("all"):
        return {"semester": label(cat, sid), "sem": sid, "all": True, "strong": True, "title": "Course readings",
                "courses": pickers(cat, sid)["courses"][:400], "items": []}
    items = group(cat, rows)
    courses = OrderedDict()
    for r in rows:
        courses.setdefault((r["code"], r["course"]), set()).add(r["faculty"])
    heading = (intent.get("code") or intent.get("course") or intent.get("faculty") or "").strip()
    if intent.get("code") and rows:
        heading = f"{rows[0]['code']} {rows[0]['course']}".strip()
    return {"semester": label(cat, sid), "sem": sid, "strong": intent.get("strong", False), "title": heading,
            "by": intent, "courses": [{"code": c, "name": n, "faculty": sorted(x for x in f if x)} for (c, n), f in courses.items()],
            "items": items, "policies": POLICY}


EXPORT_COLUMNS = ["Course code", "Course name", "Faculty", "Title", "Author", "Publisher", "Year", "ISBN", "Call no.",
                  "Textbook/Reference", "Course Reserve copies", "Short Loan copies", "Accession numbers", "Biblio no."]


def export_rows(items: list[dict]) -> list[list]:
    return [[e["code"], e["course"], "; ".join(e["faculty"]), e["title"], e["author"], e["publisher"], e["year"], e["isbn"],
             e["call"], e["kind"], e["copies"].get("CR", 0), e["copies"].get("SL", 0), ", ".join(a["acc"] for a in e["acc"]),
             e["biblio_id"] or ""] for e in items]
