/* Catalogue Discover front end. Talks to the app's own API (relative URLs, so it works under a sub-path). */
"use strict";
const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const S = {q:"", rm:new Set(), facet:{}, user:null, view:"search", tab:"loans", open:null, login:false, loginErr:"",
  img:false, imgURL:null, imgRes:null, writing:false, cfg:{}, data:null, me:null};
const FNAMES = {cover:"Searching", isbn:"ISBN", author:"By", format:"Format", lang:"Language", aud:"For", fic:"Type", avail:"Availability", ymin:"Published", similar:"Similar to",
  who:"Author", pub:"Publisher", subj:"Subject", ddc:"Subject area", authors:"By", about:"Looking at", theme:"Theme"};
const day = 86400000;

async function api(path, opts={}) {
  const o = {credentials:"same-origin", ...opts, headers:{...(opts.body && !(opts.body instanceof FormData) ? {"Content-Type":"application/json"} : {}), ...(opts.headers||{})}};
  if (o.body && !(o.body instanceof FormData) && typeof o.body !== "string") o.body = JSON.stringify(o.body);
  const r = await fetch(path.replace(/^\//, ""), o);
  let j = null; try { j = await r.json(); } catch {}
  if (!r.ok) throw new Error((j && (j.error || j.detail)) || "Something went wrong. Please try again.");
  return j;
}
function toast(t){const e=$("toast");e.textContent=t;e.hidden=false;clearTimeout(toast.h);toast.h=setTimeout(()=>e.hidden=true,2600)}
const fmtD = s => s ? new Date(s+"T00:00:00").toLocaleDateString(undefined,{day:"numeric",month:"short",year:"numeric"}) : "";
const today = () => new Date(new Date().toDateString());
function isbn10(i){if(!i)return"";if(i.length===10)return i.toUpperCase();if(i.length!==13||!i.startsWith("978"))return"";const c=i.slice(3,12);let s=0;for(let k=0;k<9;k++)s+=(10-k)*+c[k];const d=(11-s%11)%11;return c+(d===10?"X":d)}
function coverSrcs(b){const out=[],i10=isbn10(b.isbn);
  if(i10)out.push(`https://images-na.ssl-images-amazon.com/images/P/${i10}.01.MZZZZZZZ.jpg`);
  if(b.isbn)out.push(`https://covers.openlibrary.org/b/isbn/${b.isbn}-M.jpg?default=false`);
  if(S.cfg&&S.cfg.opac&&!S.cfg.demo)out.push(`${S.cfg.opac}/cgi-bin/koha/opac-image.pl?thumbnail=1&biblionumber=${b.id}`);
  return out}
/* A drawn cover sits underneath; the real cover image (if any source has one) loads on top of it. */
function cover(b,lg){const h=b.hue??200,src=coverSrcs(b);return `<div title="${esc(b.cd||"")}" class="cover${lg?" lg":""}" style="background:linear-gradient(160deg,hsl(${h} 52% 38%),hsl(${(h+18)%360} 55% 24%))" aria-hidden="true"><div class="ct">${esc(b.t)}</div><div class="ca">${esc((b.a||"").split(",")[0])}</div>${src.length?`<img class="cimg" alt="" loading="lazy" referrerpolicy="no-referrer" data-srcs="${esc(src.slice(1).join(" "))}" src="${esc(src[0])}">`:""}</div>`}
function nextCover(img){const rest=(img.dataset.srcs||"").split(" ").filter(Boolean);if(!rest.length){img.remove();return}img.dataset.srcs=rest.slice(1).join(" ");img.src=rest[0]}
document.addEventListener("error",e=>{if(e.target.classList&&e.target.classList.contains("cimg"))nextCover(e.target)},true);
document.addEventListener("load",e=>{const t=e.target;if(t.classList&&t.classList.contains("cimg")){if(t.naturalWidth<40||t.naturalHeight<40)nextCover(t);else t.classList.add("ok")}},true);
function avail(b){const e=b.f==="eBook"||b.f==="Audiobook";if(!b.tot)return"";return b.av>0?`<span class="pill ok">${e?"Available to borrow":b.av+" of "+b.tot+" on shelf"}</span>`:`<span class="pill warn">All ${b.tot} out</span>`}
function starsHTML(r){if(r==null)return`<span class="small">No rating</span>`;const s=Math.round(r*2)/2;return `<span class="stars" aria-label="${r} out of 5">${"★".repeat(Math.floor(s))}${s%1?"⯪":""}${"☆".repeat(5-Math.ceil(s))}</span>`}
function chipText(k,f,u){if(k==="ymin"){if(f.ymin&&f.ymax)return f.ymin===f.ymax?"in "+f.ymin:f.ymin+"–"+f.ymax;return f.ymin?f.ymin+" or later":"before "+(f.ymax+1)}
  if(k==="cover")return"book covers";if(k==="fic")return f.fic?"Fiction":"Non-fiction";if(k==="avail")return"Available now";if(k==="similar")return u.similar_title;if(k==="ddc")return f.ddc.padEnd(3,"0")+(u.ddc_name?" "+u.ddc_name:"");
  if(k==="authors")return f.authors.length>3?`any of ${f.authors.length} authors (${f.authors.slice(0,2).join(", ")}…)`:f.authors.join(" or ");
  if(k==="about")return"what books are about, not who wrote them";if(k==="theme")return u.theme_name||"theme "+f.theme;return f[k]}
/* Why a title matched, in plain words */
const WHERE={title:"the title",auth:"the author",subj:"the subjects",notes:"the summary",cover:"the cover description","subject area":"a related subject area"};
function whyHTML(why){if(!why||!why.length)return"";
  if(why.length===1&&why[0][1]==="meaning")return`<div class="why"><span class="mean">≈ Close in meaning to your search</span></div>`;
  if(why[0][1]==="course readings")return`<div class="why">On the course readings for <mark>${esc(why[0][0])}</mark></div>`;
  return`<div class="why">Matched ${why.map(w=>w[1]==="meaning"?"close in meaning":`<mark>${esc(w[0])}</mark> in ${esc(WHERE[w[1]]||w[1])}`).join(", ")}</div>`}
const isHome=()=>!S.q&&!Object.keys(S.facet).length&&!S.rm.size;
function shelf(items){return `<div class="shelf">${items.map(x=>`<button type="button" data-open="${x.id}">${cover(x)}<span class="bt">${esc(x.t)}</span><span class="bn">${esc(x.note||(x.a||"").split(",")[0])}</span></button>`).join("")}</div>`}
function link(k,v,text){return `<button type="button" class="lnk" data-link="${k}" data-val="${esc(v)}">${esc(text??v)}</button>`}
function goLink(k,v){S.q="";S.rm.clear();S.facet={[k]:v};S.view="search";S.open=null;renderPanel();doSearch();window.scrollTo(0,0)}

/* ---------- share, export, reading lists, saved searches ---------- */
const FACET_KEYS=["format","aud","lang","avail","who","pub","subj","ddc","theme","course_code"];
function searchParams(){const p=new URLSearchParams();if(S.q)p.set("q",S.q);if(S.rm.size)p.set("rm",[...S.rm].join(","));for(const [k,v] of Object.entries(S.facet))p.set(k,v===true?"true":v);return p}
function pageURL(query,hash){return location.origin+location.pathname+(query?"?"+query:"")+(hash?"#"+hash:"")}
function currentURL(){const q=S.view==="list"&&S.list?"list="+encodeURIComponent(S.list.id):S.view==="account"?"":S.view==="ask"?"ask=1":S.view==="courses"?courseParams(true).toString():searchParams().toString();return pageURL(q,S.open&&S.open.id&&!S.open.loading?"b="+S.open.id:"")}
function syncURL(){try{const u=currentURL();if(u!==location.href)history.replaceState(null,"",u)}catch{}}
async function copyText(text,msg){try{await navigator.clipboard.writeText(text);toast(msg||"Copied")}catch{prompt("Copy this:",text)}}
function myLists(){try{return JSON.parse(localStorage.getItem("dlists")||"{}")}catch{return {}}}
function setMyLists(m){try{localStorage.setItem("dlists",JSON.stringify(m))}catch{}}
function exportMenu(base){const sep=base.includes("?")?"&":"?";return `<details class="menu"><summary class="btn small">Export</summary><div class="menu-body">
  <a href="${esc(base+sep+"fmt=xlsx")}" download>Excel (.xlsx)</a><a href="${esc(base+sep+"fmt=csv")}" download>CSV</a>
  <a href="${esc(base+sep+"fmt=ris")}" download>RIS (Zotero, Mendeley, EndNote)</a><a href="${esc(base+sep+"fmt=bib")}" download>BibTeX (LaTeX)</a></div></details>`}
async function openList(id){S.view="list";S.open=null;S.list={loading:true,id};render();try{S.list=await api("api/lists/"+encodeURIComponent(id))}catch(e){S.list={error:e.message,id}}render()}
function renderList(){const L=S.list||{},own=myLists()[L.id];
  if(L.loading){$("main").innerHTML=`<section class="wrap listv"><p class="small">Loading the reading list…</p></section>`;return}
  if(L.error){$("main").innerHTML=`<section class="wrap listv"><h1>Reading list</h1><div class="empty">${esc(L.error)}</div></section>`;syncURL();return}
  $("main").innerHTML=`<section class="wrap listv">
    <p><button type="button" class="lnk" id="home2" data-gohome>← Back to the catalogue</button></p>
    <h1>${esc(L.name)}</h1>${L.note?`<p class="lede">${esc(L.note)}</p>`:""}
    <div class="small">${L.items.length} ${L.items.length===1?"title":"titles"} · updated ${fmtD(L.updated)} · ${own?"You made this list. Anyone with the link can see it, only you can change it.":"A reading list shared with you."}</div>
    <div class="tools"><button type="button" class="btn small" data-share>Copy link</button>${exportMenu("api/lists/"+encodeURIComponent(L.id)+"/export")}
      ${own?`<button type="button" class="btn small" data-editlist>Rename or add a note</button><button type="button" class="btn small" data-dellist>Delete list</button>`:""}</div>
    ${L.items.length?`<div class="results">${L.items.map(b=>`<div class="lrow">${rowHTML(b)}${own?`<button type="button" class="btn small" data-unlist="${b.id}" aria-label="Remove ${esc(b.t)} from this list">Remove</button>`:""}</div>`).join("")}</div>`:`<div class="empty">This list is empty. Open any title and choose <b>Add to list</b>.</div>`}
  </section>`;syncURL()}
async function addToList(lid,bid){const m=myLists();const L=await api("api/lists/"+lid,{method:"POST",body:{key:m[lid].key,add:bid}});m[lid].name=L.name;setMyLists(m);S.addTo=null;renderPanel();toast(`Added to “${L.name}”`)}
async function loadSaved(){if(!S.user)return;try{S.saved=await api("api/me/saved")}catch{S.saved=[]}if(isHome()&&S.view==="search")renderHome()}
function runSaved(x){S.q=x.params.q||"";S.rm=new Set((x.params.rm||"").split(",").filter(Boolean));S.facet={};for(const k of FACET_KEYS)if(x.params[k]!==undefined)S.facet[k]=k==="avail"?true:x.params[k];S.view="search";api(`api/me/saved/${x.id}/seen`,{method:"POST"}).catch(()=>{});x.new=0;doSearch();window.scrollTo(0,0)}
function rowHTML(b){return `<button type="button" class="row" data-open="${b.id}">${cover(b)}
            <div style="min-width:0"><h4>${esc(b.t)}${b.st?` <span class="st">${esc(b.st)}</span>`:""}</h4>
              <div class="meta">${esc(b.a)}${b.y?" · "+b.y:""}${b.ser?" · "+esc(b.ser[0])+(b.ser[1]?" #"+b.ser[1]:""):""}${b.l&&b.l!=="English"?" · "+esc(b.l):""}</div>
              <div class="about">${b.why&&b.why.some(w=>w[1]==="cover")&&b.cd?"<b>Cover:</b> "+esc(b.cd):esc(b.about||"")}</div>
              ${b.why_ai?`<div class="why ai">${esc(b.why_ai)}</div>`:whyHTML(b.why)}
            </div>
            <div class="side">${b.call?`<span class="call">${esc(b.call)}</span>`:""}${avail(b)}<span class="fmt">${esc(b.f)}</span></div>
          </button>`}

/* ---------- search ---------- */
async function doSearch(){
  if(isHome()){if(!S.home){try{S.home=await api("api/home")}catch(e){S.home={new:[],classes:[]}}}renderHome();if(S.user&&!S.picks)loadPicks();if(S.user&&!S.saved)loadSaved();return}
  const p = new URLSearchParams({q:S.q});
  if (S.rm.size) p.set("rm",[...S.rm].join(","));
  for (const [k,v] of Object.entries(S.facet)) p.set(k, v===true?"true":v);
  $("main").setAttribute("aria-busy","true");
  try { S.data = await api("api/search?"+p); } catch(e) { S.data = {error:e.message}; }
  $("main").removeAttribute("aria-busy");
  renderSearch();
}
function searchBox(ex){return `<section class="search wrap">
    <h1>What would you like to read?</h1>
    <p class="lede">Ask the way you would ask a librarian. Spelling mistakes are fine. You can also describe the cover.</p>
    <form class="q" id="qf" role="search"><input id="q" name="q" value="${esc(S.q)}" aria-label="Search the catalogue" autocomplete="off" placeholder="e.g. books about climate change after 2010"><button class="cam" type="button" data-img aria-label="Search with a photo of a cover or barcode" title="Search with a photo"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg></button><button class="btn primary" type="submit">Search</button></form>
    ${S.cfg.demo&&ex?`<div class="examples"><span>Try</span>${ex.map(e=>`<button type="button" class="ex" data-ex="${esc(e)}">${esc(e)}</button>`).join("")}</div>`:""}
  </section>`}
async function loadPicks(){S.picks="loading";if(isHome()&&S.view==="search")renderHome();try{S.picks=await api("api/me/picks")}catch(e){S.picks=[]}if(isHome()&&S.view==="search")renderHome()}
async function openBrowse(code){try{S.browse=await api("api/browse?ddc="+encodeURIComponent(code))}catch(e){toast(e.message);return}renderHome()}
function renderHome(){
  const h=S.home||{new:[],classes:[]},br=S.browse;
  const picks=!S.user?"":S.picks==="loading"||!S.picks?`<section class="home-sec"><h2>Picked for you</h2><p class="small">Looking at what you've borrowed…</p></section>`:S.picks.length?`<section class="home-sec"><h2>Picked for you</h2><p class="small">From your own borrowing. Only you see this.</p>${shelf(S.picks)}</section>`:"";
  const tree=br&&br.code?`<div class="crumbs"><button type="button" class="lnk" data-browse="">All subjects</button>${br.path.map(p=>` › <button type="button" class="lnk" data-browse="${p.code}">${esc((p.num+" "+p.name).trim())}</button>`).join("")}</div>`:"";
  const kids=(br&&br.code?br.children:h.classes)||[];
  const ml=Object.entries(myLists());
  const saved=S.user&&S.saved&&S.saved.length?`<section class="home-sec"><h2>Your saved searches</h2><p class="small">New titles are counted from when you last opened each search.${S.cfg.alerts?" Searches with alerts on also email you.":""}</p>
    <div class="savedlist">${S.saved.map((x,i)=>`<span class="sv"><button type="button" class="lnk" data-runsaved="${i}">${esc(x.name)}</button><span class="small">${x.total} titles</span>${x.new?`<span class="pill ok">${x.new} new</span>`:""}${x.email?`<span class="small" title="Email alerts on">✉</span>`:""}<button type="button" class="x" data-delsaved="${x.id}" aria-label="Delete saved search ${esc(x.name)}">×</button></span>`).join("")}</div></section>`:"";
  const lists=ml.length?`<section class="home-sec"><h2>Your reading lists</h2><p class="small">Kept in this browser. Share a list's link with anyone.</p><div class="savedlist">${ml.map(([id,x])=>`<span class="sv"><button type="button" class="lnk" data-showlist="${esc(id)}">${esc(x.name)}</button></span>`).join("")}</div></section>`:"";
  $("main").innerHTML=`${searchBox(["novels for kids about friendship","something like Harry Potter","hindi books","books by harrari","black cover with a gold bird"])}
  <div class="wrap home">
    ${saved}${picks}${lists}
    ${S.cfg.courses?`<section class="home-sec"><h2>Course readings</h2><p class="small">Textbooks and reference books your faculty recommend this semester. Search by course code, course name or faculty, e.g. “readings for CE 404”.</p><button type="button" class="btn" data-coursepage="1">Browse course readings</button></section>`:""}
    ${h.new.length?`<section class="home-sec"><h2>New arrivals</h2><p class="small">The newest additions to the library.</p>${shelf(h.new)}</section>`:""}
    ${(h.themes||[]).length?`<section class="home-sec"><h2>Explore themes</h2><p class="small">Groups of books the catalogue found by meaning, across shelves and subjects.</p><div class="themes">${h.themes.map(t=>`<button type="button" class="theme" data-link="theme" data-val="${t.id}"><b>${esc(t.name)}</b><span>${t.size.toLocaleString()} titles · ${esc(t.words.slice(0,3).join(", "))}</span></button>`).join("")}</div></section>`:""}
    <section class="home-sec"><h2>Browse by subject</h2><p class="small">Arranged by Dewey Decimal class, the way the shelves are.</p>${tree}
      <div class="ddc-grid">${kids.map(c=>`<div class="ddc"><button type="button" class="ddc-main" ${c.code.length<3?`data-browse="${c.code}"`:`data-link="ddc" data-val="${c.code}"`}><span class="num">${esc(c.num)}</span><span class="nm">${esc(c.name)}</span><span class="ct">${c.count.toLocaleString()} titles</span></button>${br&&br.code?`<button type="button" class="lnk small" data-link="ddc" data-val="${c.code}">See all</button>`:""}</div>`).join("")}</div>
      ${br&&br.code?`<p><button type="button" class="lnk" data-link="ddc" data-val="${br.code}">See all ${esc(br.path.at(-1)?.num||"")} ${esc(br.path.at(-1)?.name||"")} titles</button></p>`:""}
      ${S.cfg.ddc_notice?`<p class="small ddc-note">${esc(S.cfg.ddc_notice)}</p>`:""}
    </section>
  </div>`;
  syncURL();
}
function renderSearch(){
  if(isHome()&&S.view==="search"){renderHome();return}
  const d=S.data||{results:[],facets:{},understood:{f:{},kw:[]},count:0};
  const f=d.understood?.f||{}, kw=d.understood?.kw||[], note=d.note;
  const chips=[];
  if(kw.length)chips.push(`<span class="chip"><em>${f.cover?"Cover shows":"Topic"}</em> ${esc(kw.join(" "))}</span>`);
  for(const k of ["cover","isbn","similar","author","authors","about","theme","who","pub","subj","ddc","ymin","format","aud","lang","fic","avail"]){
    if(k==="ymin"&&!(f.ymin||f.ymax))continue; if(k!=="ymin"&&f[k]===undefined)continue;
    chips.push(`<span class="chip"><em>${FNAMES[k]}</em> ${esc(chipText(k,f,d.understood))}<button type="button" data-rm="${k}" aria-label="Remove ${FNAMES[k]} filter">×</button></span>`)}
  const labels={ddc:"Subject area (Dewey)",subj:"Subject",who:"Author",pub:"Publisher",format:"Format",aud:"Audience",lang:"Language",avail:"Availability"};
  const order=["avail","ddc","subj","who","pub","format","aud","lang"];
  const facetsHTML=order.filter(k=>(d.facets||{})[k]).map(k=>{const ent=d.facets[k];return !ent.length?"":`<section><h3>${labels[k]}</h3>${ent.map(([v,n,lbl])=>{const val=k==="avail"?true:v;const on=f[k]===val;
    return `<button type="button" class="${on?"on":""}" data-facet="${k}" data-val="${esc(v)}"><span>${esc(lbl||v)}</span><span>${n}</span></button>`}).join("")}</section>`}).join("");
  const rel=(d.related||[]).filter(r=>r.name);
  const ex=["novels for kids about friendship","something like Harry Potter","hindi books","space documentaries","books by harrari","black cover with a gold bird","indian fiction before 2000"];
  $("main").innerHTML=`${searchBox(ex)}
  <div class="wrap">
    ${d.error?`<div class="empty">${esc(d.error)}</div>`:`
    <div class="understood">
      ${note?note.kind==="auto"?`<div class="dym">Showing results for <b>${esc(note.corr)}</b><br><span class="alt">Search instead for <button type="button" data-q="${esc(note.raw)}" data-exact>${esc(note.raw)}</button></span></div>`:`<div class="dym">Did you mean <button type="button" data-q="${esc(note.corr)}"><i>${esc(note.corr)}</i></button>?</div>`:""}
      ${chips.length&&!(d.course&&d.course.strong)&&(S.q||Object.keys(S.facet).length)?`<div class="chips"><span class="lbl">${S.q?"Understood as":"Showing"}</span>${chips.join("")}</div>`:""}
      ${(d.choices||[]).length>1?`<div class="choices"><span class="lbl">Several authors match. Which one did you mean?</span>${d.choices.map(c=>`<button type="button" class="ch" data-link="who" data-val="${esc(c.name)}">${esc(c.name)} <span>${c.count}</span></button>`).join("")}</div>`:""}
      ${(d.intents||[]).length?`<div class="choices"><span class="lbl">Did you mean</span>${d.intents.map(x=>`<button type="button" class="ch" data-q="${esc(x.q)}">${esc(x.label)}</button>`).join("")}</div>`:""}
      ${d.course&&!d.course.strong&&d.course.courses.length?`<div class="choices"><span class="lbl">Course readings</span>${d.course.courses.slice(0,4).map(c=>`<button type="button" class="ch" data-coursego="${esc(c.code)}" data-coursename="${esc(c.name)}" data-fac="${esc(d.course.by&&d.course.by.faculty||"")}">${esc((c.code+" "+c.name).trim())}${c.faculty.length?` <span>${esc(c.faculty.join(", "))}</span>`:""}</button>`).join("")}</div>`:""}
      ${rel.length?`<div class="related"><span class="lbl">Also includes books shelved in related subject areas</span>${rel.map(r=>link("ddc",r.code,r.code+" "+r.name)).join("")}</div>`:""}
    </div>
    <div class="layout">
      <aside class="facets" aria-label="Refine results">${facetsHTML}</aside>
      <div style="min-width:0">
        ${d.course&&d.course.strong?courseHTML(d.course):`<div class="rtools"><div class="count">${d.count} ${d.count===1?"title":"titles"}${d.count>d.results.length?`, showing the first ${d.results.length}`:""}</div>
          ${d.results.length?`<div class="tools"><button type="button" class="btn small" data-share>Copy link</button>${exportMenu("api/export?"+searchParams())}${S.user?`<button type="button" class="btn small" data-savesearch>Save search</button>`:""}</div>`:""}</div>
        ${d.results.length?`<div class="results">${d.results.map(rowHTML).join("")}</div>`:`<div class="empty">No titles match yet. Try fewer words, or remove a filter above.</div>`}`}
      </div>
    </div>`}
  </div>`;
  syncURL();
}

/* ---------- account ---------- */
async function loadMe(){renderAccount();try{S.me=await api("api/me");}catch(e){S.me=null;S.user=null;toast(e.message)}renderAccount()}
async function loadHist(){if(S.hist||S.histLoading)return;S.histLoading=true;try{S.hist=await api("api/me/history")}catch(e){S.hist=[];toast(e.message)}S.histLoading=false;if(S.tab==="history")renderAccount()}
function renderAccount(){
  if(!S.me){$("main").innerHTML=`<section class="acct wrap"><p class="small">Loading your loans, holds and fines from the library system. This can take up to half a minute…</p></section>`;return}
  const {patron:P,loans,holds,fines}=S.me, history=S.hist||[], cur=S.cfg.currency||"";
  const owed=fines.filter(x=>!x.paid).reduce((a,x)=>a+x.amt,0), t0=today();
  const overdue=loans.filter(l=>l.due&&new Date(l.due)<t0).length;
  const T=(b,fallback)=>b?`<button type="button" class="t" data-open="${b.id}">${esc(b.t)}</button>`:esc(fallback||"Title not in the search index");
  const tabs=[["loans",`Checked out (${loans.length})`],["holds",`Holds (${holds.length})`],["fines","Fines"],["history","Reading history"]];
  let body="";
  if(S.tab==="loans")body=`<table class="tx"><thead><tr><th>Title</th><th>Due</th><th>Renewed</th><th></th></tr></thead><tbody>${loans.map(l=>{const due=new Date(l.due+"T00:00:00");const left=Math.round((due-t0)/day);
    return `<tr><td>${T(l.book)}<div class="small">${esc(l.book?.call||"")}</div></td><td class="num">${fmtD(l.due)}<br>${left<0?`<span class="pill warn">${-left} days overdue</span>`:`<span class="small">${left} days left</span>`}</td><td class="num">${l.renewals}</td><td><button type="button" class="btn small" data-renew="${l.checkout_id}">Renew</button></td></tr>`}).join("")||`<tr><td colspan="4" class="small">Nothing checked out.</td></tr>`}</tbody></table>`;
  if(S.tab==="holds")body=`<table class="tx"><thead><tr><th>Title</th><th>Status</th><th>Pickup</th><th></th></tr></thead><tbody>${holds.map(h=>`<tr><td>${T(h.book)}<div class="small">Placed ${fmtD(h.placed)}</div></td><td>${h.status==="Ready for pickup"?`<span class="pill ok">Ready${h.until?", collect by "+fmtD(h.until):""}</span>`:`<span class="small">${h.pos?`Number ${h.pos} in queue`:esc(h.status)}</span>`}</td><td>${esc(h.at||"")}</td><td><button type="button" class="btn small" data-cancel="${h.hold_id}">Cancel</button></td></tr>`).join("")||`<tr><td colspan="4" class="small">No holds.</td></tr>`}</tbody></table>`;
  if(S.tab==="fines")body=`<table class="tx"><thead><tr><th>Charge</th><th>Date</th><th>Amount</th><th>Status</th></tr></thead><tbody>${fines.map(x=>`<tr><td>${esc(x.desc)}</td><td class="num">${fmtD(x.date)}</td><td class="num">${cur}${x.amt}</td><td>${x.paid?`<span class="small">Paid</span>`:`<span class="pill warn">Due</span>`}</td></tr>`).join("")||`<tr><td colspan="4" class="small">No charges.</td></tr>`}</tbody></table><p class="small">Fines are paid at the circulation desk.</p>`;
  if(S.tab==="history"&&!S.hist){loadHist();body=`<p class="small">Loading your reading history from the library system…</p>`}
  else if(S.tab==="history")body=`<table class="tx"><thead><tr><th>Title</th><th>Borrowed</th><th>Returned</th></tr></thead><tbody>${history.map(h=>`<tr><td>${T(h.book)}<div class="small">${esc(h.book?.a||"")}</div></td><td class="num">${fmtD(h.out)}</td><td class="num">${fmtD(h.back)}</td></tr>`).join("")||`<tr><td colspan="3" class="small">No reading history yet.</td></tr>`}</tbody></table>`;
  $("main").innerHTML=`<section class="acct wrap">
    <h1>Hello, ${esc((P.name||"").split(" ")[0])}</h1><div class="small">Card ${esc(P.card)} · Home branch ${esc(P.branch||"")}${P.expires?" · Membership valid until "+fmtD(P.expires):""}</div>
    ${(S.me.unavailable||[]).length?`<p class="small" style="color:var(--warn)">Your ${S.me.unavailable.join(" and ")} could not be read from the library system just now. Ask at the circulation desk.</p>`:""}
    <div class="sum"><div><b>${loans.length}</b><span>Checked out${overdue?`, ${overdue} overdue`:""}</span></div><div><b>${holds.filter(h=>h.status==="Ready for pickup").length}</b><span>Holds ready to collect</span></div><div><b>${(S.me.unavailable||[]).includes("fines")?"–":cur+owed}</b><span>Fines owed</span></div></div>
    <div class="tabs" role="tablist">${tabs.map(([k,l])=>`<button type="button" role="tab" aria-selected="${S.tab===k}" class="${S.tab===k?"on":""}" data-tab="${k}">${l}</button>`).join("")}</div>
    <div class="txwrap">${body}</div></section>`;
  try{history.replaceState(null,"",pageURL("",""))}catch{}
}

/* ---------- overlays ---------- */
async function openRecord(id){S.open={loading:true,id};S.writing=false;renderPanel();try{S.open=await api("api/records/"+id)}catch(e){S.open=null;toast(e.message)}renderPanel()}
function renderPanel(){
  const o=$("overlay");
  if(S.login){o.innerHTML=`<div class="scrim" data-close></div><div class="modal"><form id="lf"><h2>Sign in</h2><p class="small" style="margin:0">Use your library card number and PIN or password.${S.cfg.demo?" Demo: LIB1024 / 1234.":""}</p>
    <label for="card">Library card number<input id="card" autocomplete="username" ${S.cfg.demo?'value="LIB1024"':""}></label><label for="pin">PIN or password<input id="pin" type="password" autocomplete="current-password"></label>
    ${S.loginErr?`<p class="err">${esc(S.loginErr)}</p>`:""}<div class="actions"><button class="btn primary" type="submit">Sign in</button><button class="btn" type="button" data-close>Cancel</button></div></form></div>`;setTimeout(()=>$(S.cfg.demo?"pin":"card")?.focus());return}
  if(S.addTo){const ml=Object.entries(myLists());o.innerHTML=`<div class="scrim" data-close></div><div class="modal"><form id="nlf"><h2>Add to a reading list</h2>
    ${ml.length?`<div class="pick">${ml.map(([id,x])=>`<button type="button" class="btn" data-tolist="${esc(id)}">${esc(x.name)}</button>`).join("")}</div><p class="small" style="margin:0">Or start a new list:</p>`:`<p class="small" style="margin:0">Reading lists are kept in this browser, and you can share any list by its link.</p>`}
    <label for="nlname">New list name<input id="nlname" placeholder="e.g. Thermodynamics, semester 3" ${ml.length?"":'value="My reading list"'}></label>
    <div class="actions"><button class="btn primary" type="submit">Create list and add</button><button class="btn" type="button" data-close>Cancel</button></div></form></div>`;setTimeout(()=>$("nlname")?.focus());return}
  if(S.img){const r=S.imgRes;o.innerHTML=`<div class="scrim" data-close></div><div class="modal"><form id="imf" class="imgbox"><h2>Search with a photo</h2>
    <p class="small" style="margin:0">Take or upload a photo of a book's barcode or cover. We read the ISBN or the title and look for it in the catalogue.</p>
    <label class="drop" id="drop" for="imgfile">${S.imgURL?`<img src="${S.imgURL}" alt="Your photo">`:`<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>`}<span>${S.imgURL?"Choose a different photo":"Tap to take a photo, or drop an image here"}</span><input id="imgfile" type="file" accept="image/*" capture="environment" hidden></label>
    ${r?`<p class="res-msg">${esc(r)}</p>`:""}
    <label for="isbnin" class="small">Or type the ISBN from the back cover<input id="isbnin" inputmode="numeric" placeholder="978…" style="display:block;width:100%;margin-top:4px;border:1px solid var(--line);border-radius:8px;padding:9px 10px;font-size:15px;background:var(--bg);color:var(--ink)"></label>
    <div class="actions"><button class="btn primary" type="submit">Find by ISBN</button><button class="btn" type="button" data-close>Close</button></div></form></div>`;
    const dz=$("drop");dz.addEventListener("dragover",e=>{e.preventDefault();dz.classList.add("over")});dz.addEventListener("dragleave",()=>dz.classList.remove("over"));dz.addEventListener("drop",e=>{e.preventDefault();dz.classList.remove("over");const f=e.dataTransfer.files[0];if(f)handleImage(f)});return}
  if(!S.open){o.innerHTML="";if(S.view!=="account")syncURL();return}
  const b=S.open;
  if(b.loading){o.innerHTML=`<div class="scrim" data-close></div><aside class="panel" aria-busy="true"><button type="button" class="close" data-close aria-label="Close">×</button><p class="small">Loading…</p></aside>`;return}
  const tagName={"250":"Edition","500":"General note","504":"Bibliography","505":"Contents","520":"Summary","521":"Audience","546":"Language","586":"Awards"};
  const sample=b.sources.some(s=>s.sample);
  o.innerHTML=`<div class="scrim" data-close></div><aside class="panel" role="dialog" aria-modal="true" aria-label="${esc(b.t)}">
    <button type="button" class="close" data-close aria-label="Close">×</button>
    <div class="rec-head">${cover(b,true)}<div style="min-width:0"><h2>${esc(b.t)}</h2>${b.st?`<p class="st">${esc(b.st)}</p>`:""}<div class="by">${(b.au&&b.au.length?b.au:[b.a]).map(a=>link("who",a)).join('<span class="sep">; </span>')}</div>${b.ser?`<div class="small" style="color:var(--accent);font-weight:600">${esc(b.ser[0])}${b.ser[1]?", book "+b.ser[1]:""}</div>`:""}<div class="small">${[b.y,b.f,b.l].filter(Boolean).map(esc).join(" · ")}${b.pub?` · ${link("pub",b.pub)}`:""}</div>
      <div class="actions"><button type="button" class="btn primary" data-hold="${b.id}">${b.av>0&&b.f!=="eBook"&&b.f!=="Audiobook"?"Reserve for pickup":b.av>0?"Borrow now":"Place hold"}</button><button type="button" class="btn" data-addlist="${b.id}">Add to list</button><button type="button" class="btn" data-share>Copy link</button></div></div></div>
    <div class="box"><h3>In plain words <span class="tag">${b.explain_ai?"Written by AI from the catalogue notes":"Generated from the catalogue notes"}</span></h3><ul class="plain">${b.explain.map(x=>`<li>${esc(x)}</li>`).join("")}</ul></div>
    ${b.cd?`<div class="box"><h3>What the cover looks like</h3><p style="margin:0;font-family:var(--body);font-size:16px">${esc(b.cd)}</p></div>`:""}
    ${(b.ddc_path&&b.ddc_path.length)||b.subj.length?`<div class="box"><h3>Subjects <span class="tag">Tap one to see every title on it</span></h3>
      ${b.ddc_path&&b.ddc_path.length?`<div class="crumbs">${b.ddc_path.map(p=>link("ddc",p.code,(p.num+" "+p.name).trim())).join(" › ")}${b.dd&&b.dd.length>3?` <span class="small">(${esc(b.dd)})</span>`:""}</div>`:""}
      ${b.subj.length?`<div class="tags">${b.subj.map(x=>link("subj",x)).join("")}</div>`:""}${b.theme?`<p class="small" style="margin:8px 0 0">Theme: ${link("theme",b.theme.id,b.theme.name)}</p>`:""}</div>`:""}
    ${b.cite?`<div class="box"><h3>Cite this <span class="tag">APA 7th edition</span></h3><p class="cite">${esc(b.cite)}</p><div class="tools"><button type="button" class="btn small" data-copycite>Copy citation</button><a class="btn small" href="api/export?fmt=ris&ids=${b.id}" download>RIS</a><a class="btn small" href="api/export?fmt=bib&ids=${b.id}" download>BibTeX</a>${b.opac?`<a class="btn small" href="${esc(b.opac)}" target="_blank" rel="noopener">Open in the library OPAC</a>`:""}</div><p class="small" style="margin:6px 0 0">Check the citation against your style guide before submitting.</p></div>`:""}
    <div class="box"><h3>Where to find it</h3><dl class="kv">${b.call?`<dt>Call number</dt><dd><span class="call">${esc(b.call)}</span></dd>`:""}${b.loc?`<dt>Location</dt><dd>${esc(b.loc)}</dd>`:""}<dt>Copies</dt><dd>${avail(b)||'<span class="small">No copies listed</span>'}</dd>${b.isbn?`<dt>ISBN</dt><dd style="font-family:var(--mono);font-size:13px">${esc(b.isbn)}</dd>`:""}</dl></div>
    ${b.sources.length?`<div class="box"><h3>Reviews <span class="tag">Looked up by ISBN ${esc(b.isbn)}</span></h3>
      <div class="srcs">${b.sources.map(x=>`<div class="src"><div><b>${esc(x.name)}</b><span class="small">${esc(x.how)}${x.count?` · ${x.count} ratings`:""}</span></div><div class="rating">${starsHTML(x.r)}${x.r!=null?`<span class="rv">${Number(x.r).toFixed(1)}</span>`:""}</div><a href="${esc(x.url)}" target="_blank" rel="noopener">Read reviews</a></div>`).join("")}</div>
      ${sample?`<p class="small" style="margin:8px 0 0">Demo mode shows sample ratings. The “Read reviews” links are live.</p>`:""}</div>`:""}
    <div class="box"><h3>Reviews from our members</h3><div class="members" style="margin:0;padding:0;border:0">
      ${b.member_reviews.map(m=>`<blockquote class="mrev"><div>${starsHTML(m.r)} <span class="small">${esc(m.who)} · ${fmtD(m.when)}</span></div><p>${esc(m.text)}</p>${m.pending?`<span class="small">Awaiting staff approval</span>`:""}</blockquote>`).join("")||`<p class="small" style="margin:0">No member reviews yet.</p>`}
      ${S.user?(S.writing?`<form id="rf" class="rform"><label for="rstars">Your rating</label><select id="rstars">${[5,4,3,2,1].map(n=>`<option value="${n}">${"★".repeat(n)} ${n}</option>`).join("")}</select><label for="rtext">Your review</label><textarea id="rtext" rows="3" required placeholder="What did you think?"></textarea><div class="actions"><button class="btn primary" type="submit">Submit review</button><button class="btn" type="button" data-wcancel>Cancel</button></div></form>`:`<div><button type="button" class="btn small" data-write>Write a review</button></div>`):`<div><button type="button" class="btn small" data-login>Sign in to write a review</button></div>`}
    </div></div>
    ${b.recs.length?`<div class="box"><h3>You might also like</h3>${b.recs.map(r=>`<div class="recrow"><div class="rech"><b>${esc(r.h)}</b>${r.sub?`<span class="small">${esc(r.sub)}</span>`:""}</div><div class="shelf">${r.items.map(x=>`<button type="button" ${x.id===b.id?'disabled aria-current="true"':`data-open="${x.id}"`} class="${x.id===b.id?"cur":""}">${cover(x)}<span class="bt">${esc(x.t)}</span><span class="bn">${esc(x.note||"")}</span></button>`).join("")}</div></div>`).join("")}</div>`:""}
    ${Object.keys(b.n).length||b.subj.length?`<div class="box"><h3>Catalogue notes, as recorded <span class="tag">MARC</span></h3><table class="marc"><tbody>${Object.entries(b.n).sort().map(([k,v])=>`<tr><td>${k}</td><td><span class="small">${tagName[k]||"Note"}</span><br>${esc(v)}</td></tr>`).join("")}${b.subj.length?`<tr><td>650</td><td><span class="small">Subjects</span><br>${b.subj.map(esc).join(" · ")}</td></tr>`:""}</tbody></table></div>`:""}
  </aside>`;
  o.querySelector(".close").focus();
  syncURL();
}
async function handleImage(file){
  if(!file||!file.type.startsWith("image/"))return;
  if(S.imgURL)URL.revokeObjectURL(S.imgURL);S.imgURL=URL.createObjectURL(file);S.imgRes="Reading the photo…";renderPanel();
  const fd=new FormData();fd.append("file",file);
  try{const r=await api("api/photo",{method:"POST",body:fd});
    if(r.match){closeImg();openRecord(r.match);toast("Found it");return}
    S.imgRes=r.message||"We couldn't match that photo.";}catch(e){S.imgRes=e.message}
  renderPanel();
}
async function findISBN(raw){const i=String(raw).replace(/[^0-9xX]/g,"");if(i.length!==10&&i.length!==13){S.imgRes="An ISBN has 10 or 13 digits. Check the number and try again.";renderPanel();return}
  const r=await api("api/search?q="+i);if(r.results.length){closeImg();openRecord(r.results[0].id);return}
  S.imgRes=`ISBN ${i} isn't in our catalogue. You could ask the library to buy it.`;renderPanel()}
function closeImg(){S.img=false;S.imgRes=null;if(S.imgURL)URL.revokeObjectURL(S.imgURL);S.imgURL=null}

function renderWho(){$("who").innerHTML=(S.cfg.courses?`<button type="button" class="btn ghost" data-coursepage="1">Course readings</button>`:"")+(S.cfg.ask?`<button type="button" class="btn ghost" data-askpage>Ask the librarian</button>`:"")+(S.user?`<button type="button" class="btn" data-acct>My account</button><button type="button" class="btn" data-logout>Sign out</button>`:`<button type="button" class="btn primary" data-login>Sign in</button>`)}
function render(){renderWho();if(S.view==="account"&&S.user)renderAccount();else if(S.view==="list")renderList();else if(S.view==="courses")renderCourses();else if(S.view==="ask")renderAsk();else renderSearch();renderPanel()}
function newSearch(q){S.q=q;S.rm.clear();S.facet={};S.view="search";doSearch()}


/* ---------- v5: course readings ---------- */
const POL={CR:["Course Reserve","not for issue","cr"],SL:["Short Loan","3-day issue","sl"],REF:["Reference","in the library","ref"]};
function polHTML(copies){return Object.entries(copies||{}).map(([p,n])=>{const x=POL[p]||[p,"",""];return`<span class="pol ${x[2]}" title="${esc(x[1])}">${n} ${esc(x[0])}${x[1]?` <i>(${esc(x[1])})</i>`:""}</span>`}).join("")}
function courseItem(e){const b=e.card;const head=`<span class="kind ${e.kind==="Textbook"?"tb":"rf"}">${esc(e.kind)}</span>`;
  if(b)return`<div class="citem">${rowHTML({...b,why:null})}<div class="cmeta">${head}${polHTML(e.copies)}${e.ebook?`<a href="${esc(e.ebook)}" target="_blank" rel="noopener">e-book</a>`:""}</div></div>`;
  return`<div class="citem plainitem"><div><h4>${esc(e.title)}</h4><div class="meta">${esc(e.author)}${e.publisher?" · "+esc(e.publisher):""}${e.year?" · "+esc(e.year):""}${e.isbn?" · ISBN "+esc(e.isbn):""}</div>
    <div class="small">Not found in the catalogue copy. Ask at the circulation desk.</div></div><div class="side">${e.call?`<span class="call">${esc(e.call)}</span>`:""}</div><div class="cmeta">${head}${polHTML(e.copies)}</div></div>`}
function courseHTML(c,noHead){const groups={};for(const e of c.items){const k=(e.code||"")+"|"+e.course;(groups[k]=groups[k]||[]).push(e)}
  return`<div class="course">${noHead?"":`<div class="ch-head"><div><span class="lbl">Course readings · ${esc(c.semester)}</span><h2>${esc(c.title)}</h2></div>
    <div class="tools"><button type="button" class="btn small" data-coursepage="1" data-cfac="${esc(c.by&&c.by.faculty||"")}" data-ccode="${esc(c.by&&c.by.code||"")}" data-cname="${esc(c.by&&c.by.course||"")}">Open in Course readings</button></div></div>`}
    ${c.all?`<p class="small">Pick a course:</p><div class="clist">${c.courses.map(x=>`<button type="button" class="ch" data-coursego="${esc(x.code)}" data-coursename="${esc(x.name)}">${esc((x.code+" "+x.name).trim())} <span>${esc(x.faculty.join(", "))}</span></button>`).join("")}</div>`:
    Object.values(groups).map(g=>`<section class="cgroup">${Object.keys(groups).length===1&&!noHead&&(g[0].code+" "+g[0].course).trim()===c.title?`<p class="small" style="margin:0 0 6px">${esc(g[0].faculty.join(", "))}</p>`:`<h3>${esc((g[0].code+" "+g[0].course).trim()||"Other readings")}${g[0].faculty.length?` <span class="small">${esc(g[0].faculty.join(", "))}</span>`:""}</h3>`}${g.map(courseItem).join("")}</section>`).join("")}
    <p class="small">Course Reserve copies are read in the library and are not issued. Short Loan copies are issued for 3 days. Shelf status is live from the catalogue.</p></div>`}
function courseParams(forURL){const C=S.cr||{},p=new URLSearchParams();if(forURL)p.set("courses","1");if(C.sem&&!C.isCurrent)p.set("sem",C.sem);for(const k of ["faculty","course","code","q"])if(C[k])p.set(k,C[k]);return p}
async function openCourses(sel={}){S.view="courses";S.open=null;S.cr={...(S.cr||{}),...sel,loading:true};renderCourses();
  const p=courseParams(false);try{const r=await api("api/courses?"+p);S.cr={...S.cr,...r,loading:false,isCurrent:(r.semesters.find(x=>x.id===r.sem)||{}).current}}catch(e){S.cr={...S.cr,loading:false,error:e.message}}renderCourses()}
function renderCourses(){const C=S.cr||{},P=C.pickers||{courses:[],faculty:[],codes:[]};
  const names=[...new Set(P.courses.filter(c=>!C.faculty||c.faculty.includes(C.faculty)).map(c=>c.name))].sort();
  const codes=P.courses.filter(c=>c.code&&(!C.faculty||c.faculty.includes(C.faculty))&&(!C.course||c.name===C.course)).map(c=>c.code);
  const opt=(v,cur,label)=>`<option value="${esc(v)}" ${v===cur?"selected":""}>${esc(label??v)}</option>`;
  const any=C.faculty||C.course||C.code||C.q;
  $("main").innerHTML=`<section class="wrap crpage"><h1>Course readings</h1>
    <p class="lede">Books recommended by faculty for this semester's courses. <b class="cr">Course Reserve (CR)</b>: not for issue. <b class="sl">Short Loan (SL)</b>: 3-day issue.</p>
    <form id="crf" class="crform">
      ${C.semesters&&C.semesters.length>1?`<label>Semester<select id="crsem">${C.semesters.map(x=>opt(String(x.id),String(C.sem),x.label+(x.current?" (current)":""))).join("")}</select></label>`:""}
      <label>Faculty name<select id="crfac"><option value="">All</option>${P.faculty.map(x=>opt(x,C.faculty)).join("")}</select></label>
      <label>Course name<select id="crname"><option value="">All</option>${names.map(x=>opt(x,C.course)).join("")}</select></label>
      <label>Course code<select id="crcode"><option value="">All</option>${[...new Set(codes)].sort().map(x=>opt(x,C.code)).join("")}</select></label>
      <label>Search<input id="crq" value="${esc(C.q||"")}" placeholder="Title, author, ISBN…"></label>
      <div class="actions"><button class="btn primary" type="submit">Search</button><button class="btn" type="button" data-crreset>Reset</button></div></form>
    ${C.label?`<p class="small">Suggested text and reference books for <b>${esc(C.label)}</b>${C.items&&any?` · ${C.items.length} ${C.items.length===1?"title":"titles"}`:""}</p>`:""}
    ${C.loading?`<p class="small">Loading…</p>`:C.error?`<div class="empty">${esc(C.error)}</div>`:!C.semesters||!C.semesters.length?`<div class="empty">No course readings have been uploaded yet.</div>`:
      !any?`<div class="clist">${P.courses.map(x=>`<button type="button" class="ch" data-coursego="${esc(x.code)}" data-coursename="${esc(x.name)}">${esc((x.code+" "+x.name).trim())} <span>${esc(x.faculty.join(", "))} · ${x.titles} titles</span></button>`).join("")}</div>`:
      `<div class="tools"><a class="btn small" href="api/courses/export?${courseParams(false)}&fmt=csv" download>Export to CSV</a><a class="btn small" href="api/courses/export?${courseParams(false)}&fmt=xlsx" download>Excel</a><button type="button" class="btn small" data-share>Copy link</button></div>
      ${C.items.length?courseHTML({items:C.items},true):`<div class="empty">No titles match. Try another course or clear the search.</div>`}`}
  </section>`;syncURL()}

/* ---------- v5: Ask the librarian ---------- */
function chatMsgs(){try{return JSON.parse(sessionStorage.getItem("chat")||"[]")}catch{return []}}
function setChat(m){S.chat=m;try{sessionStorage.setItem("chat",JSON.stringify(m.slice(-12)))}catch{}}
function renderAsk(){const m=S.chat||chatMsgs();S.chat=m;
  const ex=["I'm in 2nd year and want to start machine learning with Python","An easy introduction to Indian constitutional history","Readings for CE 404","Books on Gandhi's ideas of nonviolence"];
  $("main").innerHTML=`<section class="wrap ask"><h1>Ask the librarian</h1>
    <p class="lede">Tell us what you need in your own words: your course, your level, what it's for. The answers come only from books in this library's catalogue.</p>
    <div class="chat" id="chat" aria-live="polite">${m.length?m.map(x=>x.role==="user"?`<div class="msg me">${esc(x.content)}</div>`:
      `<div class="msg bot"><p>${esc(x.content)}</p>${(x.picks||[]).length?`<div class="results">${x.picks.map(rowHTML).join("")}</div>`:""}${x.try?`<p class="small">Try searching for <button type="button" class="lnk" data-q="${esc(x.try)}">${esc(x.try)}</button></p>`:""}</div>`).join(""):
      `<div class="examples"><span>Try</span>${ex.map(e=>`<button type="button" class="ex" data-askex="${esc(e)}">${esc(e)}</button>`).join("")}</div>`}
      ${S.asking?`<div class="msg bot"><p class="small">Looking through the catalogue…</p></div>`:""}</div>
    <form class="q" id="askf"><input id="askq" aria-label="Your question" autocomplete="off" placeholder="Ask a question" ${S.asking?"disabled":""}><button class="btn primary" type="submit" ${S.asking?"disabled":""}>Ask</button></form>
    <p class="small">Answers are written by AI (Claude) from the catalogue records and can be wrong, so check the title page. Your question is sent to Anthropic without your name or library card. ${m.length?`<button type="button" class="lnk" data-chatclear>Start over</button>`:""}</p>
  </section>`;setTimeout(()=>{$("askq")?.focus();const c=$("chat");if(c)c.lastElementChild?.scrollIntoView({block:"nearest"})});syncURL()}
async function askQ(q){q=(q||"").trim();if(!q||S.asking)return;const m=[...(S.chat||[]),{role:"user",content:q}];setChat(m);S.asking=true;renderAsk();
  try{const r=await api("api/ask",{method:"POST",body:{messages:m.map(x=>({role:x.role,content:x.content}))}});
    setChat([...m,{role:"assistant",content:r.reply,picks:r.picks,try:r.try_search}])}
  catch(e){setChat([...m,{role:"assistant",content:e.message,picks:[]}])}
  S.asking=false;renderAsk()}

/* ---------- events ---------- */
document.addEventListener("change",e=>{if(e.target.id==="imgfile")handleImage(e.target.files[0]);
  if(["crfac","crname","crcode","crsem"].includes(e.target.id)){const sem=$("crsem")?.value;const sel={sem:sem?+sem:S.cr?.sem,faculty:$("crfac").value,course:$("crname").value,code:$("crcode").value,q:$("crq").value.trim()};
    if(e.target.id==="crfac"){sel.course="";sel.code=""}if(e.target.id==="crname")sel.code="";if(e.target.id==="crsem"){sel.faculty="";sel.course="";sel.code=""}openCourses(sel)}});
document.addEventListener("submit",async e=>{e.preventDefault();const id=e.target.id;
  try{
    if(id==="qf"){newSearch($("q").value);return}
    if(id==="askf"){askQ($("askq").value);return}
    if(id==="crf"){const sem=$("crsem")?.value;openCourses({sem:sem?+sem:S.cr?.sem,faculty:$("crfac").value,course:$("crname").value,code:$("crcode").value,q:$("crq").value.trim()});return}
    if(id==="nlf"){const name=$("nlname").value.trim()||"My reading list";const L=await api("api/lists",{method:"POST",body:{name,biblio_id:S.addTo}});const m=myLists();m[L.id]={key:L.key,name:L.name};setMyLists(m);S.addTo=null;renderPanel();toast(`Added to “${L.name}”. Find it on the home page.`);return}
    if(id==="imf"){await findISBN($("isbnin").value);return}
    if(id==="lf"){const p=await api("api/login",{method:"POST",body:{card:$("card").value,pin:$("pin").value}});S.user=p;S.login=false;S.loginErr="";
      S.picks=null;S.saved=null;
      if(!S.open){S.view="account";S.me=null;S.hist=null;render();loadMe()}else{renderWho();renderPanel()}toast("Signed in");return}
    if(id==="rf"){await api(`api/records/${S.open.id}/reviews`,{method:"POST",body:{rating:+$("rstars").value,text:$("rtext").value}});S.writing=false;await openRecord(S.open.id);toast("Thanks. Your review will appear once staff approve it.");return}
  }catch(err){if(id==="lf"){S.loginErr=err.message;renderPanel()}else toast(err.message)}
});
document.addEventListener("click",e=>{document.querySelectorAll("details.menu[open]").forEach(d=>{if(!d.contains(e.target)||e.target.closest(".menu-body a"))d.removeAttribute("open")})});
document.addEventListener("click",async e=>{const t=e.target.closest("button,[data-close]");if(!t)return;const ds=t.dataset;
  try{
    if(t.id==="home"){S.view="search";S.cr=null;S.list=null;S.open=null;S.q="";S.facet={};S.rm.clear();S.browse=null;renderPanel();doSearch();return}
    if(ds.link){goLink(ds.link,ds.val);return}
    if(ds.coursego!==undefined){if(ds.coursego){S.q="";S.rm.clear();S.facet={course_code:ds.coursego};S.view="search";S.open=null;renderPanel();doSearch()}else openCourses({course:ds.coursename,code:"",faculty:"",q:""});window.scrollTo(0,0);return}
    if(ds.coursepage!==undefined){openCourses({faculty:ds.cfac||"",code:ds.ccode||"",course:ds.cname||"",q:""});window.scrollTo(0,0);return}
    if(ds.crreset!==undefined){openCourses({faculty:"",course:"",code:"",q:""});return}
    if(ds.askpage!==undefined){S.view="ask";S.open=null;renderPanel();renderAsk();return}
    if(ds.askex!==undefined){askQ(ds.askex);return}
    if(ds.chatclear!==undefined){setChat([]);renderAsk();return}
    if(ds.browse!==undefined){if(ds.browse)openBrowse(ds.browse);else{S.browse=null;renderHome()}return}
    if(ds.ex!==undefined){newSearch(ds.ex);return}
    if(ds.q!==undefined){newSearch(ds.q);return}
    if(ds.rm){if(S.facet[ds.rm]!==undefined)delete S.facet[ds.rm];else S.rm.add(ds.rm);doSearch();return}
    if(ds.facet){const val=ds.facet==="avail"?true:ds.val;if(S.facet[ds.facet]===val)delete S.facet[ds.facet];else{S.facet[ds.facet]=val;S.rm.delete(ds.facet)}doSearch();return}
    if(ds.open){openRecord(+ds.open);return}
    if(ds.close!==undefined){if(S.addTo)S.addTo=null;else if(S.img)closeImg();else{S.open=null;S.login=false}renderPanel();return}
    if(ds.share!==undefined){copyText(currentURL(),"Link copied. Anyone on the campus network can open it.");return}
    if(ds.copycite!==undefined){copyText(S.open.cite,"Citation copied");return}
    if(ds.addlist){S.addTo=+ds.addlist;renderPanel();return}
    if(ds.tolist){await addToList(ds.tolist,S.addTo);return}
    if(ds.showlist){openList(ds.showlist);window.scrollTo(0,0);return}
    if(ds.gohome!==undefined){S.view="search";S.list=null;S.q="";S.facet={};S.rm.clear();doSearch();return}
    if(ds.unlist){const m=myLists();S.list={...await api("api/lists/"+S.list.id,{method:"POST",body:{key:m[S.list.id].key,remove:+ds.unlist}})};renderList();return}
    if(ds.editlist!==undefined){const name=prompt("List name",S.list.name);if(name===null)return;const note=prompt("A note shown above the list (optional)",S.list.note||"");const m=myLists();S.list=await api("api/lists/"+S.list.id,{method:"POST",body:{key:m[S.list.id].key,name,note:note??S.list.note}});m[S.list.id].name=S.list.name;setMyLists(m);renderList();return}
    if(ds.dellist!==undefined){if(!confirm("Delete this list? Its link will stop working."))return;const m=myLists();await api("api/lists/"+S.list.id,{method:"POST",body:{key:m[S.list.id].key,delete:true}});delete m[S.list.id];setMyLists(m);S.list=null;S.view="search";S.q="";S.facet={};S.rm.clear();doSearch();toast("List deleted");return}
    if(ds.savesearch!==undefined){const p=Object.fromEntries(searchParams());const name=prompt("Name this search",S.q||Object.values(S.facet).join(", ")||"My search");if(!name)return;
      const alert=S.cfg.alerts?confirm("Email me when new titles match this search?"):false;const r=await api("api/me/saved",{method:"POST",body:{name,params:p,alert}});S.saved=null;
      toast(r.email?"Saved. We'll email you about new titles.":"Saved. New titles will show on the home page.");return}
    if(ds.runsaved!==undefined){runSaved(S.saved[+ds.runsaved]);return}
    if(ds.delsaved){if(!confirm("Delete this saved search?"))return;await api("api/me/saved/"+ds.delsaved,{method:"DELETE"});S.saved=S.saved.filter(x=>x.id!==+ds.delsaved);renderHome();return}
    if(ds.img!==undefined){S.img=true;S.imgRes=null;renderPanel();return}
    if(ds.login!==undefined){S.login=true;S.loginErr="";renderPanel();return}
    if(ds.logout!==undefined){await api("api/logout",{method:"POST"});S.user=null;S.me=null;S.hist=null;S.picks=null;S.saved=null;S.view="search";render();toast("Signed out");return}
    if(ds.acct!==undefined){S.view="account";S.open=null;renderPanel();loadMe();return}
    if(ds.tab){S.tab=ds.tab;renderAccount();return}
    if(ds.renew){const r=await api("api/me/renew/"+ds.renew,{method:"POST"});await loadMe();toast("Renewed. New due date "+fmtD(r.due));return}
    if(ds.cancel){await api("api/me/holds/"+ds.cancel,{method:"DELETE"});await loadMe();toast("Hold cancelled");return}
    if(ds.hold){if(!S.user){S.login=true;renderPanel();return}await api("api/me/holds",{method:"POST",body:{biblio_id:+ds.hold}});toast(S.open.av>0?"Reserved. We'll tell you when it's ready.":"Hold placed. We'll tell you when it's your turn.");return}
    if(ds.write!==undefined){S.writing=true;renderPanel();setTimeout(()=>$("rtext")?.focus());return}
    if(ds.wcancel!==undefined){S.writing=false;renderPanel();return}
  }catch(err){toast(err.message)}
});
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&(S.open||S.login||S.img||S.addTo)){if(S.addTo)S.addTo=null;else if(S.img)closeImg();else{S.open=null;S.login=false}renderPanel()}});

(async function init(){
  try{S.cfg=await api("api/config")}catch{S.cfg={}}
  $("libname").textContent=S.cfg.library||"";$("demo").hidden=!S.cfg.demo;document.title="Catalogue Discover · "+(S.cfg.library||"");
  try{const r=await fetch("api/me/who",{credentials:"same-origin"});if(r.ok){S.user=await r.json()}}catch{}
  const u=new URLSearchParams(location.search),h=new URLSearchParams(location.hash.slice(1));
  renderWho();
  if(u.get("list")){await openList(u.get("list"))}
  else if(u.get("courses")){await openCourses({sem:u.get("sem")?+u.get("sem"):undefined,faculty:u.get("faculty")||"",course:u.get("course")||"",code:u.get("code")||"",q:u.get("q")||""})}
  else if(u.get("ask")&&S.cfg.ask){S.view="ask";renderAsk()}
  else{S.q=u.get("q")||"";S.rm=new Set((u.get("rm")||"").split(",").filter(Boolean));for(const k of FACET_KEYS)if(u.get(k))S.facet[k]=k==="avail"?true:u.get(k);await doSearch()}
  if(/^\d+$/.test(h.get("b")||""))openRecord(+h.get("b"));
})();
