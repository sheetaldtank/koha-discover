"""Connections to the library system.

KohaClient talks to Koha's REST API (Koha 23.05 or later recommended).
DemoKoha serves the built-in sample catalogue and one sample patron, so the app runs without Koha.
Both expose the same methods.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from datetime import date, datetime, timedelta
from pathlib import Path

import httpx

from .config import settings

log = logging.getLogger("discover.koha")


def _fatal(e) -> bool:
    """Errors that splitting a page cannot get round: no permission, or Koha unreachable after retries."""
    return "refused access" in str(e) or "could not be reached" in str(e)

SAMPLE = json.loads((Path(__file__).parent / "sample_data.json").read_text(encoding="utf-8"))


class KohaError(Exception):
    def __init__(self, message: str, status: int = 502):
        super().__init__(message)
        self.status = status


def _d(s):
    if not s:
        return None
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00")).date().isoformat()
    except ValueError:
        return str(s)[:10]


def _marc_biblionumber(m: dict):
    """Koha keeps the record number in 999$c (MARC 21)."""
    for f in m.get("fields", []):
        if "999" in f:
            for sf in f["999"].get("subfields", []):
                if "c" in sf and str(sf["c"]).strip().isdigit():
                    return int(sf["c"])
    return None


# --------------------------------------------------------------------------- Koha
class KohaClient:
    def __init__(self):
        if not settings.koha_url:
            raise RuntimeError("KOHA_URL is not set")
        self.base = settings.koha_url + "/api/v1"
        self._token = None
        self._token_exp = 0.0
        self._libs: dict[str, str] | None = None
        self._item_biblio: dict[int, int] = {}
        self._embed_items: bool | None = None
        self.local_item_biblio = None  # set by the app: looks an item up in the synced copy, no Koha request
        self.http = httpx.AsyncClient(timeout=180, verify=settings.koha_verify_tls)

    async def _auth_header(self):
        if settings.koha_auth == "basic":
            import base64
            cred = base64.b64encode(f"{settings.koha_api_user}:{settings.koha_api_password}".encode()).decode()
            return {"Authorization": f"Basic {cred}"}
        if not self._token or time.time() > self._token_exp - 60:
            r = await self.http.post(self.base + "/oauth/token", data={
                "grant_type": "client_credentials", "client_id": settings.koha_client_id,
                "client_secret": settings.koha_client_secret})
            if r.status_code != 200:
                raise KohaError(f"Koha refused the API client credentials ({r.status_code}). Check KOHA_CLIENT_ID and KOHA_CLIENT_SECRET.")
            j = r.json()
            self._token, self._token_exp = j["access_token"], time.time() + int(j.get("expires_in", 3600))
        return {"Authorization": f"Bearer {self._token}"}

    # Waits (seconds) before retrying a read when Koha drops the connection, times out or is briefly overloaded.
    RETRY_WAITS = (5, 15, 30, 60, 120)
    LOAN_PAGE = 1000  # loans read per request

    async def _req(self, method, path, *, accept="application/json", **kw):
        extra = kw.pop("headers", {})
        waits = self.RETRY_WAITS if method == "GET" else ()  # never repeat a hold or renewal
        for attempt in range(len(waits) + 1):
            headers = {"Accept": accept, **(await self._auth_header()), **extra}
            try:
                r = await self.http.request(method, self.base + path, headers=headers, **kw)
            except httpx.TransportError as e:  # disconnected, timed out, connection refused
                if attempt == len(waits):
                    raise KohaError(f"Koha could not be reached for {path} after {attempt + 1} tries ({type(e).__name__}). "
                                    "Run the same command again later: it carries on from where it stopped.", 502)
                log.warning("Koha connection problem (%s) on %s; trying again in %ds.", type(e).__name__, path, waits[attempt])
                await asyncio.sleep(waits[attempt])
                continue
            if r.status_code in (502, 503, 504) and attempt < len(waits):
                log.warning("Koha busy (%d) on %s; trying again in %ds.", r.status_code, path, waits[attempt])
                await asyncio.sleep(waits[attempt])
                continue
            break
        if r.status_code in (401, 403):
            raise KohaError(f"Koha refused access to {path} ({r.status_code}). Check the API account's login and permissions.", 502)
        if r.status_code >= 400:
            try:
                msg = r.json().get("error") or r.text
            except ValueError:
                msg = r.text
            raise KohaError(f"Koha {method} {path} failed: {msg}", 400 if r.status_code < 500 else 502)
        return r

    async def _pages(self, path, params=None, per_page=100, accept="application/json", headers=None):
        """Yield (response, rows) page by page. Stops on an empty page or once X-Total-Count rows are read,
        so it also works when Koha caps the page size below what was asked."""
        page, seen = 1, 0
        while True:
            r = await self._req("GET", path, accept=accept, headers=headers or {},
                                params={**(params or {}), "_page": page, "_per_page": per_page})
            rows = r.json()
            if not rows:
                return
            yield r, rows
            seen += len(rows)
            total = r.headers.get("x-total-count")
            if (total and total.isdigit() and seen >= int(total)) or (not total and len(rows) < per_page):
                return
            page += 1

    async def _all(self, path, params=None, per_page=100, headers=None):
        out = []
        async for _, rows in self._pages(path, params, per_page, headers=headers):
            out += rows
        return out

    # ---- catalogue
    async def _marc_page(self, page: int, per_page: int):
        """One page of MARC-in-JSON records as [(biblio_id, marc)], plus Koha's total record count."""
        params = {"_order_by": "+biblio_id", "_page": page, "_per_page": per_page}
        r = await self._req("GET", "/biblios", accept="application/marc-in-json", params=params)
        recs = r.json()
        ids = [_marc_biblionumber(m) for m in recs]
        if None in ids:  # no 999$c in these records: match them to the same page in JSON
            ids = [b.get("biblio_id") for b in (await self._req("GET", "/biblios", params=params)).json()]
        total = r.headers.get("x-total-count")
        return list(zip(ids, recs)), int(total) if total and total.isdigit() else None

    async def _marc_page_safe(self, page: int, per_page: int, skipped: list):
        """Like _marc_page, but if Koha fails on the page (usually one damaged record), retry once,
        then read it in smaller pieces and skip only the records Koha can't return."""
        for attempt in range(2):
            try:
                return await self._marc_page(page, per_page)
            except KohaError as e:
                if _fatal(e):
                    raise
                if attempt == 0:
                    await asyncio.sleep(5)
        if per_page == 1:
            try:
                j = (await self._req("GET", "/biblios", params={"_order_by": "+biblio_id", "_page": page, "_per_page": 1})).json()
                skipped.append(j[0]["biblio_id"] if j else f"position {page}")
            except KohaError:
                skipped.append(f"position {page}")
            return [], None
        small = 10 if per_page % 10 == 0 and per_page > 10 else 1
        out, total = [], None
        first = (page - 1) * per_page // small + 1
        for sub in range(first, first + per_page // small):
            rows, t = await self._marc_page_safe(sub, small, skipped)
            out += rows
            total = total or t
            if t is not None and sub * small >= t:
                break
        return out, total

    async def iter_biblio_pages(self, per_page=250, start_page=1, skipped: list | None = None):
        """Yield (page number, [(biblio_id, marc)]) for the whole catalogue, in record-number order."""
        skipped = skipped if skipped is not None else []
        page = start_page
        while True:
            rows, total = await self._marc_page_safe(page, per_page, skipped)
            if not rows and (total is None or (page - 1) * per_page >= total):
                return
            if page == start_page and not skipped and total and len(rows) < min(per_page, total):
                per_page = len(rows)  # Koha capped the page size; page numbers follow the smaller size
            yield page, rows
            if total is not None and page * per_page >= total:
                return
            if total is None and len(rows) < per_page and not skipped:
                return
            page += 1

    async def iter_biblios(self, per_page=250):
        async for _, rows in self.iter_biblio_pages(per_page):
            for bid, m in rows:
                yield bid, m

    async def libraries(self):
        if self._libs is None:
            libs = await self._all("/libraries")
            self._libs = {x["library_id"]: x["name"] for x in libs}
        return self._libs

    @staticmethod
    def _summarise(items, libs) -> dict:
        usable = [i for i in items if not i.get("withdrawn") and not i.get("lost_status")]
        free = [i for i in usable if not i.get("checked_out_date") and not i.get("not_for_loan_status")]
        first = (free or usable or [{}])[0]
        acq = max((str(i.get("acquisition_date") or "")[:10] for i in usable), default="")
        last = max((str(i.get("last_checkout_date") or "")[:10] for i in usable), default="")
        return {"av": len(free), "tot": len(usable), "call": first.get("callnumber") or "",
                "uses": sum(int(i.get("checkouts_count") or 0) for i in usable), "lastb": last,
                "loc": " · ".join(x for x in [libs.get(first.get("holding_library_id"), ""), first.get("location") or ""] if x),
                **({"acq": acq} if re.fullmatch(r"(19|20)\d\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])", acq) else {})}

    async def availability(self, biblio_id: int) -> dict:
        items = await self._all(f"/biblios/{biblio_id}/items")
        return self._summarise(items, await self.libraries())

    # Items whose replacement price date is impossible (month or day 00) make Koha reject a whole page of items,
    # so the bulk read leaves them out. Fix them in Koha to include them (see docs/koha-setup.md).
    ITEM_FILTER = json.dumps({"-or": [{"replacement_price_date": None},
                                      {"replacement_price_date": {"-not_like": "%-00%"}}]})

    async def _item_page(self, page, per_page, q, skipped):
        params = {"_order_by": "+item_id", "_page": page, "_per_page": per_page, **({"q": q} if q else {})}
        try:
            r = await self._req("GET", "/items", params=params)
            total = r.headers.get("x-total-count")
            return r.json(), int(total) if total and total.isdigit() else None
        except KohaError as e:
            if _fatal(e) or per_page <= 10:
                if _fatal(e):
                    raise
                skipped[0] += per_page
                return [], None
        out, total = [], None  # read this page in tenths and skip only the parts Koha rejects
        small = per_page // 10
        first = (page - 1) * 10 + 1
        for sub in range(first, first + 10):
            rows, t = await self._item_page(sub, small, q, skipped)
            out += rows
            total = total or t
            if t is not None and sub * small >= t:
                break
        return out, total

    async def all_availability(self, per_page=1000, progress=None) -> dict[int, dict]:
        """Availability for every title, read from Koha's item list in large pages."""
        libs = await self.libraries()
        q = self.ITEM_FILTER
        try:
            await self._req("GET", "/items", params={"_per_page": 1, "q": q})
        except KohaError as e:
            if _fatal(e):
                raise
            q = None  # this Koha doesn't take the filter
        by_bib: dict[int, list] = {}
        n, page, skipped, known = 0, 1, [0], None
        while True:
            rows, total = await self._item_page(page, per_page, q, skipped)
            known = total or known
            for i in rows:
                by_bib.setdefault(i.get("biblio_id"), []).append(i)
                self._item_biblio[i["item_id"]] = i.get("biblio_id")
            n += len(rows)
            if progress:
                progress(n)
            if (known is not None and page * per_page >= known) or (known is None and not rows):
                break
            page += 1
        self.items_skipped = skipped[0]
        return {b: self._summarise(items, libs) for b, items in by_bib.items()}

    # ---- circulation history for staff reports
    async def _page_safe(self, path, params, page, per_page, skipped):
        """One page; when Koha fails on it (a damaged record makes it answer 500), read it in tenths and skip only
        the rows it cannot return."""
        try:
            r = await self._req("GET", path, params={**params, "_page": page, "_per_page": per_page})
            total = r.headers.get("x-total-count")
            return r.json(), int(total) if total and total.isdigit() else None
        except KohaError as e:
            if _fatal(e):
                raise  # a network problem is not a damaged record: stop, and carry on next time
            if per_page <= 1:
                skipped[0] += 1
                return [], None
        out, total, small = [], None, max(1, per_page // 10)
        first = (page - 1) * (per_page // small) + 1
        for sub in range(first, first + per_page // small):
            rows, t = await self._page_safe(path, params, sub, small, skipped)
            out += rows
            total = total or t
            if t is not None and sub * small >= t:
                break
        return out, total

    async def _page_iter(self, path, params, per_page=1000, start_page=1, skipped=None, sizes=None):
        """Yield (page number, rows, total) from start_page on. If Koha returns fewer rows than asked on a page
        that isn't the last, it caps the page size, so carry on at its size (recorded in sizes[0])."""
        page, known = start_page, None
        skipped = skipped if skipped is not None else [0]
        while True:
            before = skipped[0]
            rows, total = await self._page_safe(path, params, page, per_page, skipped)
            known = total or known
            if (known is not None and 0 < len(rows) < per_page and skipped[0] == before
                    and (page - 1) * per_page + len(rows) < known and page == start_page == 1):
                per_page = len(rows)  # capped: page 1 at the smaller size is the same rows
            if sizes is not None:
                sizes[0] = per_page
            yield page, rows, known
            if (known is not None and page * per_page >= known) or (known is None and not rows):
                break
            page += 1

    async def _paged(self, path, params, per_page=1000, progress=None, skipped=None):
        n = 0
        async for _, rows, _ in self._page_iter(path, params, per_page, skipped=skipped):
            n += len(rows)
            for row in rows:
                yield row
            if progress:
                progress(n)

    @staticmethod
    def _loan(c, old):
        return {"checkout_id": c["checkout_id"], "item_id": c.get("item_id"), "pid": c.get("patron_id"),
                "out": _d(c.get("checkout_date")) or "", "back": _d(c.get("checkin_date")) or "",
                "renewals": c.get("renewals_count", c.get("renewals", 0)) or 0, "old": old}

    async def circulation_pages(self, since: str, returned_since: str | None = None, resume: dict | None = None):
        """Yield (checkpoint, rows) page by page: loans still out first, then returned loans that went out on or after
        `since` (or came back on or after `returned_since`). Pass a saved checkpoint as `resume` to carry on."""
        self.loans_skipped = 0
        skipped = [0]
        if not resume:
            async for _, rows, _ in self._page_iter("/checkouts", {"_order_by": "+checkout_id"}, self.LOAN_PAGE,
                                                    skipped=skipped):
                yield None, [self._loan(c, False) for c in rows]
        # Returned loans, newest first, stopping once a whole page went out before the cutoff. This needs no date
        # filter (some Koha versions answer 500 to one) and reads only the years asked for.
        if returned_since:  # nightly top-up: loans that came back recently, allowing for loans kept up to ~a year
            from datetime import date as _date, timedelta as _td
            stop_before = (_date.fromisoformat(returned_since) - _td(days=400)).isoformat()
            keep_if = lambda r: r["back"] >= returned_since  # noqa: E731
        else:
            stop_before = since
            keep_if = lambda r: r["out"] >= since  # noqa: E731
        params = {"checked_in": 1, "_order_by": "-checkout_id"}
        start = resume["page"] + 1 if resume else 1
        size = [resume.get("per_page", self.LOAN_PAGE) if resume else self.LOAN_PAGE]
        async for page, rows, total in self._page_iter("/checkouts", params, size[0], start, skipped, size):
            loans = [self._loan(c, True) for c in rows]
            self.loans_skipped = skipped[0]
            yield {"mode": "newest-first", "page": page, "total": total, "per_page": size[0]}, [r for r in loans if keep_if(r)]
            dated = [r["out"] for r in loans if r["out"]]
            if dated and max(dated) < stop_before:
                break

    async def circulation(self, since: str, returned_since: str | None = None, progress=None):
        out = []
        async for _, rows in self.circulation_pages(since, returned_since):
            out += rows
            if progress:
                progress(len(out))
        return out

    async def all_patrons(self, progress=None) -> list[dict]:
        """Category, home library and the two statistics fields of every patron (no names), for the borrower reports."""
        out = []
        async for p in self._paged("/patrons", {"_order_by": "+patron_id"}, progress=progress):
            out.append({"pid": p["patron_id"], "cat": p.get("category_id") or "", "lib": p.get("library_id") or "",
                        "s1": p.get("statistics_1") or "", "s2": p.get("statistics_2") or ""})
        return out

    async def patron_categories(self) -> dict[str, str]:
        try:
            return {c["patron_category_id"]: c.get("name") or c["patron_category_id"]
                    for c in (await self._req("GET", "/patron_categories", params={"_per_page": 500})).json()}
        except Exception:
            return {}

    async def fines_by_year(self) -> list:
        """Yearly fine totals from a public Koha SQL report (KOHA_FINES_REPORT_ID). Only totals, no patrons."""
        if not settings.koha_fines_report_id or not settings.koha_opac_url:
            return []
        r = await self.http.get(settings.koha_opac_url + "/cgi-bin/koha/svc/report", params={"id": settings.koha_fines_report_id})
        if r.status_code != 200:
            raise KohaError(f"Koha did not return the fines report ({r.status_code}). Check that report "
                            f"{settings.koha_fines_report_id} exists and is marked Public.", 502)
        return r.json()

    # ---- patrons
    async def authenticate(self, identifier: str, password: str):
        r = await self.http.post(self.base + "/auth/password/validation", headers=await self._auth_header(),
                                 json={"identifier": identifier, "password": password})
        if r.status_code in (400, 404):  # Koha answers 400 "Validation failed" for a wrong card or password
            return None
        if r.status_code in (401, 403):
            raise KohaError("Koha refused the app's API account when checking a password. Check its permissions.", 502)
        if r.status_code >= 300:
            raise KohaError("Koha could not check the password right now.")
        return int(r.json()["patron_id"])

    async def patron(self, pid: int) -> dict:
        p = (await self._req("GET", f"/patrons/{pid}")).json()
        libs = await self.libraries()
        return {"id": pid, "name": " ".join(x for x in [p.get("firstname"), p.get("surname")] if x),
                "card": p.get("cardnumber"), "branch": libs.get(p.get("library_id"), p.get("library_id")),
                "branch_id": p.get("library_id"), "expires": _d(p.get("expiry_date")), "email": p.get("email") or ""}

    async def patron_card(self, pid: int) -> dict:
        p = (await self._req("GET", f"/patrons/{pid}")).json()
        return {"name": " ".join(x for x in [p.get("firstname"), p.get("surname")] if x), "card": p.get("cardnumber") or ""}

    async def _biblio_of_item(self, item_id: int) -> int | None:
        if item_id not in self._item_biblio:
            it = (await self._req("GET", f"/items/{item_id}")).json()
            self._item_biblio[item_id] = it.get("biblio_id")
        return self._item_biblio[item_id]

    async def _checkouts(self, params, rows_given=None) -> list:
        """Checkouts with their item's title id. Asks Koha to embed the item (one request) and
        falls back to looking items up in parallel when this Koha can't embed."""
        if self._embed_items is not False and rows_given is None:
            try:
                rows = await self._all("/checkouts", params, headers={"x-koha-embed": "item"})
                if all(isinstance(c.get("item"), dict) for c in rows):
                    self._embed_items = True
                    for c in rows:
                        self._item_biblio[c["item_id"]] = c["item"].get("biblio_id")
                    return rows
            except KohaError:
                pass
            self._embed_items = False
        rows = await self._all("/checkouts", params) if rows_given is None else rows_given
        if self.local_item_biblio:
            for c in rows:
                if c["item_id"] not in self._item_biblio:
                    b = self.local_item_biblio(c["item_id"])
                    if b:
                        self._item_biblio[c["item_id"]] = b
        sem = asyncio.Semaphore(6)

        async def look(iid):
            async with sem:
                try:
                    await self._biblio_of_item(iid)
                except KohaError:
                    self._item_biblio[iid] = None
        await asyncio.gather(*(look(c["item_id"]) for c in rows if c["item_id"] not in self._item_biblio))
        return rows

    async def loans(self, pid: int):
        rows = await self._checkouts({"patron_id": pid})
        return [{"checkout_id": c["checkout_id"], "biblio_id": self._item_biblio.get(c["item_id"]),
                 "due": _d(c.get("due_date")), "renewals": c.get("renewals_count", c.get("renewals", 0)) or 0}
                for c in rows]

    async def history(self, pid: int, limit=30):
        """The most recent returns (one request to Koha)."""
        base = {"patron_id": pid, "checked_in": 1, "_page": 1, "_per_page": limit}
        try:
            rows = (await self._req("GET", "/checkouts", params={**base, "_order_by": "-checkin_date"})).json()
        except KohaError:
            rows = (await self._req("GET", "/checkouts", params=base)).json()
        rows = await self._checkouts(None, rows_given=rows)
        rows.sort(key=lambda c: c.get("checkin_date") or "", reverse=True)
        return [{"biblio_id": self._item_biblio.get(c["item_id"]), "out": _d(c.get("checkout_date")),
                 "back": _d(c.get("checkin_date"))} for c in rows]

    async def holds(self, pid: int):
        rows = await self._all("/holds", {"patron_id": pid})
        libs = await self.libraries()
        out = []
        for h in rows:
            waiting = h.get("status") == "W"
            out.append({"hold_id": h["hold_id"], "biblio_id": h["biblio_id"], "placed": _d(h.get("hold_date")),
                        "status": "Ready for pickup" if waiting else ("In transit" if h.get("status") == "T" else "In queue"),
                        "pos": h.get("priority"), "until": _d(h.get("expiration_date")) if waiting else None,
                        "at": libs.get(h.get("pickup_library_id"), h.get("pickup_library_id"))})
        return out

    async def fines(self, pid: int):
        acct = (await self._req("GET", f"/patrons/{pid}/account")).json()
        lines = (acct.get("outstanding_debits") or {}).get("lines", [])
        return [{"desc": l.get("description") or l.get("debit_type") or "Charge", "amt": float(l.get("amount_outstanding") or 0),
                 "date": _d(l.get("date")), "paid": float(l.get("amount_outstanding") or 0) == 0} for l in lines]

    async def renew(self, pid: int, checkout_id: int):
        mine = {c["checkout_id"] for c in await self._all("/checkouts", {"patron_id": pid})}
        if checkout_id not in mine:
            raise KohaError("That loan isn't on your account.", 403)
        r = await self._req("POST", f"/checkouts/{checkout_id}/renewal")
        return _d(r.json().get("due_date"))

    async def place_hold(self, pid: int, biblio_id: int, pickup: str | None):
        body = {"patron_id": pid, "biblio_id": biblio_id, "pickup_library_id": pickup or settings.koha_default_pickup}
        return (await self._req("POST", "/holds", json=body)).json()

    async def cancel_hold(self, pid: int, hold_id: int):
        mine = {h["hold_id"] for h in await self._all("/holds", {"patron_id": pid})}
        if hold_id not in mine:
            raise KohaError("That hold isn't on your account.", 403)
        await self._req("DELETE", f"/holds/{hold_id}")

    async def coborrow_histories(self):
        """Anonymised borrowing baskets from a public Koha SQL report (see docs/koha-setup.md)."""
        if not settings.koha_coborrow_report_id or not settings.koha_opac_url:
            return []
        r = await self.http.get(settings.koha_opac_url + "/cgi-bin/koha/svc/report",
                                params={"id": settings.koha_coborrow_report_id})
        if r.status_code != 200:
            return []
        baskets: dict = {}
        for row in r.json():  # rows: [basket_key, biblionumber]
            baskets.setdefault(row[0], []).append(int(row[1]))
        return [b for b in baskets.values() if len(b) > 1]


# --------------------------------------------------------------------------- Demo
class DemoKoha:
    """In-memory stand-in for Koha with sample data. Changes reset when the app restarts."""

    def __init__(self):
        today = date.today()
        d = lambda n: (today + timedelta(days=n)).isoformat()
        self.books = {b["id"]: b for b in SAMPLE["books"]}
        self.patrons = {1: {"id": 1, "name": "Aarav Mehta", "card": "LIB1024", "pin": "1234", "branch": "Main Library",
                            "branch_id": "MAIN", "expires": d(240), "email": "aarav@example.org"}}
        self._loans = {1: [{"checkout_id": 501, "biblio_id": 6, "due": d(-3), "renewals": 1},
                           {"checkout_id": 502, "biblio_id": 12, "due": d(4), "renewals": 0},
                           {"checkout_id": 503, "biblio_id": 9, "due": d(11), "renewals": 0}]}
        self._holds = {1: [{"hold_id": 901, "biblio_id": 20, "placed": d(-9), "status": "Ready for pickup", "pos": 0,
                            "until": d(5), "at": "Teen Zone desk"},
                           {"hold_id": 902, "biblio_id": 3, "placed": d(-2), "status": "In queue", "pos": 2, "until": None,
                            "at": "Main Library"}]}
        self._fines = {1: [{"desc": "Overdue: Atomic Habits", "amt": 15, "date": d(-1), "paid": False},
                           {"desc": "Overdue: The Gene", "amt": 10, "date": d(-60), "paid": True}]}
        self._history = {1: [{"biblio_id": 23, "out": d(-80), "back": d(-58)}, {"biblio_id": 1, "out": d(-120), "back": d(-101)},
                             {"biblio_id": 4, "out": d(-150), "back": d(-130)}, {"biblio_id": 16, "out": d(-200), "back": d(-185)}]}
        self._next = 1000

    async def circulation(self, since, returned_since=None, progress=None):
        """Made-up but repeatable loan history for the demo reports."""
        import random
        rnd = random.Random(7)
        ids = sorted(self.books)
        popular = ids[: max(3, len(ids) // 3)]
        out, today = [], date.today()
        for n in range(400):
            bid = rnd.choice(popular) if rnd.random() < .7 else rnd.choice(ids)
            d_out = today - timedelta(days=rnd.randint(0, 700))
            back = d_out + timedelta(days=rnd.randint(3, 40))
            old = back <= today
            if (returned_since and old and back.isoformat() < returned_since) or (not returned_since and d_out.isoformat() < since):
                continue
            out.append({"checkout_id": 10000 + n, "item_id": 100000 + bid, "biblio_id": bid, "pid": rnd.randint(1, 25),
                        "out": d_out.isoformat(), "back": back.isoformat() if old else "", "renewals": rnd.choice([0, 0, 0, 1, 2]),
                        "old": old})
        return out

    async def all_patrons(self, progress=None):
        return [{"pid": i, "cat": ["ST", "ST", "ST", "FA", "SF"][i % 5], "lib": "MAIN",
                 "s1": ["Computer Science", "Physics", "Chemistry", "Humanities"][i % 4], "s2": ""} for i in range(1, 26)]

    async def patron_categories(self):
        return {"ST": "Student", "FA": "Faculty", "SF": "Staff"}

    async def fines_by_year(self):
        y = date.today().year
        return [[y - 2, 4200, 3600, 3900, 150, 150], [y - 1, 5100, 4400, 4700, 220, 180], [y, 2600, 2300, 1800, 40, 760]]

    async def patron_card(self, pid):
        if pid in self.patrons:
            p = self.patrons[pid]
            return {"name": p["name"], "card": p["card"]}
        return {"name": f"Demo Reader {pid}", "card": f"LIB{1000 + pid}"}

    async def availability(self, biblio_id):
        b = self.books.get(biblio_id, {})
        return {"av": b.get("av", 0), "tot": b.get("tot", 0), "call": b.get("call", ""), "loc": b.get("loc", "")}

    async def authenticate(self, identifier, password):
        for p in self.patrons.values():
            if p["card"].lower() == identifier.strip().lower() and p["pin"] == password:
                return p["id"]
        return None

    async def patron(self, pid):
        return {k: v for k, v in self.patrons[pid].items() if k != "pin"}

    async def loans(self, pid):
        return self._loans.get(pid, [])

    async def history(self, pid):
        return self._history.get(pid, [])

    async def holds(self, pid):
        return self._holds.get(pid, [])

    async def fines(self, pid):
        return self._fines.get(pid, [])

    async def renew(self, pid, checkout_id):
        for l in self._loans.get(pid, []):
            if l["checkout_id"] == checkout_id:
                if l["renewals"] >= 3:
                    raise KohaError("No renewals left on this loan.", 400)
                start = max(date.today(), date.fromisoformat(l["due"]))
                l["due"] = (start + timedelta(days=14)).isoformat()
                l["renewals"] += 1
                return l["due"]
        raise KohaError("That loan isn't on your account.", 403)

    async def place_hold(self, pid, biblio_id, pickup=None):
        if any(h["biblio_id"] == biblio_id for h in self._holds.get(pid, [])):
            raise KohaError("You already have a hold on this title.", 400)
        b = self.books[biblio_id]
        self._next += 1
        h = {"hold_id": self._next, "biblio_id": biblio_id, "placed": date.today().isoformat(),
             "status": "Being pulled from shelf" if b["av"] > 0 else "In queue", "pos": 0 if b["av"] > 0 else 3,
             "until": None, "at": self.patrons[pid]["branch"]}
        self._holds.setdefault(pid, []).append(h)
        return h

    async def cancel_hold(self, pid, hold_id):
        hs = self._holds.get(pid, [])
        for h in hs:
            if h["hold_id"] == hold_id:
                hs.remove(h)
                return
        raise KohaError("That hold isn't on your account.", 403)

    async def coborrow_histories(self):
        return SAMPLE["borrowing_history"]


def make_backend():
    return DemoKoha() if settings.demo else KohaClient()
