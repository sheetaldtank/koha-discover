"""Email alerts for saved searches: "3 new titles match 'machine learning'".

After each catalogue refresh, every saved search with alerts on is run again. Titles added since the last alert
(a higher record number, or a newer accession date) are emailed to the reader, using the library's own mail
server (SMTP_* settings in .env). Without SMTP settings nothing is sent, and readers still see "N new" on the site.
"""
from __future__ import annotations

import json
import logging
import re
import smtplib
from email.message import EmailMessage

from .catalog import Catalog
from .config import settings
from .search import parse, run_search

log = logging.getLogger("discover.alerts")
SEARCH_KEYS = ("q", "rm", "format", "aud", "lang", "avail", "who", "pub", "subj", "ddc")


def run_params(cat: Catalog, params: dict) -> list[int]:
    """Run a saved search with the built-in rules (no AI, so it costs nothing to repeat nightly)."""
    p = {k: v for k, v in params.items() if k in SEARCH_KEYS}
    parsed = parse(cat, (p.get("q") or "").strip())
    f = dict(parsed["f"])
    for k in filter(None, (p.get("rm") or "").split(",")):
        f.pop(k, None)
        if k == "ymin":
            f.pop("ymax", None)
    for k in ("format", "aud", "lang", "who", "pub", "subj"):
        if p.get(k):
            f[k] = p[k]
    if p.get("ddc"):
        f["ddc"] = re.sub(r"\D", "", str(p["ddc"]))[:6]
    if p.get("avail") in (True, "true", "1", 1):
        f["avail"] = True
    return [r["id"] for r in run_search(cat, {"f": f, "kw": parsed["kw"]})]


def is_new(b: dict, base_id: int, base_date: str) -> bool:
    return b["id"] > (base_id or 0) or bool(base_date and (b.get("acq") or "") > base_date)


def baseline(cat: Catalog) -> tuple[int, str]:
    books = cat.books.values()
    return max((b["id"] for b in books), default=0), max((b.get("acq") or "" for b in books), default="")


def smtp_ready() -> bool:
    return bool(settings.smtp_host and settings.smtp_from)


def _send(to: str, subject: str, text: str):
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = settings.smtp_from, to, subject
    msg.set_content(text)
    cls = smtplib.SMTP_SSL if settings.smtp_port == 465 else smtplib.SMTP
    with cls(settings.smtp_host, settings.smtp_port, timeout=30) as s:
        if cls is smtplib.SMTP and settings.smtp_starttls:
            s.starttls()
        if settings.smtp_user:
            s.login(settings.smtp_user, settings.smtp_password)
        s.send_message(msg)


def send_alerts(cat: Catalog) -> int:
    """Email readers about new titles for their saved searches. Returns the number of emails sent."""
    if not smtp_ready():
        log.info("Saved-search alerts: no SMTP settings, so no emails sent.")
        return 0
    rows = cat.run("SELECT id, email, name, params, alerted_id, alerted_date FROM saved_searches WHERE email != ''")
    bid, bdate = baseline(cat)
    sent = 0
    site = settings.public_url.rstrip("/")
    for sid, email, name, params, a_id, a_date in rows:
        try:
            new = [cat.books[i] for i in run_params(cat, json.loads(params)) if is_new(cat.books[i], a_id, a_date)]
            if new:
                lines = [f"New in the library for your saved search \"{name}\":", ""]
                for b in new[:25]:
                    lines.append(f"- {b['t']} ({b['a']}{', ' + str(b['y']) if b.get('y') else ''})"
                                 + (f"\n  {site}/#b={b['id']}" if site else ""))
                if len(new) > 25:
                    lines.append(f"... and {len(new) - 25} more.")
                lines += ["", f"To stop these emails, sign in to {site or 'Catalogue Discover'} and remove the saved search.",
                          f"{settings.library_name}"]
                _send(email, f"{len(new)} new title{'s' if len(new) != 1 else ''}: {name}", "\n".join(lines))
                sent += 1
            cat.run("UPDATE saved_searches SET alerted_id=?, alerted_date=? WHERE id=?", (bid, bdate, sid), commit=True)
        except Exception as e:  # one bad address must not stop the rest
            log.warning("Saved-search alert %s failed: %s", sid, e)
    log.info("Saved-search alerts: %d email(s) sent.", sent)
    return sent
