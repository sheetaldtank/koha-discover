"""Make data/ddc-names.csv from OCLC's DDC Summaries, so Browse by subject uses the official Dewey captions.

    python -m app.ddcnames ddc23-summaries.pdf

Download the PDF from https://www.oclc.org/content/dam/oclc/dewey/ddc23-summaries.pdf (a .txt or .csv copy
with lines like "541 Physical chemistry" also works). The result stays in the data folder on this computer: it is
not part of the code you put on GitHub, because OCLC owns the copyright in the Dewey Decimal Classification.
Restart the app afterwards. To go back to the built-in names, delete data/ddc-names.csv and restart.
"""
from __future__ import annotations

import csv
import re
import sys
from pathlib import Path

from .dewey import names_file

ENTRY = re.compile(r"(?<![\d.])(\d{3})\s+(\S.*?)(?=\s+\d{3}\s+\S|\s*$)")
SKIP = re.compile(r"^\[?\s*(unassigned|not assigned|no longer used)", re.I)


def read_text(path: Path) -> str:
    if path.suffix.lower() == ".pdf":
        from pypdf import PdfReader
        return "\n".join(page.extract_text() or "" for page in PdfReader(str(path)).pages)
    return path.read_text(encoding="utf-8-sig", errors="replace")


def parse(text: str) -> dict[str, str]:
    """Later entries win, so the Third Summary (all 1,000 sections) overrides the shorter First and Second."""
    names: dict[str, str] = {}
    for line in text.splitlines():
        line = line.replace(" ", " ").strip().strip('"')
        if "," in line and re.match(r"^\d{3},", line):  # a CSV row
            code, name = line.split(",", 1)
            names[code] = name.strip().strip('"')
            continue
        for code, name in ENTRY.findall(line):
            name = re.sub(r"\s+", " ", name).strip(" .")
            if name and not name.isdigit() and len(name) < 120:
                names[code] = name
    return {c: n for c, n in sorted(names.items()) if not SKIP.match(n)}


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(1)
    names = parse(read_text(Path(sys.argv[1])))
    if len(names) < 100:
        print(f"Found only {len(names)} Dewey captions in that file, so nothing was saved. "
              "Check it is the DDC Summaries PDF.")
        sys.exit(1)
    out = names_file()
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open("w", encoding="utf-8", newline="") as fh:
        csv.writer(fh).writerows(sorted(names.items()))
    print(f"Saved {len(names)} Dewey captions to {out}. "
          f"Examples: 500 {names.get('500', '?')}; 540 {names.get('540', '?')}; 541 {names.get('541', '?')}.")
    print("Restart the app to use them.")


if __name__ == "__main__":
    main()
