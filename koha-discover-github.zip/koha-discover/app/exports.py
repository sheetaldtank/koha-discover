"""Turning lists of titles (or a staff report) into files: CSV, Excel, RIS and BibTeX, plus an APA citation.

RIS and BibTeX are the standard formats that Zotero, Mendeley, EndNote and LaTeX read.
Excel files are written with openpyxl.
"""
from __future__ import annotations

import csv
import io
import re

from .config import settings

ROW_COLUMNS = ["Title", "Subtitle", "Authors", "Publisher", "Year", "ISBN", "Call number", "Dewey", "Subjects",
               "Copies on shelf", "Catalogue link"]


def opac_link(b: dict) -> str:
    return f"{settings.koha_opac_url}/cgi-bin/koha/opac-detail.pl?biblionumber={b['id']}" if settings.koha_opac_url else ""


def book_row(b: dict) -> list:
    return [b["t"], b.get("st") or "", "; ".join(b.get("au") or [b.get("a", "")]), b.get("pub") or "", b.get("y") or "",
            b.get("isbn") or "", b.get("call") or "", b.get("dd") or "", "; ".join(b.get("subj", [])),
            b.get("av", ""), opac_link(b)]


def to_csv(columns: list, rows: list) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(columns)
    w.writerows(rows)
    return ("﻿" + buf.getvalue()).encode("utf-8")  # the BOM makes Excel open Hindi and other scripts correctly


def to_xlsx(columns: list, rows: list, title: str = "Export", about: str = "") -> bytes:
    from openpyxl import Workbook
    from openpyxl.styles import Font
    from openpyxl.utils import get_column_letter
    wb = Workbook()
    ws = wb.active
    ws.title = re.sub(r"[\[\]:*?/\\]", "", title)[:31] or "Export"
    start = 1
    if about:
        ws.cell(row=1, column=1, value=title).font = Font(bold=True, size=13)
        ws.cell(row=2, column=1, value=about)
        start = 4
    for c, name in enumerate(columns, 1):
        ws.cell(row=start, column=c, value=name).font = Font(bold=True)
    for r, row in enumerate(rows, start + 1):
        for c, v in enumerate(row, 1):
            ws.cell(row=r, column=c, value=v)
    for c, name in enumerate(columns, 1):
        width = max([len(str(name))] + [len(str(row[c - 1])) for row in rows[:200]])
        ws.column_dimensions[get_column_letter(c)].width = min(max(10, width + 2), 60)
    ws.freeze_panes = ws.cell(row=start + 1, column=1)
    out = io.BytesIO()
    wb.save(out)
    return out.getvalue()


def _type(b: dict) -> tuple[str, str]:
    return ("VIDEO", "misc") if b.get("f") == "DVD" else ("EBOOK", "book") if b.get("f") == "eBook" else ("BOOK", "book")


def to_ris(books: list[dict]) -> bytes:
    out = []
    for b in books:
        out.append(f"TY  - {_type(b)[0]}")
        out.append(f"TI  - {b['t']}" + (f": {b['st']}" if b.get("st") else ""))
        for a in b.get("au") or [b.get("a", "")]:
            out.append(f"AU  - {a}")
        for k, v in (("PY", b.get("y")), ("PB", b.get("pub")), ("SN", b.get("isbn")), ("CN", b.get("call")),
                     ("LA", b.get("l")), ("UR", opac_link(b))):
            if v:
                out.append(f"{k}  - {v}")
        for s in b.get("subj", []):
            out.append(f"KW  - {s}")
        if b.get("n", {}).get("520"):
            out.append(f"AB  - {b['n']['520']}")
        out.append("ER  - \n")
    return "\r\n".join(out).encode("utf-8")


def _bib(s) -> str:
    return str(s).replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}").replace("&", "\\&").replace("%", "\\%")


def to_bibtex(books: list[dict]) -> bytes:
    out = []
    for b in books:
        first = re.sub(r"[^a-z]", "", ((b.get("au") or [b.get("a", "")])[0].split(",")[0]).lower()) or "anon"
        key = f"{first}{b.get('y') or ''}_{b['id']}"
        f = {"title": b["t"] + (f": {b['st']}" if b.get("st") else ""),
             "author": " and ".join(b.get("au") or [b.get("a", "")]), "year": b.get("y"), "publisher": b.get("pub"),
             "isbn": b.get("isbn"), "note": f"Call number {b['call']}" if b.get("call") else None, "url": opac_link(b)}
        body = ",\n".join(f"  {k} = {{{_bib(v)}}}" for k, v in f.items() if v)
        out.append(f"@{_type(b)[1]}{{{key},\n{body}\n}}\n")
    return "\n".join(out).encode("utf-8")


def _apa_name(n: str) -> str:
    """'Mukherjee, Siddhartha' or 'Siddhartha Mukherjee' -> 'Mukherjee, S.'"""
    n = n.strip().rstrip(".")
    if "," in n:
        last, first = [x.strip() for x in n.split(",", 1)]
    else:
        parts = n.split()
        if len(parts) < 2:
            return n
        last, first = parts[-1], " ".join(parts[:-1])
    initials = " ".join(p[0] + "." for p in re.split(r"[\s.]+", first) if p and p[0].isalpha())
    return f"{last}, {initials}".strip(", ")


def apa(b: dict) -> str:
    names = [_apa_name(a) for a in (b.get("au") or [b.get("a", "")]) if a and a != "Unknown author"][:20]
    who = names[0] if len(names) == 1 else (", ".join(names[:-1]) + ", & " + names[-1]) if names else ""
    title = b["t"] + (f": {b['st']}" if b.get("st") else "")
    parts = [f"{who} " if who else "", f"({b['y']}). " if b.get("y") else "(n.d.). ", f"{title}. ", f"{b['pub']}." if b.get("pub") else ""]
    return "".join(parts).strip()
