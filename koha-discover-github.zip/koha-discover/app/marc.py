"""Turn a Koha MARC-in-JSON record (MARC 21) into the flat record the app uses."""
import re
from datetime import date

LANG_CODES = {"eng": "English", "hin": "Hindi", "mar": "Marathi", "tam": "Tamil", "tel": "Telugu", "ben": "Bengali",
              "guj": "Gujarati", "kan": "Kannada", "mal": "Malayalam", "pan": "Punjabi", "urd": "Urdu", "san": "Sanskrit",
              "fre": "French", "ger": "German", "spa": "Spanish", "jpn": "Japanese", "chi": "Chinese", "ara": "Arabic"}
# Some catalogues put two-letter ISO 639-1 codes in 008/35-37 ("en ", "hi ")
LANG_CODES.update({"en": "English", "hi": "Hindi", "mr": "Marathi", "ta": "Tamil", "te": "Telugu", "bn": "Bengali",
                   "gu": "Gujarati", "kn": "Kannada", "ml": "Malayalam", "pa": "Punjabi", "ur": "Urdu", "sa": "Sanskrit",
                   "fr": "French", "de": "German", "es": "Spanish", "ja": "Japanese", "zh": "Chinese", "ar": "Arabic",
                   "fra": "French", "deu": "German", "zho": "Chinese", "ita": "Italian", "rus": "Russian", "por": "Portuguese",
                   "kor": "Korean", "nep": "Nepali", "ori": "Odia", "asm": "Assamese", "per": "Persian", "lat": "Latin",
                   "grc": "Ancient Greek", "gre": "Greek", "dut": "Dutch", "swe": "Swedish", "pol": "Polish", "tur": "Turkish",
                   "heb": "Hebrew", "tib": "Tibetan", "pli": "Pali", "prk": "Prakrit", "snd": "Sindhi", "kas": "Kashmiri",
                   "kok": "Konkani", "mai": "Maithili", "raj": "Rajasthani", "bho": "Bhojpuri", "mul": "Multiple languages"})
NOTE_TAGS = ["250", "500", "504", "505", "520", "521", "546", "586"]


def _fields(rec, tag):
    for f in rec.get("fields", []):
        if tag in f:
            yield f[tag]


def _sub(field, codes):
    if isinstance(field, str):
        return [field]
    return [v for s in field.get("subfields", []) for k, v in s.items() if k in codes]


def _first(rec, tag, codes="a"):
    for f in _fields(rec, tag):
        vals = _sub(f, codes)
        if vals:
            return " ".join(vals)
    return ""


def _clean(s: str) -> str:
    s = re.sub(r"\s+", " ", s or "").strip()
    return re.sub(r"\s*[/:;,=.]\s*$", "", s).strip()


def _hue(text: str) -> int:
    return sum(ord(c) for c in text) * 37 % 360


def marc_to_record(biblio_id: int, rec: dict) -> dict:
    leader = rec.get("leader", "")
    f008 = _first(rec, "008", "")
    for f in _fields(rec, "008"):
        f008 = f if isinstance(f, str) else f008

    title = _clean(_first(rec, "245", "anp"))
    subtitle = _clean(_first(rec, "245", "b"))
    author = _clean(_first(rec, "100", "a") or _first(rec, "110", "a") or _first(rec, "245", "c"))
    added = [_clean(" ".join(_sub(f, "a"))) for f in _fields(rec, "700")]
    people = [p for p in dict.fromkeys([_clean(_first(rec, "100", "a")), _clean(_first(rec, "110", "a"))] + added) if p]
    publisher = _clean(_first(rec, "264", "b") or _first(rec, "260", "b"))
    publisher = re.sub(r"^\[?(?:s\.\s?n\.?|n\.\s?p\.?|publisher not identified)\]?$", "", publisher, flags=re.I).strip(" []")
    ddc = ""
    m = re.match(r"\s*(\d{3}(?:\.\d+)?)", (_first(rec, "082", "a") or "").replace("/", "").replace("'", ""))
    if m:
        ddc = m.group(1)
    if added and author and len(added) <= 3:
        author = ", ".join([author] + added)

    year = None
    this_year = date.today().year
    for text in (_first(rec, "264", "c"), _first(rec, "260", "c"), f008[7:11] if len(f008) > 10 else ""):
        for y in re.findall(r"(?<!\d)(1[4-9]\d\d|20\d\d)(?!\d)", text or ""):
            if 1450 <= int(y) <= this_year + 1:
                year = int(y)
                break
        if year:
            break

    isbn = ""
    for f in _fields(rec, "020"):
        for v in _sub(f, "a"):
            digits = re.sub(r"[^0-9Xx]", "", v.split(" ")[0])
            if len(digits) == 13 or (len(digits) == 10 and not isbn):
                isbn = digits.lower()
                if len(digits) == 13:
                    break
        if len(isbn) == 13:
            break

    # 008/35-37 holds a MARC language code; many records have junk there ("|||", "0 E"), so fall back to 041$a.
    language = ""
    for code in ((f008[35:38] if len(f008) >= 38 else ""), _first(rec, "041", "a")[:3]):
        code = code.strip().lower()
        if re.fullmatch(r"[a-z]{2,3}", code) and code in LANG_CODES:
            language = LANG_CODES[code]
            break

    # 008/22 target audience (books): j = juvenile, d = adolescent
    aud_code = f008[22] if len(f008) > 22 else ""
    audience = {"a": "Children", "b": "Children", "c": "Children", "j": "Children", "d": "Young adult"}.get(aud_code, "General")
    # 008/33 literary form: 0 = not fiction
    lit = f008[33] if len(f008) > 33 else ""
    fiction = lit not in ("0", "", " ", "|") if leader[6:7] in ("a", "t") else False

    rtype = leader[6:7]
    fmt = {"g": "DVD", "i": "Audiobook", "j": "Music", "e": "Map", "m": "eBook"}.get(rtype, "Book")
    if _first(rec, "856", "u") and fmt == "Book" and "electronic" in _first(rec, "245", "h").lower():
        fmt = "eBook"
    itype = _first(rec, "942", "c").upper()
    fmt = {"EBOOK": "eBook", "EB": "eBook", "DVD": "DVD", "AUDIO": "Audiobook", "AB": "Audiobook", "BK": "Book"}.get(itype, fmt)

    subjects = []
    for tag in ("650", "651", "600", "610"):
        for f in _fields(rec, tag):
            s = _clean(" -- ".join(_sub(f, "a")))
            if s and s not in subjects:
                subjects.append(s)
    genres = [_clean(" ".join(_sub(f, "a"))) for f in _fields(rec, "655")]
    genre = genres[0] if genres else (subjects[0] if subjects else ("Fiction" if fiction else "Non-fiction"))

    series = None
    for tag in ("800", "830", "490"):
        for f in _fields(rec, tag):
            name = _clean(" ".join(_sub(f, "at" if tag == "800" else "a")))
            vol = " ".join(_sub(f, "v"))
            n = re.search(r"\d+", vol)
            if name:
                series = [name, int(n.group()) if n else 0]
                break
        if series:
            break

    notes = {}
    for tag in NOTE_TAGS:
        vals = [" ".join(_sub(f, "abcdefghijklmnopqrstuvwxyz")) for f in _fields(rec, tag)]
        vals = [re.sub(r"\s+", " ", v).strip() for v in vals if v.strip()]
        if vals:
            notes[tag] = " ".join(vals)

    pages = None
    m = re.search(r"(\d+)\s*p", _first(rec, "300", "a"))
    if m:
        pages = int(m.group(1))

    return {
        "id": int(biblio_id), "t": title or "(untitled)", "st": subtitle or None, "a": author or "Unknown author",
        "y": year, "f": fmt, "l": language, "aud": audience, "fic": fiction, "pg": pages,
        "call": _first(rec, "082", "a") or _first(rec, "092", "a") or "", "isbn": isbn,
        "subj": subjects + [g for g in genres if g not in subjects], "g": genre, "ser": series,
        "n": notes, "hue": _hue(title or str(biblio_id)), "au": people, "pub": publisher, "ddc": ddc,
    }
