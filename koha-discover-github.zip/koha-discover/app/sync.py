"""Copy the catalogue from Koha into the local search index, and add AI enrichments.

Run:  python -m app.sync                 (records + availability)
      python -m app.sync --enrich        (also cover descriptions and plain-language summaries via Claude)
      python -m app.sync --enrich --limit 200   (enrich at most 200 records this run)
Schedule it nightly with cron or a systemd timer (see README).
"""
from __future__ import annotations

import argparse
import sys
import asyncio
import json
import logging
import time

import httpx

from . import ai
from .catalog import Catalog
from .config import settings
from .koha import SAMPLE, DemoKoha, KohaClient, KohaError
from .marc import marc_to_record

log = logging.getLogger("discover.sync")


def load_demo(cat: Catalog):
    cat.upsert(SAMPLE["books"])
    cat.reindex()


PER_PAGE = 250


async def sync_koha(cat: Catalog, from_page: int | None = None):
    """Copy every record from Koha. If a previous run stopped part-way, carry on from the last finished batch."""
    k = KohaClient()
    t0 = time.time()
    saved = cat.cache_get("sync_progress")
    start = from_page or (saved["page"] + 1 if saved else 1)
    resuming = start > 1
    if resuming:
        log.info("Carrying on from batch %d (records already copied are kept).", start)
    try:
        log.info("Reading the shelf status of every copy from Koha...")
        avail = await k.all_availability(progress=lambda n: log.info("  read %d copies", n))
        cat.save_item_map(k._item_biblio)
        if getattr(k, "items_skipped", 0):
            log.warning("Left out about %d copies that Koha rejects (impossible dates on the item). See docs/koha-setup.md.", k.items_skipped)
    except Exception as e:
        log.warning("Could not read the copy list in bulk (%s). Availability will be read live instead.", str(e)[:300])
        avail = {}
    log.info("Reading catalogue records from Koha...")
    seen, skipped, n = set(), [], 0
    async for page, rows in k.iter_biblio_pages(PER_PAGE, start, skipped):
        batch = []
        for bid, marc in rows:
            try:
                rec = marc_to_record(bid, marc)
                rec.update(avail.get(bid) or {"av": 0, "tot": 0})
            except Exception as e:
                log.warning("Skipping record %s: %s", bid, e)
                continue
            batch.append(rec)
            seen.add(bid)
        cat.upsert(batch)
        cat.save_marc(rows)
        cat.cache_set("sync_progress", {"page": page}, ttl=86400 * 3)
        n += len(batch)
        log.info("Synced %d records (batch %d, %.0f min so far)", (start - 1) * PER_PAGE + n, page, (time.time() - t0) / 60)
    if skipped:
        log.warning("Koha could not return %d record(s), skipped: %s", len(skipped), ", ".join(map(str, skipped[:50])))
    if avail and resuming:  # refresh shelf status of the records copied in the earlier run
        with cat.lock:
            for bid, a in avail.items():
                row = cat.db.execute("SELECT data FROM records WHERE id=?", (bid,)).fetchone()
                if row and bid not in seen:
                    d = json.loads(row[0]); d.update(a)
                    cat.db.execute("UPDATE records SET data=? WHERE id=?", (json.dumps(d, ensure_ascii=False), bid))
            cat.db.commit()
    removed = 0 if resuming else cat.remove_missing(seen)  # only a full run can tell which records were deleted
    cat.cache_set("sync_progress", None, ttl=-1)
    log.info("Sync done: %d records copied, %d removed, %d skipped, in %.0f min. The catalogue now holds %d records.",
             n, removed, len(skipped), (time.time() - t0) / 60, cat.count())
    cat.reindex()


async def _cover_image(b: dict):
    urls = []
    if settings.koha_opac_url:
        urls.append(f"{settings.koha_opac_url}/cgi-bin/koha/opac-image.pl?biblionumber={b['id']}")
    if b.get("isbn"):
        urls.append(f"https://covers.openlibrary.org/b/isbn/{b['isbn']}-L.jpg?default=false")
    async with httpx.AsyncClient(timeout=15, follow_redirects=True) as h:
        for u in urls:
            try:
                r = await h.get(u)
            except httpx.HTTPError:
                continue
            ct = r.headers.get("content-type", "").split(";")[0]
            if r.status_code == 200 and ct in ("image/jpeg", "image/png", "image/gif", "image/webp") and len(r.content) > 2000:
                return r.content, ct
    return None


async def enrich(cat: Catalog, limit: int):
    if not settings.ai_enabled:
        log.warning("ANTHROPIC_API_KEY is not set, so there is nothing to enrich.")
        return
    done = 0
    for b in list(cat.books.values()):
        if done >= limit:
            break
        changed = False
        if not b.get("cd"):
            img = await _cover_image(b)
            if img:
                desc = await asyncio.to_thread(ai.describe_cover, *img)
                if desc:
                    cat.set_enrichment(b["id"], cover_desc=desc); changed = True
        if not b.get("ai_explain") and (b.get("n") or b.get("subj")):
            pts = await asyncio.to_thread(ai.explain_record, b)
            if pts:
                cat.set_enrichment(b["id"], explain=pts); changed = True
        done += changed
    log.info("Enriched %d records", done)
    cat.reindex()


async def sync_availability(cat: Catalog):
    """Refresh only the shelf status of every title (quick compared with a full copy)."""
    k = KohaClient()
    t0 = time.time()
    avail = await k.all_availability(progress=lambda n: log.info("  read %d copies", n))
    cat.save_item_map(k._item_biblio)
    if getattr(k, "items_skipped", 0):
        log.warning("Left out about %d copies that Koha rejects (impossible dates on the item). See docs/koha-setup.md.", k.items_skipped)
    with cat.lock:
        rows = cat.db.execute("SELECT id, data FROM records").fetchall()
        for bid, data in rows:
            if bid in avail:
                d = json.loads(data); d.update(avail[bid])
                cat.db.execute("UPDATE records SET data=? WHERE id=?", (json.dumps(d, ensure_ascii=False), bid))
        cat.db.commit()
    cat.reindex()
    log.info("Shelf status done: %d titles with copies, in %.0f min.", len(avail), (time.time() - t0) / 60)


def _save_loans(cat: Catalog, rows: list[dict]):
    for r in rows:
        if r.get("biblio_id") is None and r.get("item_id"):
            r["biblio_id"] = cat.item_biblio(r["item_id"])
    with cat.lock:
        cat.db.executemany("INSERT OR REPLACE INTO circ VALUES(?,?,?,?,?,?,?)",
                           [(r["checkout_id"], r.get("item_id"), r.get("biblio_id"), r.get("pid"), r["out"], r["back"],
                             r["renewals"]) for r in rows])
        cat.db.commit()


async def sync_circulation(cat: Catalog, since: str | None = None, k=None, restart: bool = False):
    """Copy loans for the circulation reports. The first run (or --since) reads every loan from that date;
    later runs read loans still out plus returns since the last run. Loans are saved page by page, so an
    interrupted run carries on from the last saved page when started again with the same command."""
    from datetime import date, timedelta
    k = k or (DemoKoha() if settings.demo else KohaClient())
    t0 = time.time()
    last = cat.cache_get("circ_synced")
    if since or not last:
        since = since or (date.today() - timedelta(days=730)).isoformat()
        returned_since, first = None, since
    else:
        returned_since = (date.fromisoformat(last["to"]) - timedelta(days=2)).isoformat()
        since, first = last["from"], last["from"]
    plan = {"since": since, "returned_since": returned_since}
    saved = None if restart else cat.cache_get("circ_progress")
    resume = saved if saved and saved.get("mode") == "newest-first" and {x: saved.get(x) for x in plan} == plan else None
    if resume:
        log.info("Carrying on from page %d of returned loans (saved by the last run).", resume["page"] + 1)
    else:
        log.info("Copying loans %s (this can take a while on a slow Koha)...",
                 f"returned since {returned_since}" if returned_since else f"from {since}")
    n = 0
    if hasattr(k, "circulation_pages"):
        async for point, rows in k.circulation_pages(since, returned_since, resume):
            _save_loans(cat, rows)
            n += len(rows)
            if point:
                cat.cache_set("circ_progress", {**plan, **point}, ttl=86400 * 30)
                log.info("  saved %d loans (page %d%s)", n, point["page"],
                         f", newest first, back to {plan['returned_since'] or plan['since']}")
    else:  # demo
        rows = await k.circulation(since, returned_since)
        _save_loans(cat, rows)
        n = len(rows)
    try:
        patrons = await k.all_patrons(progress=lambda c: log.info("  read %d patrons", c))
        with cat.lock:
            cat.db.executemany("INSERT OR REPLACE INTO patron_min VALUES(?,?,?,?,?)",
                               [(p["pid"], p["cat"], p["lib"], p["s1"], p["s2"]) for p in patrons])
            cat.db.commit()
        cat.cache_set("patron_categories", await k.patron_categories(), ttl=86400 * 365)
    except Exception as e:  # the borrower reports then show numbers without categories
        log.warning("Could not read patron categories: %s", e)
    cat.cache_set("circ_progress", None, ttl=-1)
    cat.cache_set("circ_synced", {"from": first, "to": date.today().isoformat()}, ttl=86400 * 3650)
    if getattr(k, "loans_skipped", 0):
        log.warning("Koha could not return %d old loan record(s) (damaged dates in Koha), so they were left out.",
                    k.loans_skipped)
    missing = cat.run("SELECT COUNT(*) FROM circ c LEFT JOIN item_map m ON m.item_id = c.item_id "
                      "WHERE c.biblio_id IS NULL AND m.biblio_id IS NULL")[0][0]
    log.info("Loans done: %d read in %.1f min.%s", n, (time.time() - t0) / 60,
             f" {missing} belong to copies not in the catalogue copy (run --availability-only to refresh)." if missing else "")


def reparse(cat: Catalog):
    """Re-read every record from the MARC saved by the last sync (after a fix to the MARC reading). Needs no Koha."""
    n = 0
    with cat.lock:
        old = {i: json.loads(d) for i, d in cat.db.execute("SELECT id, data FROM records")}
        marcs = cat.db.execute("SELECT id, data FROM marc").fetchall()
    batch = []
    for bid, data in marcs:
        rec = marc_to_record(bid, json.loads(data))
        prev = old.get(bid, {})
        rec.update({k: prev[k] for k in ("av", "tot", "loc", "acq", "uses", "lastb") if k in prev})
        if prev.get("call"):
            rec["call"] = prev["call"]
        batch.append(rec)
        if len(batch) >= 1000:
            cat.upsert(batch); n += len(batch); batch = []
    cat.upsert(batch); n += len(batch)
    cat.reindex()
    log.info("Re-read %d records from saved MARC.", n)
    if not marcs:
        log.warning("No saved MARC yet. Run a full sync (python -m app.sync --full) once.")


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--enrich", action="store_true", help="add cover descriptions and summaries with Claude")
    p.add_argument("--reparse", action="store_true", help="re-read records from the MARC saved by the last sync (no Koha needed)")
    p.add_argument("--full", action="store_true", help="copy everything from the start, even if a previous run stopped part-way")
    p.add_argument("--availability-only", action="store_true", help="only refresh which copies are on the shelf")
    p.add_argument("--from-page", type=int, help="start the copy at this batch of 250 (normally automatic after an interrupted run)")
    p.add_argument("--circulation", action="store_true", help="only copy loans for the circulation reports")
    p.add_argument("--since", help="with --circulation: copy loans from this date (YYYY-MM-DD), e.g. 2024-01-01")
    p.add_argument("--restart", action="store_true", help="with --circulation: start again instead of carrying on from an interrupted run")
    p.add_argument("--send-alerts", action="store_true", help="only email readers about new titles for their saved searches")
    p.add_argument("--limit", type=int, default=500, help="maximum records to enrich in this run")
    a = p.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    cat = Catalog()
    if a.circulation:
        if settings.demo:
            load_demo(cat)
        try:
            asyncio.run(sync_circulation(cat, a.since, restart=a.restart))
        except KohaError as e:
            log.error("Stopped: %s", e)
            sys.exit(1)
        return
    if settings.demo:
        load_demo(cat)
        log.info("Demo mode: loaded %d sample records", cat.count())
    else:
        if a.send_alerts:
            pass
        elif a.reparse:
            reparse(cat)
        else:
            asyncio.run(sync_availability(cat) if a.availability_only else sync_koha(cat, 1 if a.full else a.from_page))
    if a.enrich:
        asyncio.run(enrich(cat, a.limit))
    if not a.reparse and not a.send_alerts and not settings.demo and cat.cache_get("circ_synced"):
        try:  # the nightly refresh tops up the loans once the first copy has been made
            asyncio.run(sync_circulation(cat))
        except Exception as e:
            log.warning("Loans for the circulation reports were not refreshed: %s", e)
    if not a.send_alerts and not a.availability_only and settings.semantic != "off":
        try:  # v5: top up the meaning index with new or changed titles (the app reads it when it restarts)
            from .semantic import Semantic
            log.info(Semantic().build(cat.books))
        except Exception as e:
            log.warning("Meaning index not refreshed (word search still works): %s", e)
    if not a.reparse:
        from .alerts import send_alerts
        send_alerts(cat)


if __name__ == "__main__":
    main()
