"""Meaning-based search and topic themes (v5).

Every title gets a "meaning fingerprint" (a vector of numbers) made from its title, subjects, series, summary and
contents. A search is turned into the same kind of vector, and titles whose vectors point the same way are close in
meaning, even when they share no words ("ahimsa" finds books on nonviolence).

Two ways to make the vectors, chosen by SEMANTIC in .env:
  model  A small open sentence-embedding model run on this computer with the sentence-transformers library
         (EMBED_MODEL, default paraphrase-multilingual-MiniLM-L12-v2: about 470 MB, 50+ languages including Hindi).
         Nothing is sent outside the campus. Install with:  pip install -r requirements-semantic.txt
  lsa    Latent semantic analysis with scikit-learn (TF-IDF + SVD). Learns which words go together from the
         catalogue itself. No download, works everywhere, weaker than the model.
  auto   (default) model when sentence-transformers is installed, otherwise lsa.
  off    keyword search only.

Themes: the vectors are grouped with k-means (scikit-learn) into about 150 themes, and each theme is named from
the subject headings and words that set it apart (class-based TF-IDF, the method BERTopic uses).

Build or refresh:  python -m app.semantic     (the nightly sync also refreshes it)
Files: data/semantic/ (vectors.npy, ids.json, meta.json, themes.json, lsa.pkl)
"""
from __future__ import annotations

import hashlib
import json
import logging
import math
import pickle
import re
import threading
import time
from collections import Counter

from .config import settings

log = logging.getLogger("discover.semantic")

try:
    import numpy as np
except ImportError:  # pragma: no cover
    np = None


def book_text(b: dict) -> str:
    """What a title is about. The author is left out, so "books on Gandhi" is not matched by books Gandhi wrote."""
    n = b.get("n", {})
    ser = b.get("ser") or ""
    if isinstance(ser, (list, tuple)):
        ser = ". ".join(x if isinstance(x, str) else str(x.get("t") or x.get("name") or "") if isinstance(x, dict) else str(x) for x in ser)
    parts = [b.get("t", ""), b.get("st") or "", ". ".join(b.get("subj", [])), ser,
             n.get("520", ""), n.get("505", "")[:400]]
    return re.sub(r"\s+", " ", ". ".join(p for p in parts if p)).strip()[:1200]


def _digest(t: str) -> str:
    return hashlib.md5(t.encode("utf-8")).hexdigest()[:12]


def backend_wanted() -> str:
    mode = settings.semantic
    if mode in ("off", "lsa"):
        return mode
    try:
        import sentence_transformers  # noqa: F401
        return "model"
    except Exception:
        if mode == "model":
            log.warning("SEMANTIC=model but sentence-transformers is not installed; using lsa. "
                        "Install it with:  pip install -r requirements-semantic.txt")
        return "lsa"


class Semantic:
    def __init__(self):
        self.dir = settings.data_dir / "semantic"
        self.ready = False
        self.backend = ""
        self.ids: list[int] = []
        self.pos: dict[int, int] = {}
        self.vecs = None
        self.themes: list[dict] = []
        self.theme_of: dict[int, int] = {}
        self.centroids = None
        self._model = None
        self._lsa = None
        self.building = False
        self.lock = threading.Lock()

    # ---------------------------------------------------------------- encoders
    def model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            log.info("Loading the meaning model %s (the first time it is downloaded, about 470 MB)...", settings.embed_model)
            self._model = SentenceTransformer(settings.embed_model, device="cpu")
        return self._model

    def encode(self, texts: list[str], progress=False):
        if self.backend == "model":
            v = self.model().encode(texts, batch_size=64, normalize_embeddings=True, show_progress_bar=progress,
                                    convert_to_numpy=True)
            return v.astype(np.float32)
        vec, svd = self._lsa
        v = svd.transform(vec.transform(texts)).astype(np.float32)
        return v / np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9)

    # ---------------------------------------------------------------- build
    def build(self, books: dict, force=False, progress=False) -> str:
        """Make or refresh the vectors and themes. With the model, only new or changed titles are encoded."""
        if np is None:
            return "numpy is not installed"
        backend = backend_wanted()
        if backend == "off":
            return "semantic search is switched off (SEMANTIC=off)"
        t0 = time.time()
        self.building = True
        try:
            self.dir.mkdir(parents=True, exist_ok=True)
            ids = sorted(books)
            texts = [book_text(books[i]) for i in ids]
            digests = [_digest(t) for t in texts]
            if backend == "model":
                self.backend = "model"
                old = self._read_old(backend)
                vecs, todo = [], []
                for k, (i, d) in enumerate(zip(ids, digests)):
                    hit = None if force or not old else old.get((i, d))
                    vecs.append(hit)
                    if hit is None:
                        todo.append(k)
                log.info("Meaning fingerprints: %d to make, %d kept from last time", len(todo), len(ids) - len(todo))
                if todo:
                    made = self.encode([texts[k] for k in todo], progress=progress)
                    for k, v in zip(todo, made):
                        vecs[k] = v
                dim = len(vecs[0]) if vecs else 384
                V = np.vstack(vecs).astype(np.float32) if vecs else np.zeros((0, dim), np.float32)
            else:
                from sklearn.decomposition import TruncatedSVD
                from sklearn.feature_extraction.text import TfidfVectorizer
                self.backend = "lsa"
                big = len(ids) >= 2000
                vec = TfidfVectorizer(sublinear_tf=True, min_df=2 if big else 1, max_df=0.4 if big else 0.9,
                                      stop_words="english", token_pattern=r"(?u)\b[a-zA-Z][a-zA-Z]+\b", max_features=60000)
                X = vec.fit_transform(texts)
                k = max(2, min(256, X.shape[1] - 1, len(ids) - 1))
                svd = TruncatedSVD(n_components=k, random_state=0).fit(X)
                self._lsa = (vec, svd)
                with open(self.dir / "lsa.pkl", "wb") as fh:
                    pickle.dump(self._lsa, fh)
                V = self.encode(texts)
            themes, theme_of, cents = make_themes(V, ids, books)
            np.save(self.dir / "vectors.npy", V)
            np.save(self.dir / "centroids.npy", cents)
            (self.dir / "ids.json").write_text(json.dumps({"ids": ids, "digests": digests}))
            (self.dir / "themes.json").write_text(json.dumps({"themes": themes, "of": {str(k): v for k, v in theme_of.items()}},
                                                             ensure_ascii=False))
            (self.dir / "meta.json").write_text(json.dumps({"backend": backend, "model": settings.embed_model if backend == "model" else "",
                                                            "built": time.strftime("%Y-%m-%d %H:%M"), "count": len(ids)}))
            self._install(ids, V, themes, theme_of, cents)
            msg = f"Meaning search ready ({backend}): {len(ids)} titles, {len(themes)} themes, in {time.time() - t0:.0f} s"
            log.info(msg)
            return msg
        finally:
            self.building = False

    def _read_old(self, backend):
        try:
            meta = json.loads((self.dir / "meta.json").read_text())
            if meta.get("backend") != backend or meta.get("model") != settings.embed_model:
                return None
            j = json.loads((self.dir / "ids.json").read_text())
            V = np.load(self.dir / "vectors.npy")
            return {(i, d): V[k] for k, (i, d) in enumerate(zip(j["ids"], j["digests"]))}
        except Exception:
            return None

    def _install(self, ids, V, themes, theme_of, cents):
        with self.lock:
            self.ids, self.vecs = ids, V
            self.pos = {i: k for k, i in enumerate(ids)}
            self.themes, self.theme_of, self.centroids = themes, theme_of, cents
            self.ready = len(ids) > 0

    def load(self) -> bool:
        """Read what was built before. Returns False when there is nothing (or it was made another way)."""
        if np is None or backend_wanted() == "off":
            return False
        try:
            meta = json.loads((self.dir / "meta.json").read_text())
            want = backend_wanted()
            if meta["backend"] != want or (want == "model" and meta.get("model") != settings.embed_model):
                return False
            self.backend = want
            if want == "lsa":
                with open(self.dir / "lsa.pkl", "rb") as fh:
                    self._lsa = pickle.load(fh)
            j = json.loads((self.dir / "ids.json").read_text())
            t = json.loads((self.dir / "themes.json").read_text())
            self._install(j["ids"], np.load(self.dir / "vectors.npy"), t["themes"], {int(k): v for k, v in t["of"].items()},
                          np.load(self.dir / "centroids.npy"))
            return self.ready
        except FileNotFoundError:
            return False
        except Exception as e:
            log.warning("Could not read the meaning index, it will be rebuilt: %s", e)
            return False

    # ---------------------------------------------------------------- use
    @property
    def floor(self) -> float:
        """How close in meaning a title must be to count. The model's scores run higher than LSA's."""
        return settings.semantic_min if settings.semantic_min else (0.42 if self.backend == "model" else 0.25)

    def search(self, text: str, k: int = 60) -> list[tuple[int, float]]:
        if not self.ready or not text.strip():
            return []
        q = self.encode([text])[0]
        with self.lock:
            sims = self.vecs @ q
            ids = self.ids
        if not len(sims):
            return []
        top = np.argsort(-sims)[: k * 2]
        best = float(sims[top[0]])
        cut = max(self.floor, best * 0.75)
        return [(ids[i], float(sims[i])) for i in top if sims[i] >= cut][:k]

    def nearest_theme(self, texts: list[str]) -> list[int]:
        if not self.ready or self.centroids is None or not len(self.centroids) or not texts:
            return [-1] * len(texts)
        V = self.encode(texts)
        return [int(x) for x in np.argmax(V @ self.centroids.T, axis=1)]

    def theme(self, tid: int) -> dict | None:
        return self.themes[tid] if 0 <= tid < len(self.themes) else None

    def status(self) -> dict:
        return {"ready": self.ready, "backend": self.backend, "building": self.building, "themes": len(self.themes),
                "titles": len(self.ids)}


# ---------------------------------------------------------------- themes
GENERIC = set("""india indian history general study studies introduction handbook text textbook theory theories principles
methods applications analysis research science sciences guide basic fundamentals advanced edition volume vol series case
cases new modern selected collected essays papers proceedings conference international national""".split())


def make_themes(V, ids: list[int], books: dict):
    """Group titles into themes with k-means and name each from the subject headings that set it apart."""
    n = len(ids)
    if n < 4:
        return [], {}, np.zeros((0, V.shape[1] if len(V.shape) == 2 else 1), np.float32)
    from sklearn.cluster import MiniBatchKMeans
    k = settings.themes if settings.themes else int(round(math.sqrt(n / 2)))
    k = max(2, min(k, 200, n // 3))
    km = MiniBatchKMeans(n_clusters=k, random_state=0, n_init=3, batch_size=2048).fit(V)
    labels = km.labels_
    cents = km.cluster_centers_.astype(np.float32)
    cents /= np.maximum(np.linalg.norm(cents, axis=1, keepdims=True), 1e-9)
    members: dict[int, list[int]] = {}
    for bid, lab in zip(ids, labels):
        members.setdefault(int(lab), []).append(bid)
    # class-based TF-IDF over subject-heading words and title words
    tf = {c: Counter() for c in members}
    heads = {c: Counter() for c in members}
    for c, bids in members.items():
        for bid in bids:
            b = books[bid]
            for s in b.get("subj", []):
                h = s.split(" -- ")[0].strip().rstrip(".")
                if h:
                    heads[c][h] += 1
            for w in re.findall(r"[a-z]+", (b.get("t", "") + " " + " ".join(b.get("subj", []))).lower()):
                if len(w) > 3 and w not in GENERIC:
                    tf[c][w] += 1
    df = Counter()
    for c in tf:
        df.update(tf[c].keys())
    avg = sum(sum(t.values()) for t in tf.values()) / max(len(tf), 1)
    themes, of = [], {}
    order = sorted(members, key=lambda c: -len(members[c]))
    remap = {c: i for i, c in enumerate(order)}
    for c in order:
        score = {w: (f / max(sum(tf[c].values()), 1)) * math.log(1 + avg / df[w]) for w, f in tf[c].items()}
        top = [w for w, _ in sorted(score.items(), key=lambda x: -x[1])[:5]]
        size = len(members[c])
        name = ""
        if heads[c]:
            h, cnt = heads[c].most_common(1)[0]
            if cnt >= max(2, 0.15 * size):
                name = h
                second = [x for x, m in heads[c].most_common(3)[1:] if m >= max(2, 0.12 * size) and x != h]
                if second:
                    name += " · " + second[0]
        if not name:
            name = ", ".join(w.capitalize() for w in top[:3]) or "Miscellaneous"
        dd = Counter((books[b].get("dd") or "")[:3] for b in members[c] if books[b].get("dd")).most_common(1)
        themes.append({"id": remap[c], "name": name, "words": top, "size": size, "ddc": dd[0][0] if dd else ""})
        for bid in members[c]:
            of[bid] = remap[c]
    cents = cents[order]
    return themes, of, cents


def main():  # pragma: no cover - command line
    import argparse
    from .catalog import Catalog
    p = argparse.ArgumentParser(description="Build the meaning-search index and themes")
    p.add_argument("--force", action="store_true", help="re-encode every title, not just new or changed ones")
    a = p.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    cat = Catalog()
    if not cat.books:
        print(f"No titles found in {cat.path}. Copy the data folder from the previous version (or set DATA_DIR in .env), "
              "or run  python -m app.sync  first.")
        raise SystemExit(1)
    print(Semantic().build(cat.books, force=a.force, progress=True))


if __name__ == "__main__":
    main()
