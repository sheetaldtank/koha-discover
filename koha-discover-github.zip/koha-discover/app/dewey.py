"""A subject map built from Dewey Decimal class numbers, used for browsing and for "semantic" search.

The tree has three levels the reader sees: 10 main classes (5 = Science), 100 divisions (54 = Chemistry) and
1,000 sections (541).

Names come from one of two places:
- OCLC's official DDC Summaries, when the library has made data/ddc-names.csv from them with
  `python -m app.ddcnames <ddc23-summaries.pdf>`. The file stays on the library's own computer and is not part of
  the code, because OCLC owns the copyright in the DDC. When it is loaded, the app shows OCLC's notice.
- Otherwise built-in plain-language names for classes and divisions, and for sections the heading used most often
  by this library's books in that section (541 -> "Physical chemistry").

Each section also gets a word profile learned from the titles and subject headings of its books. A search for
"thermodynamics" scores every section by those words and adds books from the best sections, even when the word
is not in their own record.
"""
from __future__ import annotations

import math
import re
from collections import Counter, defaultdict

from .catalog import STOP, stem, words
from .config import settings

CLASSES = {
    "0": "Computers, information and general works", "1": "Philosophy and psychology", "2": "Religion",
    "3": "Social sciences", "4": "Language", "5": "Science", "6": "Technology and engineering",
    "7": "Arts and recreation", "8": "Literature", "9": "History and geography",
}
DIVISIONS = {
    "00": "Computer science and general works", "01": "Bibliographies", "02": "Library and information science",
    "03": "Encyclopedias", "04": "Special topics", "05": "Magazines and serials", "06": "Associations and museums",
    "07": "News media and journalism", "08": "General collections", "09": "Manuscripts and rare books",
    "10": "Philosophy", "11": "Metaphysics", "12": "Knowledge and causation", "13": "Parapsychology",
    "14": "Philosophical schools of thought", "15": "Psychology", "16": "Logic", "17": "Ethics",
    "18": "Ancient, medieval and eastern philosophy", "19": "Modern western philosophy",
    "20": "Religion", "21": "Philosophy of religion", "22": "The Bible", "23": "Christianity", "24": "Christian practice",
    "25": "Christian pastoral practice", "26": "Christian organisation", "27": "History of Christianity",
    "28": "Christian denominations", "29": "Other religions",
    "30": "Social sciences and sociology", "31": "Statistics", "32": "Political science", "33": "Economics", "34": "Law",
    "35": "Public administration and military science", "36": "Social problems and services", "37": "Education",
    "38": "Commerce, communications and transport", "39": "Customs, etiquette and folklore",
    "40": "Language", "41": "Linguistics", "42": "English language", "43": "German language", "44": "French language",
    "45": "Italian and Romanian languages", "46": "Spanish and Portuguese languages", "47": "Latin",
    "48": "Classical Greek", "49": "Other languages",
    "50": "Science", "51": "Mathematics", "52": "Astronomy", "53": "Physics", "54": "Chemistry",
    "55": "Earth sciences and geology", "56": "Palaeontology", "57": "Life sciences and biology", "58": "Plants (botany)",
    "59": "Animals (zoology)",
    "60": "Technology", "61": "Medicine and health", "62": "Engineering", "63": "Agriculture",
    "64": "Home and family management", "65": "Management and business", "66": "Chemical engineering",
    "67": "Manufacturing", "68": "Manufacture for specific uses", "69": "Building and construction",
    "70": "Arts", "71": "Landscape and area planning", "72": "Architecture", "73": "Sculpture and metalwork",
    "74": "Drawing and decorative arts", "75": "Painting", "76": "Graphic arts and printmaking",
    "77": "Photography and computer art", "78": "Music", "79": "Sports, games and entertainment",
    "80": "Literature and rhetoric", "81": "American literature in English", "82": "English literature",
    "83": "German literature", "84": "French literature", "85": "Italian literature",
    "86": "Spanish and Portuguese literature", "87": "Latin literature", "88": "Classical Greek literature",
    "89": "Other literatures (including Indian)",
    "90": "History", "91": "Geography and travel", "92": "Biography and genealogy", "93": "Ancient history",
    "94": "History of Europe", "95": "History of Asia (including India)", "96": "History of Africa",
    "97": "History of North America", "98": "History of South America", "99": "History of other areas",
}

OFFICIAL: dict[str, str] = {}  # "541" -> official DDC Summaries caption, when loaded
NOTICE = ("All copyright rights in the Dewey Decimal Classification system are owned by OCLC. Dewey, Dewey Decimal "
          "Classification, DDC and WebDewey are registered trademarks of OCLC.")


def names_file():
    return settings.data_dir / "ddc-names.csv"


def load_official() -> dict[str, str]:
    import csv
    OFFICIAL.clear()
    f = names_file()
    if f.is_file():
        with f.open(encoding="utf-8-sig", newline="") as fh:
            for row in csv.reader(fh):
                if len(row) >= 2 and re.fullmatch(r"\d{3}", row[0].strip()) and row[1].strip():
                    OFFICIAL[row[0].strip()] = row[1].strip()
    return OFFICIAL


_NUM = re.compile(r"^\s*(?:[A-Za-z]{1,4}\s+)?(\d{3})(?:\.(\d+))?")


def class_number(b: dict) -> str:
    """The Dewey number of a record: 082 first, else the call number when it starts with one."""
    for v in (b.get("ddc"), b.get("call")):
        m = _NUM.match(v or "")
        if m:
            return m.group(1) + ("." + m.group(2) if m.group(2) else "")
    return ""


def label(code: str, sections: dict | None = None) -> str:
    """Name of a class (1 digit), division (2) or section (3)."""
    if len(code) == 1:
        return OFFICIAL.get(code + "00") or CLASSES.get(code, "")
    if len(code) == 2:
        return OFFICIAL.get(code + "0") or DIVISIONS.get(code, "")
    return OFFICIAL.get(code) or (sections or {}).get(code) or label(code[:2])


def display(code: str) -> str:
    """How a code is written on screen: 5 -> 500, 54 -> 540, 541 -> 541."""
    return code.ljust(3, "0") if len(code) < 3 else code


class Ontology:
    def __init__(self, books: dict):
        load_official()
        self.by_section: dict[str, list[int]] = defaultdict(list)
        heads: dict[str, Counter] = defaultdict(Counter)
        prof: dict[str, Counter] = defaultdict(Counter)
        for b in books.values():
            num = class_number(b)
            b["dd"] = num
            if not num:
                continue
            sec = num[:3]
            self.by_section[sec].append(b["id"])
            for s in b.get("subj", [])[:3]:
                heads[sec][s.split(" -- ")[0].strip()] += 1
            for w in words(b["t"] + " " + (b.get("st") or "") + " " + " ".join(b.get("subj", []))):
                if len(w) > 2 and w not in STOP and not w.isdigit():
                    prof[sec][stem(w)] += 1
        self.sections = {}
        for sec, c in heads.items():
            top, n = c.most_common(1)[0] if c else ("", 0)
            self.sections[sec] = OFFICIAL.get(sec) or (top if n >= 2 else "")
        # word profile per section, with the class, division and official section names mixed in
        for sec in list(prof) + [d + "0" for d in DIVISIONS]:
            for w in words(label(sec[:2]) + " " + label(sec[:1]) + " " + OFFICIAL.get(sec, "")):
                if w not in STOP:
                    prof[sec][stem(w)] += 3
        df = Counter()
        for c in prof.values():
            df.update(c.keys())
        n = max(len(prof), 1)
        self.idf = {w: math.log(n / d) for w, d in df.items()}
        self.prof = {sec: {w: (1 + math.log(c)) * self.idf[w] for w, c in cnt.items()} for sec, cnt in prof.items()}
        self.term_index: dict[str, list[tuple[str, float]]] = defaultdict(list)
        for sec, p in self.prof.items():
            for w, v in p.items():
                self.term_index[w].append((sec, v))

    def name(self, code: str) -> str:
        return label(code, self.sections)

    def path(self, num: str) -> list[dict]:
        """Breadcrumb for a Dewey number: 541.3 -> [500 Science, 540 Chemistry, 541 Physical chemistry]."""
        if not num:
            return []
        out = []
        for code in (num[:1], num[:2], num[:3]):
            # a section without its own name is shown by number only, not as a repeat of its division
            name = self.sections.get(code, "") if len(code) == 3 else self.name(code)
            if len(code) < 3 and not name:
                continue
            if len(code) == 3 and code.endswith("0") and (not name or name == self.name(code[:2])):
                continue  # 540 with no name of its own is just the division again
            out.append({"code": code, "num": display(code), "name": name})
        return out

    def related(self, kw: list[str], k: int = 3) -> list[tuple[str, float]]:
        """Sections whose books are most about these words, best first, with a 0-1 strength."""
        score: Counter = Counter()
        for w in kw:
            if w in STOP:
                continue
            hits = self.term_index.get(stem(w), [])
            for sec, v in hits:
                if len(sec) == 3 and sec in self.by_section:
                    score[sec] += v
        if not score:
            return []
        best = score.most_common(k * 3)
        top = best[0][1]
        return [(s, v / top) for s, v in best if v >= top * 0.45][:k]

    def children(self, code: str, books: dict, ids=None) -> list[dict]:
        """Next level down from a class or division, with how many books each holds."""
        counts: Counter = Counter()
        width = len(code) + 1
        for sec, bids in self.by_section.items():
            if sec.startswith(code):
                counts[sec[:width]] += len(bids) if ids is None else sum(1 for i in bids if i in ids)
        out = [{"code": c, "num": display(c), "name": self.name(c) or "Other", "count": n} for c, n in counts.items() if n]
        return sorted(out, key=lambda x: x["code"])
