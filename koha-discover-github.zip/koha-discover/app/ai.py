"""Claude features. Every function returns None when Claude isn't configured or a call fails,
and the caller falls back to the built-in rules, so the catalogue keeps working without an API key."""
from __future__ import annotations

import base64
import json
import logging

from .config import settings

log = logging.getLogger("discover.ai")
_client = None

if settings.ai_enabled:
    import anthropic

    _client = anthropic.Anthropic(api_key=settings.anthropic_api_key, timeout=60, max_retries=2)


def _nullable(t, **extra):
    return {"anyOf": [{"type": t, **extra}, {"type": "null"}]}


QUERY_SCHEMA = {
    "type": "object",
    "properties": {
        "keywords": {"type": "array", "items": {"type": "string"},
                     "description": "Topic words to match in titles, subjects and summaries, with spelling fixed."},
        "corrected_query": _nullable("string"),
        "author": _nullable("string", description="Only when the patron wants books written BY this person."),
        "about_topic": {"type": "boolean",
                        "description": "True when the patron wants books ABOUT a person or topic (on, about, life of, biography of)."},
        "year_min": _nullable("integer"),
        "year_max": _nullable("integer"),
        "format": _nullable("string", enum=["Book", "eBook", "Audiobook", "DVD"]),
        "audience": _nullable("string", enum=["Children", "Young adult", "General"]),
        "language": _nullable("string"),
        "fiction": _nullable("boolean"),
        "available_only": {"type": "boolean"},
        "similar_to_title": _nullable("string"),
        "describes_cover": {"type": "boolean",
                            "description": "True when the reader is describing what the cover looks like."},
        "isbn": _nullable("string"),
    },
    "required": ["keywords", "corrected_query", "author", "about_topic", "year_min", "year_max", "format", "audience", "language",
                 "fiction", "available_only", "similar_to_title", "describes_cover", "isbn"],
    "additionalProperties": False,
}

QUERY_SYSTEM = """You turn a library patron's search request into catalogue search parameters.
Patrons write casually, misspell words, and mix English with Indian languages. Fix spelling in keywords and author names.
Keywords are the topic words only: leave out words like "books", "about", "find me", and anything captured by another field.
"Books by Gandhi" means the author is Gandhi. "Books on Gandhi" or "about Gandhi" means Gandhi is the subject:
put the name in keywords, set about_topic, and leave author null.
For a cover description such as "blue cover with a lighthouse", set describes_cover and put the visual words (colours, objects) in keywords.
Set corrected_query only when you changed the spelling of something the patron typed. The current year is {year}."""


def _call(system: str, content, schema: dict | None = None, max_tokens=2000, effort="low", messages=None):
    if not _client:
        return None
    try:
        kw = {}
        if schema:
            kw["output_config"] = {"effort": effort, "format": {"type": "json_schema", "schema": schema}}
        else:
            kw["output_config"] = {"effort": effort}
        resp = _client.beta.messages.create(
            model=settings.claude_model, max_tokens=max_tokens, system=system,
            messages=messages or [{"role": "user", "content": content}],
            betas=["server-side-fallback-2026-07-01"], fallbacks="default", **kw)
        if resp.stop_reason == "refusal":
            log.warning("Claude declined the request: %s", getattr(resp, "stop_details", None))
            return None
        text = "".join(b.text for b in resp.content if b.type == "text").strip()
        return json.loads(text) if schema else text
    except Exception as e:  # network, rate limits, bad JSON: fall back to rules
        log.warning("Claude call failed, using built-in rules instead: %s", e)
        return None


def parse_query(q: str, year: int) -> dict | None:
    return _call(QUERY_SYSTEM.format(year=year), q, QUERY_SCHEMA, max_tokens=1500)


EXPLAIN_SCHEMA = {"type": "object", "properties": {"points": {"type": "array", "items": {"type": "string"}}},
                  "required": ["points"], "additionalProperties": False}
EXPLAIN_SYSTEM = """You help library patrons understand what a catalogue record describes.
From the MARC notes and subjects, write 3 to 6 short, plain sentences: what kind of item it is and who it suits,
what it is about, how it is organised, and anything useful (awards, edition, language, length).
Use only facts present in the record. Do not praise the book or invent details."""


def explain_record(b: dict) -> list[str] | None:
    rec = {k: b.get(k) for k in ("t", "st", "a", "y", "f", "l", "aud", "fic", "pg", "subj", "n", "ser")}
    out = _call(EXPLAIN_SYSTEM, json.dumps(rec, ensure_ascii=False), EXPLAIN_SCHEMA, max_tokens=1500)
    return out["points"] if out else None


COVER_SYSTEM = """Describe this book cover in one or two sentences, the way a reader would remember it:
the main colours, the picture or objects, people, and how the title is lettered.
Do not guess the book's title or author unless the words are clearly visible. Plain words, no preamble."""


def describe_cover(image: bytes, media_type: str) -> str | None:
    content = [{"type": "image", "source": {"type": "base64", "media_type": media_type, "data": base64.b64encode(image).decode()}},
               {"type": "text", "text": "Describe this cover."}]
    return _call(COVER_SYSTEM, content, max_tokens=600)


PHOTO_SCHEMA = {"type": "object", "properties": {"isbn": _nullable("string"), "title": _nullable("string"),
                                                 "author": _nullable("string", description="Only when the patron wants books written BY this person."),
        "about_topic": {"type": "boolean",
                        "description": "True when the patron wants books ABOUT a person or topic (on, about, life of, biography of)."}, "cover_description": {"type": "string"}},
                "required": ["isbn", "title", "author", "cover_description"], "additionalProperties": False}
PHOTO_SYSTEM = """A library patron sent a photo of a book, its cover, spine or barcode. Read any ISBN digits, the title and the author
exactly as printed. Use null for anything you cannot read clearly. Also describe the cover briefly in plain words."""


def read_photo(image: bytes, media_type: str) -> dict | None:
    content = [{"type": "image", "source": {"type": "base64", "media_type": media_type, "data": base64.b64encode(image).decode()}},
               {"type": "text", "text": "What book is this?"}]
    return _call(PHOTO_SYSTEM, content, PHOTO_SCHEMA, max_tokens=800)


def ai_to_parsed(cat, ai: dict) -> dict:
    """Map Claude's answer onto the same filter shape the rule parser produces."""
    f: dict = {}
    if ai.get("isbn"):
        f["isbn"] = "".join(c for c in ai["isbn"] if c.isdigit() or c in "xX").lower()
    for src, dst in (("year_min", "ymin"), ("year_max", "ymax"), ("format", "format"), ("language", "lang")):
        if ai.get(src):
            f[dst] = ai[src]
    if ai.get("audience") and ai["audience"] != "General":
        f["aud"] = ai["audience"]
    if ai.get("fiction") is not None:
        f["fic"] = ai["fiction"]
    if ai.get("available_only"):
        f["avail"] = True
    if ai.get("describes_cover"):
        f["cover"] = True
    if ai.get("about_topic"):
        f["about"] = True
    choices: list = []
    if ai.get("author"):
        from .search import set_author
        set_author(cat, f, ai["author"], choices)
    if ai.get("similar_to_title"):
        seed = cat.find_title(ai["similar_to_title"])
        if seed:
            f["similar"] = seed["id"]
    from .catalog import STOP, words
    kw = [w for k in ai.get("keywords", []) for w in words(k) if w not in STOP and len(w) > 1]
    out = {"f": f, "kw": kw}
    if choices:
        out["choices"] = choices
    return out


# ---------------------------------------------------------------- v5: Ask the librarian
ASK_SCHEMA = {
    "type": "object",
    "properties": {
        "reply": {"type": "string", "description": "2 to 4 short sentences to the reader, in the reader's language."},
        "picks": {"type": "array", "items": {
            "type": "object",
            "properties": {"id": {"type": "integer"}, "why": {"type": "string", "description": "One sentence: why it suits this reader."}},
            "required": ["id", "why"], "additionalProperties": False}},
        "try_search": _nullable("string", description="A better catalogue search if the titles given do not answer the question."),
    },
    "required": ["reply", "picks", "try_search"],
    "additionalProperties": False,
}
ASK_SYSTEM = """You are the reference librarian of {library}, helping students and staff on the library's catalogue site.
Each question comes with titles found in this library's own catalogue (JSON, with ids). Recommend only from those titles,
by id: never mention a book that is not in the list, and never invent details. Pick the 3 to 8 that best fit what the reader
asked (level, purpose, topic), best first, and say in one sentence each why it fits. Mention when a title is on loan (av = 0)
or is a course reserve (CR: read in the library) or short loan (SL: 3-day issue).
If none of the titles fit, say so plainly, pick nothing, and suggest a better search in try_search.
If the reader asks something that is not about finding books or library resources, answer briefly and steer back to books.
Be warm and brief. Plain text, no Markdown. Reply in the language the reader writes in."""


def ask(history: list[dict], candidates: list[dict], library: str) -> dict | None:
    """history: [{"role": "user"|"assistant", "content": str}], the last one the reader's new question.
    candidates: compact catalogue records. Only the question and public catalogue data are sent, never who is asking."""
    msgs = [{"role": m["role"], "content": m["content"]} for m in history[:-1]]
    msgs.append({"role": "user", "content": "Titles found in the catalogue for this question:\n"
                 + json.dumps(candidates, ensure_ascii=False) + "\n\nReader's question: " + history[-1]["content"]})
    return _call(ASK_SYSTEM.format(library=library), None, ASK_SCHEMA, max_tokens=4000, effort="low", messages=msgs)
