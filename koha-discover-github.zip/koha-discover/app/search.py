"""Natural-language search: understand the question, fix spelling, rank results, and explain titles."""
from __future__ import annotations

import re
from collections import Counter
from datetime import date

from .catalog import FMT, LANGS, STOP, SYN, Catalog, norm, words

YEAR = date.today().year


# ---------------------------------------------------------------- rule-based understanding
def parse(cat: Catalog, q: str) -> dict:
    """Return {"f": filters, "kw": keywords}. Filters: isbn, ymin, ymax, avail, aud, fic, lang, format, similar, author, cover."""
    s = " " + re.sub(r"[?!.,]", " ", norm(q)) + " "
    s = re.sub(r"(\d)-(?=\d)", r"\1", s)
    f: dict = {}

    def cut(pattern):
        nonlocal s
        m = re.search(pattern, s)
        if m:
            s = s.replace(m.group(0), " ", 1)
        return m

    if m := cut(r"\b(97[89]\d{10}|\d{9}[\dx])\b"):
        f["isbn"] = m.group(1)
    if m := cut(r"\bbetween (\d{4}) and (\d{4})\b"):
        f["ymin"], f["ymax"] = int(m.group(1)), int(m.group(2))
    if m := cut(r"\b(?:published |written |released )?(?:after|since|post) (\d{4})\b"):
        f["ymin"] = int(m.group(1)) + (0 if "since" in m.group(0) else 1)
    if m := cut(r"\b(?:published |written )?(?:before|pre|until) (\d{4})\b"):
        f["ymax"] = int(m.group(1)) - 1
    if m := cut(r"\b(?:from the |in the |the )?(\d{3})0s\b"):
        f["ymin"] = int(m.group(1) + "0"); f["ymax"] = f["ymin"] + 9
    if m := cut(r"\b(?:published |from |in )(\d{4})\b"):
        f["ymin"] = f["ymax"] = int(m.group(1))
    if cut(r"\b(recent|latest|new|newest)\b"):
        f["ymin"] = YEAR - 10
    if cut(r"\b(available(?: now)?|on the shelf|on shelf|in stock|can borrow(?: now)?|borrow now)\b"):
        f["avail"] = True
    if cut(r"\b(kids?|children'?s?|child|my (?:son|daughter)|\d{1,2} year olds?)\b"):
        f["aud"] = "Children"
    if cut(r"\b(teens?|teenagers?|young adults?|ya)\b"):
        f["aud"] = "Young adult"
    if cut(r"\b(non ?fiction)\b"):
        f["fic"] = False
    elif cut(r"\b(novels?|fiction)\b"):
        f["fic"] = True
    if m := cut(r"\b(?:in )?(" + "|".join(LANGS) + r")\b"):
        f["lang"] = LANGS[m.group(1)]
    if m := cut(r"\b(?:on |as (?:an? )?)?(" + "|".join(FMT) + r")\b"):
        f["format"] = FMT[m.group(1)]
    if m := cut(r"\b(?:similar to|books like|something like|anything like|more like|like the book)\s+(.+)$"):
        seed = cat.find_title(m.group(1))
        if seed:
            f["similar"] = seed["id"]
        else:
            s += " " + m.group(1)
    choices = []
    if m := cut(r"\b(?:written |edited )?by ([a-z.' ]+?)(?=\s+(?:about|on|regarding|after|before|since|published|from|in)\b|\s*$)"):
        if not set_author(cat, f, m.group(1), choices):
            s += " " + m.group(1)
    # "on X", "about X", "life of X": what the book is about, so the author field is not searched
    if cut(r"\b(?:on|about|regarding|concerning|related to|relating to|(?:the )?(?:life|lives|biography|biographies|history|works?|philosophy|ideas|thoughts?) of)\b"):
        f["about"] = True
    if re.search(r"\b(covers?|front|picture on)\b", s):
        f["cover"] = True
    kw = [w for w in words(s) if w not in STOP and len(w) > 1]
    intents = []
    if "author" not in f and "authors" not in f and not f.get("about") and not f.get("cover") and kw:
        # One name typed on its own ("gandhi"): if it is both an author and a subject, offer both readings
        name = " ".join(kw)
        found = cat.authors_like(name) if len(kw) <= 3 else []
        if found:
            if cat.on_subject(kw):
                label = name.title() if len(found) > 1 else found[0][0]
                intents = [{"label": f"Books by {label}", "q": f"books by {name}"},
                           {"label": f"Books about {label}", "q": f"books about {name}"}]
            elif set_author(cat, f, name, choices):
                kw = []
        if not found:
            for w in kw:
                a = cat.match_author(w, strict=True)
                if a and not any(w in words(b["t"] + " " + " ".join(b.get("subj", []))) for b in cat.books.values()):
                    f["author"] = a
                    kw.remove(w)
                    break
    out = {"f": f, "kw": kw}
    if choices:
        out["choices"] = choices
    if intents:
        out["intents"] = intents
    return out


def set_author(cat: Catalog, f: dict, text: str, choices: list) -> bool:
    """Set the author filter from a typed name. Several authors share it ("gandhi"): keep them all and list them."""
    found = cat.authors_like(text)
    if len(found) == 1:
        f["author"] = found[0][0]
        return True
    if found:
        f["authors"] = [a for a, _ in found[:12]]
        choices += [{"name": a, "count": n} for a, n in found[:12]]
        return True
    a = cat.match_author(text)
    if a:
        f["author"] = a
        return True
    return False


def spellcheck(cat: Catalog, q: str) -> str | None:
    changed = False

    def fix(m):
        nonlocal changed
        c = cat.correct_word(norm(m.group(0)).replace("'", ""))
        if c:
            changed = True
            return c
        return m.group(0)

    out = re.sub(r"[A-Za-zÀ-ÿ']+", fix, q)
    return out if changed else None


def isbn10(i: str) -> str:
    if not i.startswith("978") or len(i) != 13:
        return ""
    c = i[3:12]
    d = (11 - sum((10 - k) * int(c[k]) for k in range(9)) % 11) % 11
    return c + ("x" if d == 10 else str(d))


# ---------------------------------------------------------------- ranking
def run_search(cat: Catalog, parsed: dict, meaning: bool = True) -> list[dict]:
    f, kw = parsed["f"], parsed["kw"]
    books = cat.books
    results: list[dict] = []
    if f.get("similar") in books:
        seed = books[f["similar"]]
        seed_words = set(words(" ".join(seed.get("subj", []))))
        for b in books.values():
            if b["id"] == seed["id"]:
                continue
            ov = [s for s in b.get("subj", []) if s in seed.get("subj", [])]
            sw = {w for w in words(" ".join(b.get("subj", []))) if len(w) > 3 and w in seed_words}
            aud = 2 if b["aud"] == seed["aud"] else (1 if b["aud"] != "General" and seed["aud"] != "General" else 0)
            score = len(ov) * 3 + len(sw) + aud + (2 if b["fic"] == seed["fic"] else 0)
            if score >= 3:
                results.append({"id": b["id"], "score": score, "why": [[w, "subject"] for w in list(dict.fromkeys(ov + sorted(sw)))[:3]]})
    elif kw:
        scores: dict[int, list] = {}
        for k in kw:
            alts = [k] + SYN.get(k, [])
            best: dict[int, tuple] = {}
            for a in alts:
                hit: dict[int, list] = {}
                weights = ({"cover": 4.0, "title": 1.0} if f.get("cover") else
                           {"subj": 4.0, "title": 2.0, "notes": 1.5} if f.get("about") else
                           {"title": 3.0, "auth": 3.0, "subj": 2.5, "notes": 1.0})
                for field, w in weights.items():
                    for bid in cat.matches(field, a):
                        h = hit.setdefault(bid, [0.0, field])
                        h[0] += w
                for bid, (sc, where) in hit.items():
                    if sc > best.get(bid, (0,))[0]:
                        best[bid] = (sc, where)
            for bid, (sc, where) in best.items():
                e = scores.setdefault(bid, [0.0, 0, []])
                e[0] += sc; e[1] += 1; e[2].append([k, where])
        n = len(kw)
        for bid, (sc, cov, why) in scores.items():
            if cov == n or (n > 2 and cov >= -(-n // 2)) or (f.get("cover") and cov >= min(2, n)):
                results.append({"id": bid, "score": cov * 10 + sc, "why": why})
        # Related subject areas from the Dewey map: add books shelved there that the words alone missed
        if not f.get("cover") and not f.get("isbn") and getattr(cat, "onto", None):
            found = {r["id"] for r in results}
            rel = cat.onto.related(kw)
            parsed["related"] = [{"code": sec, "name": cat.onto.name(sec), "strength": round(st, 2)} for sec, st in rel]
            for sec, st in rel:
                for bid in cat.onto.by_section.get(sec, []):
                    if bid not in found:
                        found.add(bid)
                        results.append({"id": bid, "score": 5 * st, "why": [[f"{sec} {cat.onto.name(sec)}", "subject area"]]})
        # Meaning: titles close in meaning to the words, blended with the word matches (reciprocal rank fusion)
        sem = getattr(cat, "sem", None)
        if meaning and sem and sem.ready and not f.get("cover") and not f.get("isbn"):
            try:
                hits = sem.search(" ".join(kw))
            except Exception as e:  # never let the meaning index break a search
                hits = []
                import logging
                logging.getLogger("discover.semantic").warning("meaning search failed: %s", e)
            if hits:
                parsed["semantic"] = True
                results = fuse(results, hits)
    else:
        results = [{"id": b["id"], "score": 0, "why": []} for b in books.values()]

    def ok(b):
        if f.get("isbn") and f["isbn"] not in (b.get("isbn"), isbn10(b.get("isbn") or "")):
            return False
        y = b.get("y") or 0
        if f.get("who") and f["who"] not in b.get("au", []) and f["who"] != b["a"]:
            return False
        if f.get("pub") and norm(b.get("pub") or "") != norm(f["pub"]):
            return False
        if f.get("subj") and f["subj"] not in b.get("subj", []) and not any(s.startswith(f["subj"] + " -- ") for s in b.get("subj", [])):
            return False
        if f.get("ddc") and not (b.get("dd") or "").replace(".", "").startswith(f["ddc"]):
            return False
        if "theme" in f and getattr(cat, "sem", None) and cat.sem.theme_of.get(b["id"]) != f["theme"]:
            return False
        if f.get("author") and f["author"] != b["a"] and f["author"] not in b.get("au", []):
            return False
        if f.get("authors") and not set(f["authors"]) & set(b.get("au") or [b["a"]]):
            return False
        return ( (not f.get("format") or b["f"] == f["format"])
                and (not f.get("lang") or b["l"] == f["lang"]) and (not f.get("aud") or b["aud"] == f["aud"])
                and ("fic" not in f or b["fic"] == f["fic"]) and (not f.get("avail") or b.get("av", 1) > 0)
                and (not f.get("ymin") or y >= f["ymin"]) and (not f.get("ymax") or (y and y <= f["ymax"])))

    results = [r for r in results if ok(books[r["id"]])]
    results.sort(key=lambda r: (-r["score"], -(books[r["id"]].get("y") or 0)))
    return results


def fuse(results: list[dict], hits: list[tuple[int, float]], k: int = 20) -> list[dict]:
    """Blend word-match results and meaning results by rank. A title found both ways rises to the top."""
    ranked = sorted(results, key=lambda r: -r["score"])
    out = {r["id"]: dict(r, score=1.0 / (k + i + 1)) for i, r in enumerate(ranked)}
    for i, (bid, sim) in enumerate(hits):
        add = 0.8 / (k + i + 1)
        if bid in out:
            out[bid]["score"] += add
        else:
            out[bid] = {"id": bid, "score": add, "why": [["close in meaning", "meaning"]]}
    for r in out.values():
        r["score"] = round(r["score"] * 1000, 3)
    return list(out.values())


def facets(cat: Catalog, ids: list[int]) -> dict:
    out = {"format": {}, "aud": {}, "lang": {}, "avail": {}, "ddc": {}, "who": {}, "pub": {}, "subj": {}}
    for i in ids:
        b = cat.books[i]
        if b.get("dd"):
            d = b["dd"][:2]
            out["ddc"][d] = out["ddc"].get(d, 0) + 1
        for a in b.get("au", [])[:3]:
            out["who"][a] = out["who"].get(a, 0) + 1
        if b.get("pub"):
            out["pub"][b["pub"]] = out["pub"].get(b["pub"], 0) + 1
        for sj in b.get("subj", [])[:4]:
            out["subj"][sj] = out["subj"].get(sj, 0) + 1
        for k, v in (("format", b["f"]), ("aud", b["aud"]), ("lang", b["l"])):
            if v:
                out[k][v] = out[k].get(v, 0) + 1
        if b.get("av", 1) > 0:
            out["avail"]["Available now"] = out["avail"].get("Available now", 0) + 1
    res = {k: sorted(v.items(), key=lambda x: -x[1]) for k, v in out.items()}
    for k in ("who", "pub", "subj"):
        res[k] = [x for x in res[k] if x[1] > 1 or len(ids) < 30][:8]
    onto = getattr(cat, "onto", None)
    res["ddc"] = [[c, n, f"{c}0 {onto.name(c) if onto else ''}".strip()] for c, n in res["ddc"][:10]]
    return res


# ---------------------------------------------------------------- notes in plain words (rule version)
def _kind(b):
    S = " ".join(b.get("subj", [])).lower()
    if b["f"] == "DVD":
        return "A documentary series" if "documentary" in S else "A film"
    if "short stories" in S:
        return "A collection of short stories"
    if "autobiography" in S or "memoir" in S:
        return "An audiobook memoir" if b["f"] == "Audiobook" else "A memoir"
    if "textbook" in S:
        return "A textbook"
    base = "novel" if b["fic"] else "non-fiction book"
    if b["f"] == "eBook":
        return f"An eBook, a {base},"
    if b["f"] == "Audiobook":
        return f"An audiobook, a {base},"
    return "A novel" if b["fic"] else "A non-fiction book"


def explain(b: dict) -> list[str]:
    if b.get("ai_explain"):
        return b["ai_explain"]
    n = b.get("n", {})
    a521 = f" ({n['521'].rstrip('.').lower()})" if n.get("521") else ""
    aud = {"Children": "for children" + a521, "Young adult": "for teenagers" + a521}.get(b["aud"], "for general readers")
    topics = [re.sub(r"\s*\(.*?\)", "", s).lower() for s in b.get("subj", [])
              if not re.search(r"fiction|textbooks|documentary|memoir|autobiography|short stories", s, re.I)][:3]
    about = (", ".join(topics[:-1]) + " and " + topics[-1]) if len(topics) > 1 else (topics[0] if topics else "")
    out = [f"{_kind(b)} {aud}{', written in ' + b['l'] if b['l'] and b['l'] != 'English' else ''}{', about ' + about if about else ''}."]
    if n.get("520"):
        out.append("In short: " + re.split(r"(?<=\.)\s", n["520"])[0])
    if n.get("505"):
        parts = [re.sub(r"^Part \w+\.\s*", "", p).strip() for p in n["505"].split(" -- ")]
        unit = "parts" if n["505"].startswith("Part") else "sections"
        out.append(f"It is organised in {len(parts)} {unit}, starting with “{parts[0]}” and ending with “{parts[-1]}”.")
    if n.get("586"):
        out.append("Award: " + n["586"].rstrip(".") + ".")
    if n.get("500"):
        out.append("Good to know: " + n["500"])
    if n.get("250"):
        out.append(f"This copy is the {n['250'].replace('ed.', 'edition').rstrip('.')}.")
    if b.get("pg") and b["f"] not in ("DVD", "Audiobook"):
        out.append(f"About {max(1, round(b['pg'] / 40))} hours of reading ({b['pg']} pages).")
    if b.get("min"):
        out.append(f"Running time about {round(b['min'] / 60)} hours.")
    return out


def one_line(b: dict) -> str:
    return re.split(r"(?<=\.)\s", b.get("n", {}).get("520") or explain(b)[0])[0]


# ---------------------------------------------------------------- recommendations
def recommend(cat: Catalog, b: dict, coborrow: dict) -> list[dict]:
    books = cat.books
    used = {b["id"]}
    out = []

    def take(ids, n):
        res = [i for i in ids if i not in used and i in books][:n]
        used.update(res)
        return res

    if b.get("ser"):
        items = sorted([x for x in books.values() if x.get("ser") and x["ser"][0] == b["ser"][0]], key=lambda x: x["ser"][1])
        if len(items) > 1:
            out.append({"k": "series", "h": f"{b['ser'][0]} series", "sub": f"This is book {b['ser'][1]}. Read them in order.",
                        "items": [[x["id"], f"Book {x['ser'][1]}" + (" · this one" if x["id"] == b["id"] else "")] for x in items]})
            used.update(x["id"] for x in items)
    au = take([x["id"] for x in sorted(books.values(), key=lambda x: -(x.get("y") or 0)) if x["a"] == b["a"]], 6)
    if au:
        out.append({"k": "author", "h": f"More by {b['a'].split(',')[0]}", "items": [[i, str(books[i].get("y") or "")] for i in au]})
    co = sorted(coborrow.get(b["id"], {}).items(), key=lambda x: -x[1])
    co_ids = take([i for i, _ in co], 4)
    if co_ids:
        cnt = dict(co)
        out.append({"k": "also", "h": "Readers who borrowed this also borrowed", "sub": "From anonymised borrowing history.",
                    "items": [[i, f"{cnt[i]} reader{'s' if cnt[i] != 1 else ''}"] for i in co_ids]})
    sim = cat.similar(b["id"], 10)
    why = {i: w for _, i, w in sim}
    sim_ids = take([i for _, i, _ in sim], 4)
    if sim_ids:
        out.append({"k": "abstract", "h": "Similar subject and summary", "sub": "Matched on the summary and subject notes.",
                    "items": [[i, "Shares: " + ", ".join(why[i])] for i in sim_ids]})
    gen = take([x["id"] for x in sorted(books.values(), key=lambda x: -(x.get("r") or 0)) if x.get("g") == b.get("g") and x["aud"] == b["aud"]], 4)
    if gen:
        out.append({"k": "genre", "h": f"More {str(b.get('g', '')).lower()}", "sub": "Highest rated first." if any(books[i].get("r") for i in gen) else None,
                    "items": [[i, f"★ {books[i]['r']:.1f}" if books[i].get("r") else str(books[i].get("y") or "")] for i in gen]})
    return out


def coborrow_counts(histories: list[list[int]]) -> dict:
    co: dict[int, dict[int, int]] = {}
    for h in histories:
        h = list(dict.fromkeys(h))
        for a in h:
            for c in h:
                if a != c:
                    co.setdefault(a, {})
                    co[a][c] = co[a].get(c, 0) + 1
    return co


# ---------------------------------------------------------------- picked for you
def picks_for(cat: Catalog, read: list[int], n: int = 12) -> list[list]:
    """Suggestions from one reader's borrowing: their most-read Dewey sections, authors and subject headings.
    Returns [[biblio_id, reason], ...]. Titles they already borrowed are left out; available, newer titles first."""
    books = cat.books
    read = [i for i in dict.fromkeys(read) if i in books]
    if not read:
        return []
    seen = set(read)
    sec_w, au_w, sj_w = Counter(), Counter(), Counter()
    source: dict = {}
    for rank, i in enumerate(read):
        b = books[i]
        w = 1.0 / (1 + rank * 0.1)  # recent borrowing counts a little more
        if b.get("dd"):
            sec_w[b["dd"][:3]] += w
            source.setdefault(("sec", b["dd"][:3]), i)
        for a in b.get("au", [])[:2]:
            au_w[a] += w
            source.setdefault(("au", a), i)
        for sj in b.get("subj", [])[:4]:
            sj_w[sj] += w
            source.setdefault(("sj", sj), i)
    scored = []
    for b in books.values():
        if b["id"] in seen:
            continue
        sec = (b.get("dd") or "")[:3]
        s_sec = sec_w.get(sec, 0) * 2
        s_au = max((au_w.get(a, 0) for a in b.get("au", [])), default=0) * 3
        hits = [sj for sj in b.get("subj", []) if sj in sj_w]
        s_sj = sum(sj_w[sj] for sj in hits) * 1.5
        score = s_sec + s_au + s_sj
        if score <= 0:
            continue
        score += (0.5 if b.get("av", 1) > 0 else 0) + ((b.get("y") or 1900) - 1900) / 400
        best = max([(s_au, "au", next((a for a in b.get("au", []) if a in au_w), None)),
                    (s_sj, "sj", hits[0] if hits else None), (s_sec, "sec", sec)], key=lambda x: x[0])
        scored.append((score, b["id"], best[1], best[2]))
    scored.sort(reverse=True)
    out, per_reason = [], Counter()
    for score, bid, kind, val in scored:
        if per_reason[(kind, val)] >= 4:  # keep the list varied
            continue
        per_reason[(kind, val)] += 1
        src = books[source.get((kind, val), read[0])]
        what = {"au": f"by {val}", "sj": f"on {val}", "sec": f"in {val} {cat.onto.name(val) if getattr(cat, 'onto', None) else ''}"}[kind]
        out.append([bid, f"Because you borrowed {src['t']} ({what.strip()})"])
        if len(out) >= n:
            break
    return out
