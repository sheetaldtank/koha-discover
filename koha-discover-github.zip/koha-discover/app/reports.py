"""Staff reports for display planning and collection development.

They read three things: the catalogue copy (titles, copies, how many are on loan now, accession dates, Dewey
numbers), and the anonymous search and view logs the app keeps. The logs hold the words searched, how many
results there were, which titles were opened, and when. They hold nothing about who searched.

Every report returns {"title", "about", "columns", "rows"}, so the same data can be shown on screen,
saved, or exported to CSV or Excel.
"""
from __future__ import annotations

import statistics
import time
from collections import Counter, defaultdict
from datetime import date, timedelta

from .catalog import Catalog, norm, words
from .dewey import display

REPORTS = {
    "top_searches": "Top searches",
    "zero_results": "Searches with no results",
    "demand": "Demand by subject",
    "display": "Display ideas",
    "new_by_subject": "New arrivals by subject",
    "age": "Collection age by subject",
    # v4: circulation
    "circ_summary": "Circulation summary",
    "top_titles": "Top 20 most-used titles",
    "least_titles": "20 least-used titles",
    "use_factor": "Well-used and under-used subjects",
    "use_by_class": "Use by main class",
    "borrowers": "Most active borrowers",
    "by_category": "Borrowing by patron category",
    "by_department": "Borrowing by department",
    "fines": "Fines by year",
    # v5: themes found by the meaning index
    "themes": "Themes readers search for",
}
GROUPS = {
    "Searches and displays": ["top_searches", "zero_results", "demand", "themes", "display", "new_by_subject", "age"],
    "Circulation": ["circ_summary", "top_titles", "least_titles", "use_factor", "use_by_class"],
    "Borrowers and fines": ["borrowers", "by_category", "by_department", "fines"],
}
NAMES_STAFF_ONLY = {"borrowers"}  # reports that list patrons by name


def period(days: int | None = 30, start: str | None = None, end: str | None = None) -> dict:
    """The report period, from a number of days back from today or from two dates (both included)."""
    if start or end:
        s = date.fromisoformat(start) if start else date(2000, 1, 1)
        e = date.fromisoformat(end) if end else date.today()
        if e < s:
            s, e = e, s
    else:
        e = date.today()
        s = e - timedelta(days=max(1, int(days or 30)) - 1)
    ts0 = time.mktime(s.timetuple())
    ts1 = time.mktime((e + timedelta(days=1)).timetuple())
    return {"start": s.isoformat(), "end": e.isoformat(), "ts0": ts0, "ts1": ts1, "days": (e - s).days + 1,
            "label": f"{s.isoformat()} to {e.isoformat()}"}


def _div(b: dict) -> str:
    return (b.get("dd") or "")[:2]


def _div_name(cat: Catalog, d: str) -> str:
    return f"{display(d)} {cat.onto.name(d)}".strip() if d else "No Dewey number"


def _search_counts(cat: Catalog, P: dict):
    return cat.run("SELECT lower(trim(q)), COUNT(*), AVG(n), SUM(n = 0), MAX(ts) FROM searchlog "
                   "WHERE ts >= ? AND ts < ? AND trim(q) != '' GROUP BY lower(trim(q)) ORDER BY COUNT(*) DESC",
                   (P["ts0"], P["ts1"]))


def top_searches(cat: Catalog, P: dict):
    rows = [[q, n, round(avg or 0), "Yes" if zero else ""] for q, n, avg, zero, _ in _search_counts(cat, P)[:100]]
    return {"columns": ["Search", "Times searched", "Average results", "Sometimes found nothing"], "rows": rows,
            "about": "What readers look for most. Use it to choose display themes and to check the catalogue answers well."}


def zero_results(cat: Catalog, P: dict):
    rows = []
    for q, n, avg, zero, last in _search_counts(cat, P):
        if not zero:
            continue
        rel = cat.onto.related(words(q), 1)
        area = f"{rel[0][0]} {cat.onto.name(rel[0][0])}".strip() if rel else ""
        rows.append([q, zero, date.fromtimestamp(last).isoformat(), area])
    rows.sort(key=lambda r: -r[1])
    return {"columns": ["Search", "Times with no results", "Last searched", "Nearest subject area"], "rows": rows[:200],
            "about": "Demand the collection does not meet yet. Candidates for purchase, or for better cataloguing "
                     "(missing subjects or alternative titles)."}


def _views(cat: Catalog, P: dict) -> Counter:
    return Counter({bid: n for bid, n in cat.run("SELECT biblio_id, COUNT(*) FROM viewlog WHERE ts >= ? AND ts < ? "
                                                 "GROUP BY biblio_id", (P["ts0"], P["ts1"]))})


def _searches_by_division(cat: Catalog, P: dict) -> Counter:
    out = Counter()
    for q, n, *_ in _search_counts(cat, P)[:2000]:
        rel = cat.onto.related(words(q), 1)
        if rel:
            out[rel[0][0][:2]] += n
    return out


def demand(cat: Catalog, P: dict):
    views, searches = _views(cat, P), _searches_by_division(cat, P)
    agg = defaultdict(lambda: [0, 0, 0, 0])  # titles, copies, on loan, views
    for b in cat.books.values():
        a = agg[_div(b)]
        a[0] += 1
        a[1] += b.get("tot") or 0
        a[2] += max((b.get("tot") or 0) - (b.get("av") or 0), 0)
        a[3] += views.get(b["id"], 0)
    rows = []
    for d, (t, c, out, v) in agg.items():
        rows.append([_div_name(cat, d), t, c, out, round(100 * out / c) if c else 0, v, searches.get(d, 0)])
    rows.sort(key=lambda r: (-r[4], -r[5]))
    return {"columns": ["Subject area", "Titles", "Copies", "On loan now", "% on loan", "Title views", "Searches"],
            "rows": rows,
            "about": "Busy and quiet shelves. A high share on loan with many searches suggests buying more; "
                     "a low share on loan with few views suggests promoting or weeding."}


def display_ideas(cat: Catalog, P: dict):
    views = _views(cat, P)
    dem = {r[0]: r for r in demand(cat, P)["rows"]}
    score_div = {name: r[4] + r[5] * 5 + r[6] for name, r in dem.items()}
    top_divs = {n for n, _ in sorted(score_div.items(), key=lambda x: -x[1])[:6]}
    rows = []
    for b in cat.books.values():
        name = _div_name(cat, _div(b))
        if name in top_divs and (b.get("av") or 0) > 0:
            rows.append([b["t"], b["a"], b.get("call", ""), b.get("av", 0), name, views.get(b["id"], 0), b.get("y") or ""])
    rows.sort(key=lambda r: (-r[5], -(r[6] or 0)))
    return {"columns": ["Title", "Author", "Call number", "Copies on shelf", "Subject area", "Views", "Year"], "rows": rows[:150],
            "about": "Titles on the shelf right now from the subject areas readers want most. Ready-made display candidates."}


def new_by_subject(cat: Catalog, P: dict):
    groups = defaultdict(list)
    for b in cat.books.values():
        if P["start"] <= (b.get("acq") or "") <= P["end"]:
            groups[_div(b)].append(b)
    rows = []
    for d, bs in groups.items():
        bs.sort(key=lambda b: b.get("acq", ""), reverse=True)
        rows.append([_div_name(cat, d), len(bs), "; ".join(b["t"] for b in bs[:3])])
    rows.sort(key=lambda r: -r[1])
    note = "" if any(b.get("acq") for b in cat.books.values()) else \
        " No accession dates yet: run python -m app.sync --availability-only."
    return {"columns": ["Subject area", "New titles", "Latest examples"], "rows": rows,
            "about": "Where recent purchases went, by accession date of the newest copy." + note}


def age(cat: Catalog, P: dict):  # the whole collection as it is today; the period is not used
    this_year = date.today().year
    years = defaultdict(list)
    for b in cat.books.values():
        if b.get("y"):
            years[_div(b)].append(b["y"])
    rows = []
    for d, ys in years.items():
        old = sum(1 for y in ys if this_year - y > 20)
        rows.append([_div_name(cat, d), len(ys), int(statistics.median(ys)), max(ys), round(100 * old / len(ys))])
    rows.sort(key=lambda r: r[2])
    return {"columns": ["Subject area", "Titles with a year", "Median year", "Newest", "% older than 20 years"], "rows": rows,
            "about": "How current each part of the collection is. Oldest first."}


from .circulation import (borrowers, by_category, by_department, circ_summary, fines, least_titles,  # noqa: E402
                          top_titles, use_by_class, use_factor)

FUNCS = {"top_searches": top_searches, "zero_results": zero_results, "demand": demand, "display": display_ideas,
         "new_by_subject": new_by_subject, "age": age, "circ_summary": circ_summary, "top_titles": top_titles,
         "least_titles": least_titles, "use_factor": use_factor, "use_by_class": use_by_class, "borrowers": borrowers,
         "by_category": by_category, "by_department": by_department, "fines": fines}
EXTRA_ARGS = {"fines": "rows from Koha", "borrowers": "names from Koha"}


def themes(cat: Catalog, P: dict):
    """Each logged search placed in its nearest theme, next to the theme's size and its loans in the period."""
    sem = getattr(cat, "sem", None)
    if not sem or not sem.ready:
        return {"columns": ["Theme"], "rows": [], "about": "The meaning index is not ready yet. Run  python -m app.semantic  once."}
    counts = _search_counts(cat, P)[:500]
    near = sem.nearest_theme([q for q, *_ in counts]) if counts else []
    searched, zero, examples = Counter(), Counter(), defaultdict(list)
    for (q, n, _avg, z, _), tid in zip(counts, near):
        searched[tid] += n
        zero[tid] += 1 if z else 0
        if len(examples[tid]) < 3:
            examples[tid].append(q)
    from .circulation import _loans
    loans = Counter()
    for bid, *_ in _loans(cat, P):
        if bid in sem.theme_of:
            loans[sem.theme_of[bid]] += 1
    rows = []
    for t in sem.themes:
        s_, l_ = searched.get(t["id"], 0), loans.get(t["id"], 0)
        if not s_ and not l_:
            continue
        rows.append([t["name"], s_, t["size"], l_, round(10 * s_ / t["size"], 1) if t["size"] else 0,
                     "; ".join(examples.get(t["id"], [])), ", ".join(t["words"][:4])])
    rows.sort(key=lambda r: (-r[1], -r[3]))
    return {"columns": ["Theme", "Searches", "Titles in theme", "Loans in period", "Searches per 10 titles",
                        "Example searches", "Theme words"], "rows": rows[:150],
            "about": "Themes are groups of titles the app found by meaning, across Dewey classes. Many searches per 10 "
                     "titles with few loans can mean readers want more on the theme than the shelf offers: a buying "
                     "signal. Busy themes with many loans make good displays."}


FUNCS["themes"] = themes


def build(cat: Catalog, kind: str, P: dict, extra: dict | None = None) -> dict:
    """extra carries data read live from Koha: {"names": {pid: {...}}} for borrowers, {"rows": [...]} for fines."""
    out = FUNCS[kind](cat, P, **(extra or {})) if kind in EXTRA_ARGS else FUNCS[kind](cat, P)
    return {"kind": kind, "title": REPORTS[kind], "days": P["days"], "start": P["start"], "end": P["end"],
            "made": date.today().isoformat(), **out}


def log_search(cat: Catalog, q: str, n: int, filters: dict):
    import json
    q = norm(q)[:200]
    cat.run("INSERT INTO searchlog VALUES(?,?,?,?)", (time.time(), q, n, json.dumps(filters, default=str)[:500]), commit=True)


def log_view(cat: Catalog, bid: int):
    cat.run("INSERT INTO viewlog VALUES(?,?)", (time.time(), bid), commit=True)
