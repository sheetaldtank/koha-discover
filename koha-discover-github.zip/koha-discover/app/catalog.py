"""Local search index of the catalogue, stored in SQLite and held in memory for fast searching.

Records come from Koha (scripts/sync.py) or from the sample data in demo mode. Enrichments that cost
time or money to make (cover descriptions, plain-language summaries) are cached in the same database.
"""
from __future__ import annotations

import bisect
import json
import math
import re
import sqlite3
import threading
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path

from .config import settings

# ---------------------------------------------------------------- text utilities
def norm(s: str) -> str:
    s = unicodedata.normalize("NFD", (s or "").lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn")


def words(s: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", norm(s))


def stem(w: str) -> str:
    return re.sub(r"(ing|es|s)$", "", w) if len(w) > 4 else w


STOP = set("""i me my we want wanted need looking look for find show give get some something any anything a an the books
book titles title about on of to read reading good best great with that this is are and or in by please can you have do does
what which who copy copies published written there now cover covers picture image photo front has had remember forgot forget
it was think called name color colour""".split())
SYN = {"ai": ["artificial", "intelligence"], "ml": ["machine", "learning"], "space": ["astronomy", "cosmology", "universe"],
       "universe": ["cosmology", "astronomy"], "environment": ["ecology", "environmental", "climate", "pollution"],
       "climate": ["climate", "warming"], "upsc": ["civil", "services", "polity"], "motivation": ["motivation", "self", "habit"],
       "happy": ["happiness"], "coding": ["programming", "algorithms"], "programming": ["programming", "algorithms"],
       "dna": ["genetics", "gene"], "biography": ["autobiography", "memoir", "biography"], "memoir": ["memoir", "autobiography"],
       "magic": ["magic", "wizards", "fantasy"], "psychology": ["psychology", "thinking", "behavior"],
       "libraries": ["library", "libraries"]}
FMT = {"ebook": "eBook", "ebooks": "eBook", "kindle": "eBook", "audiobook": "Audiobook", "audiobooks": "Audiobook",
       "dvd": "DVD", "dvds": "DVD", "film": "DVD", "films": "DVD", "movie": "DVD", "movies": "DVD",
       "documentary": "DVD", "documentaries": "DVD"}
LANGS = {"hindi": "Hindi", "marathi": "Marathi", "english": "English", "tamil": "Tamil", "telugu": "Telugu",
         "bengali": "Bengali", "gujarati": "Gujarati", "kannada": "Kannada", "malayalam": "Malayalam", "urdu": "Urdu",
         "sanskrit": "Sanskrit", "french": "French", "german": "German"}
EXTRA_VOCAB = ["after", "before", "since", "between", "recent", "latest", "new", "kids", "children", "childrens", "child",
               "teen", "teens", "teenagers", "young", "adult", "available", "shelf", "fiction", "nonfiction", "novel",
               "novels", "stories", "similar", "like", "more", "year", "years", "old"]
FIELDS = {"title": 3.0, "auth": 3.0, "subj": 2.5, "notes": 1.0, "cover": 1.0}


def edit_distance(a: str, b: str, mx: int) -> int:
    """Optimal string alignment distance, stopping early once it exceeds mx."""
    if abs(len(a) - len(b)) > mx:
        return mx + 1
    prev2, prev = None, list(range(len(b) + 1))
    for i in range(1, len(a) + 1):
        cur, row_min = [i] + [0] * len(b), i
        for j in range(1, len(b) + 1):
            v = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] != b[j - 1]))
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                v = min(v, prev2[j - 2] + 1)
            cur[j] = v
            row_min = min(row_min, v)
        if row_min > mx:
            return mx + 1
        prev2, prev = prev, cur
    return prev[-1]


class Catalog:
    def __init__(self, path: Path | None = None):
        settings.data_dir.mkdir(parents=True, exist_ok=True)
        self.path = path or settings.data_dir / "catalog.db"
        self.db = sqlite3.connect(self.path, check_same_thread=False)
        self.lock = threading.Lock()
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY, data TEXT NOT NULL, updated TEXT DEFAULT CURRENT_TIMESTAMP);
            CREATE TABLE IF NOT EXISTS enrich(id INTEGER PRIMARY KEY, cover_desc TEXT, explain TEXT, updated TEXT DEFAULT CURRENT_TIMESTAMP);
            CREATE TABLE IF NOT EXISTS reviews(rid INTEGER PRIMARY KEY AUTOINCREMENT, biblio_id INTEGER, patron_id INTEGER,
                who TEXT, rating INTEGER, text TEXT, status TEXT DEFAULT 'pending', created TEXT DEFAULT CURRENT_TIMESTAMP);
            CREATE TABLE IF NOT EXISTS cache(key TEXT PRIMARY KEY, value TEXT, expires REAL);
            CREATE TABLE IF NOT EXISTS marc(id INTEGER PRIMARY KEY, data TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS item_map(item_id INTEGER PRIMARY KEY, biblio_id INTEGER);
            -- v3: anonymous usage log for staff reports (no patron is ever recorded)
            CREATE TABLE IF NOT EXISTS searchlog(ts REAL, q TEXT, n INTEGER, filters TEXT);
            CREATE INDEX IF NOT EXISTS searchlog_ts ON searchlog(ts);
            CREATE TABLE IF NOT EXISTS viewlog(ts REAL, biblio_id INTEGER);
            CREATE INDEX IF NOT EXISTS viewlog_ts ON viewlog(ts);
            -- v4: loans for the circulation reports. pid is Koha's borrower number (staff reports only); names are never stored
            CREATE TABLE IF NOT EXISTS circ(checkout_id INTEGER PRIMARY KEY, item_id INTEGER, biblio_id INTEGER, pid INTEGER,
                out TEXT, back TEXT, renewals INTEGER);
            CREATE INDEX IF NOT EXISTS circ_out ON circ(out);
            CREATE INDEX IF NOT EXISTS circ_back ON circ(back);
            CREATE TABLE IF NOT EXISTS patron_min(pid INTEGER PRIMARY KEY, cat TEXT, lib TEXT, s1 TEXT, s2 TEXT);
            CREATE TABLE IF NOT EXISTS saved_reports(id TEXT PRIMARY KEY, name TEXT, kind TEXT, params TEXT, created REAL);
            CREATE TABLE IF NOT EXISTS lists(id TEXT PRIMARY KEY, edit_key TEXT, name TEXT, note TEXT, items TEXT,
                created REAL, updated REAL);
            CREATE TABLE IF NOT EXISTS saved_searches(id INTEGER PRIMARY KEY AUTOINCREMENT, pid INTEGER, email TEXT, name TEXT,
                params TEXT, base_id INTEGER, base_date TEXT, alerted_id INTEGER, alerted_date TEXT, created REAL);
        """)
        self.books: dict[int, dict] = {}
        self.sem = None  # meaning index (app/semantic.py), attached by the app
        self.reindex()

    # ---------------------------------------------------------------- storage
    def upsert(self, records: list[dict]):
        with self.lock:
            self.db.executemany("INSERT INTO records(id,data) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data, updated=CURRENT_TIMESTAMP",
                                [(r["id"], json.dumps(r, ensure_ascii=False)) for r in records])
            self.db.commit()

    def save_marc(self, rows: list[tuple[int, dict]]):
        """Keep the raw MARC so records can be re-read after a parsing fix without asking Koha again."""
        with self.lock:
            self.db.executemany("INSERT OR REPLACE INTO marc(id,data) VALUES(?,?)",
                                [(bid, json.dumps(m, ensure_ascii=False)) for bid, m in rows])
            self.db.commit()

    def run(self, sql, args=(), commit=False):
        with self.lock:
            cur = self.db.execute(sql, args)
            rows = cur.fetchall()
            if commit:
                self.db.commit()
            return rows

    def save_item_map(self, m: dict):
        with self.lock:
            self.db.executemany("INSERT OR REPLACE INTO item_map VALUES(?,?)", [(i, b) for i, b in m.items() if i and b])
            self.db.commit()

    def item_biblio(self, item_id: int):
        row = self.db.execute("SELECT biblio_id FROM item_map WHERE item_id=?", (item_id,)).fetchone()
        return row[0] if row else None

    def remove_missing(self, keep_ids: set[int]):
        with self.lock:
            ids = [r[0] for r in self.db.execute("SELECT id FROM records")]
            gone = [(i,) for i in ids if i not in keep_ids]
            self.db.executemany("DELETE FROM records WHERE id=?", gone)
            self.db.executemany("DELETE FROM marc WHERE id=?", gone)
            self.db.commit()
            return len(gone)

    def set_enrichment(self, bid: int, cover_desc: str | None = None, explain: list | None = None):
        with self.lock:
            self.db.execute("INSERT INTO enrich(id) VALUES(?) ON CONFLICT(id) DO NOTHING", (bid,))
            if cover_desc is not None:
                self.db.execute("UPDATE enrich SET cover_desc=?, updated=CURRENT_TIMESTAMP WHERE id=?", (cover_desc, bid))
            if explain is not None:
                self.db.execute("UPDATE enrich SET explain=?, updated=CURRENT_TIMESTAMP WHERE id=?", (json.dumps(explain), bid))
            self.db.commit()

    def count(self) -> int:
        return self.db.execute("SELECT COUNT(*) FROM records").fetchone()[0]

    def cache_get(self, key):
        import time
        row = self.db.execute("SELECT value, expires FROM cache WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row and row[1] > time.time() else None

    def cache_set(self, key, value, ttl=86400 * 7):
        import time
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO cache VALUES(?,?,?)", (key, json.dumps(value), time.time() + ttl))
            self.db.commit()

    # ---------------------------------------------------------------- index
    def reindex(self):
        books = {}
        for bid, data in self.db.execute("SELECT id, data FROM records"):
            books[bid] = json.loads(data)
        for bid, cd, ex in self.db.execute("SELECT id, cover_desc, explain FROM enrich"):
            if bid in books:
                if cd:
                    books[bid]["cd"] = cd
                if ex:
                    books[bid]["ai_explain"] = json.loads(ex)
        self.books = books
        inv = {f: defaultdict(set) for f in FIELDS}
        vocab = Counter()
        for b in books.values():
            texts = {"title": f"{b['t']} {b.get('st') or ''}", "auth": b["a"], "subj": " ".join(b.get("subj", [])),
                     "notes": " ".join(b.get("n", {}).values()), "cover": b.get("cd") or ""}
            for f, txt in texts.items():
                ws = words(txt)
                vocab.update({w: FIELDS[f] for w in ws}.keys())
                for w in ws:
                    inv[f][stem(w)].add(b["id"])
        for w in list(STOP) + list(SYN) + [x for v in SYN.values() for x in v] + list(FMT) + list(LANGS) + EXTRA_VOCAB:
            vocab[w] += 5
        self.inv = inv
        self.vocab = vocab
        self.sorted_terms = {f: sorted(inv[f]) for f in FIELDS}
        self._tfidf = None
        self._authors = sorted({b["a"] for b in books.values()})
        for b in books.values():
            if not b.get("au"):
                b["au"] = [b["a"]] if b.get("a") and b["a"] != "Unknown author" else []
        n_by = Counter(a for b in books.values() for a in set(b.get("au") or [b["a"]]))
        self._author_words = {a: (set(words(a)), n) for a, n in n_by.items()}
        from .dewey import Ontology
        self.onto = Ontology(books)

    def matches(self, field: str, w: str) -> set[int]:
        w = stem(w)
        out = set(self.inv[field].get(w, ()))
        if len(w) >= 4:
            terms = self.sorted_terms[field]
            i = bisect.bisect_left(terms, w)
            while i < len(terms) and terms[i].startswith(w):
                out |= self.inv[field][terms[i]]
                i += 1
        return out

    def correct_word(self, w: str) -> str | None:
        if len(w) < 4 or re.search(r"\d", w) or w in self.vocab:
            return None
        mx = 2 if len(w) >= 7 else 1
        best, bd, bf = None, mx + 1, 0
        for v, f in self.vocab.items():
            if abs(len(v) - len(w)) > mx:
                continue
            d = edit_distance(w, v, mx)
            if d < bd or (d == bd and f > bf):
                best, bd, bf = v, d, f
        return best if bd <= mx else None

    def match_author(self, text: str, strict=False) -> str | None:
        qs = [w for w in words(text) if len(w) > 2]
        if not qs:
            return None
        best, bs = None, 0
        for a in self._authors:
            aw = words(a)
            sc = sum(2 if q in aw else (1 if not strict and any(len(x) > 3 and edit_distance(q, x, 2) <= 2 for x in aw) else 0) for q in qs)
            if sc > bs:
                best, bs = a, sc
        return best if bs >= (2 if strict else max(1, len(qs))) else None

    def authors_like(self, text: str) -> list[tuple[str, int]]:
        """Every author whose name holds all the words typed, most titles first: "gandhi" gives each Gandhi."""
        qs = [w for w in words(text) if len(w) > 1 and w not in ("dr", "prof", "mr", "mrs", "ms", "sir")]
        if not qs or not any(len(w) > 2 for w in qs):
            return []
        counts = Counter()
        for a, (aw, n) in self._author_words.items():
            if all(q in aw or (len(q) <= 2 and any(x.startswith(q) for x in aw)) for q in qs):
                counts[a] = n
        return counts.most_common()

    def on_subject(self, ws: list[str]) -> bool:
        """True when some title or subject heading holds all these words."""
        ids = None
        for w in ws:
            hit = self.inv["subj"].get(stem(w), set()) | self.inv["title"].get(stem(w), set())
            ids = hit if ids is None else ids & hit
            if not ids:
                return False
        return bool(ids)

    def find_title(self, text: str) -> dict | None:
        qs = [w for w in words(text) if w not in STOP]
        best, bs = None, 0.0
        for b in self.books.values():
            tw = set(words(b["t"]))
            sc = sum(q in tw for q in qs) / max(len(qs), 1)
            if sc > bs:
                best, bs = b, sc
        return best if bs >= 0.5 else None

    # ---------------------------------------------------------------- similarity (summary + subjects)
    def _vectors(self):
        if self._tfidf is None:
            stopish = set("this that from with their into they them have about through also when where what which more most how who his her its our your these those very each been being over after before while between book books".split())
            tfs = {}
            df = Counter()
            for b in self.books.values():
                tf = Counter(stem(w) for w in words(b.get("n", {}).get("520", "") + " " + " ".join(b.get("subj", [])) * 2)
                             if len(w) > 3 and w not in stopish)
                tfs[b["id"]] = tf
                df.update(tf.keys())
            n = max(len(self.books), 1)
            vecs = {}
            for bid, tf in tfs.items():
                v = {w: c * math.log(n / df[w]) for w, c in tf.items()}
                vecs[bid] = (v, math.sqrt(sum(x * x for x in v.values())) or 1.0)
            self._tfidf = vecs
        return self._tfidf

    def similar(self, bid: int, k=6):
        vecs = self._vectors()
        if bid not in vecs:
            return []
        va, na = vecs[bid]
        out = []
        for other, (vb, nb) in vecs.items():
            if other == bid:
                continue
            shared = [(w, va[w] * vb[w]) for w in va if w in vb]
            s = sum(x for _, x in shared) / (na * nb)
            if s > 0.06:
                out.append((s, other, [w for w, _ in sorted(shared, key=lambda x: -x[1])][:2]))
        return sorted(out, reverse=True)[:k]

    # ---------------------------------------------------------------- reviews
    def add_review(self, bid, pid, who, rating, text):
        with self.lock:
            self.db.execute("INSERT INTO reviews(biblio_id,patron_id,who,rating,text) VALUES(?,?,?,?,?)", (bid, pid, who, rating, text))
            self.db.commit()

    def reviews(self, bid=None, status="approved", pid=None):
        q, args = "SELECT rid,biblio_id,patron_id,who,rating,text,status,created FROM reviews WHERE 1=1", []
        if bid is not None:
            q += " AND biblio_id=?"; args.append(bid)
        if status:
            if pid is not None:
                q += " AND (status=? OR patron_id=?)"; args += [status, pid]
            else:
                q += " AND status=?"; args.append(status)
        rows = self.db.execute(q + " ORDER BY created DESC", args).fetchall()
        return [dict(zip(["rid", "biblio_id", "patron_id", "who", "rating", "text", "status", "created"], r)) for r in rows]

    def moderate(self, rid, action):
        with self.lock:
            if action == "approve":
                self.db.execute("UPDATE reviews SET status='approved' WHERE rid=?", (rid,))
            else:
                self.db.execute("DELETE FROM reviews WHERE rid=?", (rid,))
            self.db.commit()
