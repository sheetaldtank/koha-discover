"""Ratings and review links, looked up by ISBN.

Google Books and Open Library have free public APIs, so their ratings are fetched and cached for a week.
Goodreads closed its API in December 2020 and Amazon's Product Advertising API needs an Associates account,
so those two are offered as links to the book's page on each site.
"""
from __future__ import annotations

import httpx

from .config import settings


async def _google(isbn: str) -> dict | None:
    params = {"q": f"isbn:{isbn}"}
    if settings.google_books_api_key:
        params["key"] = settings.google_books_api_key
    async with httpx.AsyncClient(timeout=8) as h:
        r = await h.get("https://www.googleapis.com/books/v1/volumes", params=params)
    if r.status_code != 200 or not r.json().get("items"):
        return None
    vi = r.json()["items"][0].get("volumeInfo", {})
    return {"r": vi.get("averageRating"), "count": vi.get("ratingsCount"), "url": vi.get("infoLink"),
            "description": vi.get("description"), "cover": (vi.get("imageLinks") or {}).get("thumbnail")}


async def _openlibrary(isbn: str) -> dict | None:
    async with httpx.AsyncClient(timeout=8, follow_redirects=True) as h:
        r = await h.get(f"https://openlibrary.org/isbn/{isbn}.json")
        if r.status_code != 200:
            return None
        works = r.json().get("works") or []
        if not works:
            return None
        key = works[0]["key"]
        rr = await h.get(f"https://openlibrary.org{key}/ratings.json")
    s = rr.json().get("summary", {}) if rr.status_code == 200 else {}
    return {"r": s.get("average"), "count": s.get("count"), "url": f"https://openlibrary.org{key}"}


def amazon_url(isbn: str) -> str:
    tag = f"&tag={settings.amazon_associate_tag}" if settings.amazon_associate_tag else ""
    return f"https://{settings.amazon_domain}/s?k={isbn}{tag}"


async def sources(cat, b: dict) -> list[dict]:
    isbn = b.get("isbn")
    if not isbn:
        return []
    links = {"Goodreads": f"https://www.goodreads.com/book/isbn/{isbn}", "Amazon": amazon_url(isbn),
             "Google Books": f"https://books.google.com/books?vid=ISBN{isbn}", "Open Library": f"https://openlibrary.org/isbn/{isbn}"}
    hows = {"Goodreads": "Reader community", "Amazon": "Customer reviews", "Google Books": "Google Books", "Open Library": "Open Library"}

    if settings.demo:  # sample ratings, clearly marked as such in the UI
        base = b.get("r") or 4.0
        offs = {"Goodreads": -.25, "Amazon": .2, "Google Books": -.05, "Open Library": -.15}
        return [{"name": n, "how": hows[n], "r": round(min(5, max(1, base + offs[n])), 1), "count": None, "url": u, "sample": True}
                for n, u in links.items()]

    key = f"ratings:{isbn}"
    cached = cat.cache_get(key)
    if cached is None:
        cached = {}
        for name, fn in (("Google Books", _google), ("Open Library", _openlibrary)):
            try:
                cached[name] = await fn(isbn)
            except httpx.HTTPError:
                cached[name] = None
        cat.cache_set(key, cached)
    out = []
    for n, u in links.items():
        got = cached.get(n) or {}
        out.append({"name": n, "how": hows[n], "r": got.get("r"), "count": got.get("count"), "url": got.get("url") or u, "sample": False})
    return out
