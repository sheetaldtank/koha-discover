# Setting up Koha for Catalogue Discover

You need a Koha administrator for these steps. They take about 15 minutes.

## 1. Choose how the app signs in to Koha

Either works. Pick one:

- **Username and password** (`KOHA_AUTH=basic`): needs the system preference `RESTBasicAuth` set to **Enable**. Simplest.
- **API key** (`KOHA_AUTH=oauth`): needs `RESTOAuth2ClientCredentials` set to **Enable**. The key can be revoked without changing the account's password.

Both are under **Administration › System preferences**.

**If the API refuses every login with 401** even though the account and key are right, the web server is dropping the `Authorization` header before it reaches Koha. This is common when Koha runs as plain CGI (for example a git install without Plack). Add this line inside the staff interface's `<VirtualHost>` in the Koha Apache site file, then `sudo apachectl configtest && sudo systemctl reload apache2`:

```apache
SetEnvIf Authorization "(.*)" HTTP_AUTHORIZATION=$1
```

If staff sign in through LDAP, prefer the API key: Koha may not accept LDAP passwords through the API.

Check the API answers by opening `https://<staff-url>/api/v1/.html` in a browser. You should see the API documentation page.

## 2. Create a staff account for the app

1. **Patrons › New patron**, category **Staff**. Name it `discover-api`. Give it a long random password nobody needs to know.
2. On the new patron, **More › Set permissions** and tick:
   - `catalogue` (view the staff catalogue)
   - `circulate › circulate_remaining_permissions` (read loans, renew)
   - `borrowers › api_validate_password` (check sign-in passwords; Koha 24.05 and later), `borrowers › list_borrowers`, `borrowers › edit_borrowers` and `borrowers › view_borrower_infos_from_any_libraries` (read patron details and accounts)
   - `reserveforothers › place_holds` and `reserveforothers › modify_holds_priority` (place and cancel holds)
   - `updatecharges › remaining_permissions` (read fines)
3. For **username and password**: give the account a username (for example `discover-api`) and put it and the password in `.env` as `KOHA_API_USER` and `KOHA_API_PASSWORD`.
   For an **API key**: **More › Manage API keys › Generate a new client id/secret pair**, and put them in `.env` as `KOHA_CLIENT_ID` and `KOHA_CLIENT_SECRET`.
4. Check everything with `docker compose run --rm discover python -m app.check`. Add `--card <a test card> --password <its password>` to check patron sign-in too. Each failed step says what to fix.

Permission names differ slightly between Koha versions. If sign-in, renewals or holds fail with "Koha … failed", the message names the endpoint, which tells you which permission is missing.

## 3. Pickup branch

Set `KOHA_DEFAULT_PICKUP_LIBRARY` to the branch code (from **Administration › Libraries**) where holds placed online are collected.

## 4. Optional: "readers who borrowed this also borrowed"

This needs anonymised borrowing history from Koha. Create a saved SQL report (**Reports › Create from SQL**):

```sql
SELECT MD5(CONCAT('change-this-salt', o.borrowernumber, YEAR(o.issuedate))) AS basket,
       i.biblionumber
FROM old_issues o
JOIN items i ON i.itemnumber = o.itemnumber
WHERE o.issuedate > DATE_SUB(NOW(), INTERVAL 3 YEAR)
  AND o.borrowernumber IS NOT NULL
GROUP BY basket, i.biblionumber
```

- Replace `change-this-salt` with a random word. Without it, the basket codes could be traced back to patrons.
- The report groups a patron's loans per year and replaces the patron with a code. Patrons whose history Koha anonymises (privacy setting "Never") are left out automatically.
- Tick **Public** on the report so the app can read it at `/cgi-bin/koha/svc/report?id=<id>`. Public reports can be read by anyone who knows the id, so restrict that address to the app's server in Apache:

```apache
<Location /cgi-bin/koha/svc/report>
    Require ip 127.0.0.1
</Location>
```

Put the report's number in `.env` as `KOHA_COBORROW_REPORT_ID`. Suggestions refresh when the app restarts or after a sync.

## 5. Optional: cover images

The app describes covers from Koha's local cover images (`OPACLocalCoverImages`) first, and from Open Library by ISBN otherwise. Nothing to set up if either is available.

## Items with impossible dates

Koha's API refuses to return an item whose replacement price date is impossible (month or day `00`, often left by an old migration), and refuses the whole page of items it sits in. The app leaves those items out and says how many it skipped, so their titles show no shelf status. To fix them in Koha, a database administrator can run:

```sql
UPDATE items SET replacementpricedate = NULL
WHERE replacementpricedate IS NOT NULL
  AND (MONTH(replacementpricedate) = 0 OR DAY(replacementpricedate) = 0);
```

Take a database backup first. Other date columns (`datelastseen`, `dateaccessioned`) can have the same problem.

## Koha versions

The app is written against the Koha 23.x REST API: `/biblios` (with MARC-in-JSON), `/biblios/{id}/items`, `/items/{id}`, `/auth/password/validation`, `/patrons/{id}`, `/patrons/{id}/account`, `/checkouts`, `/checkouts/{id}/renewal`, `/holds` and `/libraries`. Older versions lack some of these, especially the password check used for sign-in.


## Circulation reports (version 4)

The staff page's circulation and borrower reports read loans through the API (`GET /checkouts`, including returned loans) and patron categories (`GET /patrons`). The app account needs `circulate › circulate_remaining_permissions` and `borrowers › list_borrowers`, which it already has for sign-in and loans.

Make the first copy once, choosing the first date you want reports for:

```
python -m app.sync --circulation --since 2023-01-01
```

After that, every normal `python -m app.sync` tops it up. The app stores, for each loan, the copy, title, borrower number, dates and renewals. It never stores patron names: the *Most active borrowers* report looks up the top 20 names from Koha when it is opened. Patrons whose history Koha anonymises are counted, but not as named borrowers.

Department: the *Borrowing by department* report reads the patron field Sort 1. If your library keeps the department in Sort 2, set `PATRON_DEPT_FIELD=statistics_2` in `.env`.

## Fines by year (version 4)

Koha's API has no library-wide list of fines, so this report reads yearly totals from a saved SQL report.

1. In Koha: **Reports › Create from SQL**. Name it "Catalogue Discover: fines by year" and paste:

```sql
SELECT YEAR(`date`) AS year,
  ROUND(SUM(CASE WHEN debit_type_code IS NOT NULL AND debit_type_code <> 'PAYOUT' THEN amount ELSE 0 END), 2) AS charged,
  ROUND(SUM(CASE WHEN debit_type_code = 'OVERDUE' THEN amount ELSE 0 END), 2) AS overdue_fines,
  ROUND(SUM(CASE WHEN credit_type_code = 'PAYMENT' AND (status IS NULL OR status <> 'VOID') THEN -amount ELSE 0 END), 2) AS collected,
  ROUND(SUM(CASE WHEN credit_type_code IN ('WRITEOFF','FORGIVEN','CANCELLATION') AND (status IS NULL OR status <> 'VOID')
                 THEN -amount ELSE 0 END), 2) AS waived,
  ROUND(SUM(CASE WHEN debit_type_code IS NOT NULL THEN amountoutstanding ELSE 0 END), 2) AS outstanding_now
FROM accountlines
WHERE `date` IS NOT NULL
GROUP BY YEAR(`date`)
ORDER BY year DESC
```

2. Save it, then edit it and tick **Public** (it returns only yearly totals, no patron details). Note the report number.
3. In `.env`: `KOHA_FINES_REPORT_ID=<the number>`, then restart the app.

The person who creates the report needs Koha's `reports` permission. The app's own account needs nothing extra.
