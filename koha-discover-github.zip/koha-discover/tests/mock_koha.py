import json
"""A tiny stand-in for Koha's REST API, used by the tests. Mirrors the response shapes of Koha 23.x."""
from fastapi import FastAPI, Form, HTTPException, Request
from fastapi.responses import JSONResponse

app = FastAPI()
CALLS: list[str] = []  # paths requested, so tests can check the sync reads in bulk
MAX_PAGE = 2
BROKEN: set[int] = set()
BAD_ITEM_DATES: set[int] = set()  # items with replacement_price_date like 2019-00-10  # records Koha fails to turn into MARC (it answers 500 for any page holding one)  # like Koha's page-size cap: forces the client to follow X-Total-Count


@app.middleware("http")
async def record_calls(request, call_next):
    CALLS.append(request.url.path)
    return await call_next(request)
TOKEN = "tok123"


def marc(title, sub, author, year, isbn, subjects, summary, lang="eng", aud=" ", lit="0", series=None):
    c = list(" " * 40)
    c[0:7], c[7:11], c[22], c[33], c[35:38] = list("240101s"), list(str(year)), aud, lit, list(lang)
    f008 = "".join(c)
    fields = [{"008": f008},
              {"020": {"ind1": " ", "ind2": " ", "subfields": [{"a": isbn}]}},
              {"100": {"ind1": "1", "ind2": " ", "subfields": [{"a": author}]}},
              {"245": {"ind1": "1", "ind2": "0", "subfields": [{"a": title + " :"}, {"b": sub + " /"}, {"c": author}]}},
              {"264": {"ind1": " ", "ind2": "1", "subfields": [{"c": str(year)}]}},
              {"300": {"ind1": " ", "ind2": " ", "subfields": [{"a": "320 p."}]}},
              {"520": {"ind1": " ", "ind2": " ", "subfields": [{"a": summary}]}},
              {"082": {"ind1": " ", "ind2": " ", "subfields": [{"a": "158.1 CLE"}]}}]
    fields += [{"650": {"ind1": " ", "ind2": "0", "subfields": [{"a": s}]}} for s in subjects]
    if series:
        fields.append({"490": {"ind1": "1", "ind2": " ", "subfields": [{"a": series[0]}, {"v": f"bk. {series[1]}"}]}})
    return {"leader": "00000nam a22000007a 4500", "fields": fields}


BIBLIOS = {
    101: marc("Atomic habits", "an easy & proven way to build good habits", "Clear, James", 2018, "9780735211292",
              ["Habit", "Self-help"], "A practical guide to building good habits and breaking bad ones."),
    102: marc("Godaan", "a novel", "Premchand", 1936, "9788171828869", ["Peasants", "Rural conditions"],
              "The farmer Hori dreams of owning a cow.", lang="hin", lit="1"),
    103: marc("The hunger games", "", "Collins, Suzanne", 2008, "9780439023481", ["Survival", "Dystopias"],
              "Katniss volunteers for a televised fight to the death.", aud="d", lit="1", series=("The Hunger Games", 1)),
}
ITEMS = {101: [{"item_id": 1, "biblio_id": 101, "callnumber": "158.1 CLE", "holding_library_id": "MAIN", "checked_out_date": None},
               {"item_id": 2, "biblio_id": 101, "callnumber": "158.1 CLE", "holding_library_id": "MAIN", "checked_out_date": "2026-11-01"}],
         102: [{"item_id": 3, "biblio_id": 102, "callnumber": "891.43 PRE", "holding_library_id": "MAIN", "checked_out_date": None}],
         103: [{"item_id": 4, "biblio_id": 103, "callnumber": "YA COL", "holding_library_id": "TEEN", "checked_out_date": "2026-10-30"}]}
CHECKOUTS = [{"checkout_id": 77, "patron_id": 5, "item_id": 2, "due_date": "2026-11-20T23:59:00+05:30", "renewals_count": 0, "checkout_date": "2026-11-01"},
             {"checkout_id": 78, "patron_id": 9, "item_id": 4, "due_date": "2026-11-13T23:59:00+05:30", "renewals_count": 0, "checkout_date": "2026-10-30"}]
Q_CRASHES = False
BAD_LOANS: set = set()
OLD = [{"checkout_id": 60, "patron_id": 5, "item_id": 3, "checkout_date": "2026-09-01", "checkin_date": "2026-09-20"}]
HOLDS = [{"hold_id": 300, "patron_id": 5, "biblio_id": 103, "status": None, "priority": 1, "hold_date": "2026-11-02", "pickup_library_id": "MAIN"}]


def auth(request: Request):
    import base64
    basic = "Basic " + base64.b64encode(b"discover-api:pw").decode()
    if request.headers.get("authorization") not in (f"Bearer {TOKEN}", basic):
        raise HTTPException(401, "unauthorized")


def page(rows, request):
    p, n = int(request.query_params.get("_page", 1)), min(int(request.query_params.get("_per_page", 20)), MAX_PAGE)
    return JSONResponse(rows[(p - 1) * n: p * n], headers={"X-Total-Count": str(len(rows))})


@app.post("/api/v1/oauth/token")
def token(grant_type: str = Form(...), client_id: str = Form(...), client_secret: str = Form(...)):
    if client_id != "cid" or client_secret != "secret":
        raise HTTPException(403, "bad client")
    return {"access_token": TOKEN, "expires_in": 3600, "token_type": "Bearer"}


@app.get("/api/v1/biblios")
def biblios(request: Request):
    auth(request)
    if request.headers.get("accept") == "application/marc-in-json":
        recs = [{**m, "fields": m["fields"] + [{"999": {"ind1": " ", "ind2": " ", "subfields": [{"c": str(i)}, {"d": str(i)}]}}]}
                for i, m in BIBLIOS.items()]
        p, n = int(request.query_params.get("_page", 1)), min(int(request.query_params.get("_per_page", 20)), MAX_PAGE)
        if any(i in BROKEN for i in list(BIBLIOS)[(p - 1) * n: p * n]):
            raise HTTPException(500, "Something went wrong, check Koha logs for details.")
        return page(recs, request)
    return page([{"biblio_id": i} for i in BIBLIOS], request)


@app.get("/api/v1/items")
def all_items(request: Request):
    auth(request)
    rows = [i for r in ITEMS.values() for i in r]
    if BAD_ITEM_DATES and "q" not in request.query_params:  # like Koha: one bad date fails the whole page
        raise HTTPException(500, "Month out of range.")
    rows = [i for i in rows if i["item_id"] not in BAD_ITEM_DATES]
    return page(rows, request)
    return page([i for rows in ITEMS.values() for i in rows], request)


@app.get("/api/v1/biblios/{bid}")
def biblio(bid: int, request: Request):
    auth(request)
    assert request.headers.get("accept") == "application/marc-in-json"
    return BIBLIOS[bid]


@app.get("/api/v1/biblios/{bid}/items")
def items(bid: int, request: Request):
    auth(request)
    return page(ITEMS.get(bid, []), request)


@app.get("/api/v1/items/{iid}")
def item(iid: int, request: Request):
    auth(request)
    return next(i for rows in ITEMS.values() for i in rows if i["item_id"] == iid)


@app.get("/api/v1/libraries")
def libraries(request: Request):
    auth(request)
    return page([{"library_id": "MAIN", "name": "Main Library"}, {"library_id": "TEEN", "name": "Teen Zone"}], request)


@app.post("/api/v1/auth/password/validation")
async def validate(request: Request):
    auth(request)
    b = await request.json()
    if b.get("identifier") == "23529000123" and b.get("password") == "pass":
        return {"patron_id": 5, "cardnumber": "23529000123", "userid": "asha"}
    raise HTTPException(400, "Validation failed")


@app.get("/api/v1/patrons")
def patrons(request: Request):
    auth(request)
    return page([{"patron_id": 5, "firstname": "Asha", "surname": "Rao", "category_id": "ST", "library_id": "MAIN",
                  "statistics_1": "Physics", "statistics_2": ""}], request)


@app.get("/api/v1/patrons/{pid}")
def patron(pid: int, request: Request):
    auth(request)
    return {"patron_id": pid, "firstname": "Asha", "surname": "Rao", "cardnumber": "23529000123", "library_id": "MAIN", "expiry_date": "2027-03-31"}


@app.get("/api/v1/patrons/{pid}/account")
def account(pid: int, request: Request):
    auth(request)
    return {"balance": 20, "outstanding_debits": {"total": 20, "lines": [{"amount": 20, "amount_outstanding": 20, "description": "Overdue fine", "date": "2026-10-15T10:00:00", "debit_type": "OVERDUE"}]}}


@app.get("/api/v1/checkouts")
def checkouts(request: Request, patron_id: int | None = None, checked_in: int = 0):
    auth(request)
    if request.query_params.get("_order_by") not in (None, "-checkin_date", "+checkout_id", "-checkout_id"):
        raise HTTPException(400, "bad order")
    rows = [c for c in (OLD if checked_in else CHECKOUTS) if patron_id is None or c["patron_id"] == patron_id]
    if request.query_params.get("_order_by") == "-checkout_id":
        rows = sorted(rows, key=lambda c: -c["checkout_id"])
    if checked_in and patron_id is None:
        if request.query_params.get("q") and Q_CRASHES:
            raise HTTPException(500, "Something went wrong, check Koha logs for details.")
        p, n = int(request.query_params.get("_page", 1)), min(int(request.query_params.get("_per_page", 20)), MAX_PAGE)
        if any(c["checkout_id"] in BAD_LOANS for c in rows[(p - 1) * n: p * n]):
            raise HTTPException(500, "Something went wrong, check Koha logs for details.")
    if request.query_params.get("q"):
        for field, cond in json.loads(request.query_params["q"]).items():
            rows = [c for c in rows if (c.get(field) or "") >= cond[">="]]
    if request.headers.get("x-koha-embed") == "item":
        if checked_in:  # pretend old checkouts can't embed, to exercise the fallback
            raise HTTPException(400, "Embedding objects is not allowed on this endpoint.")
        rows = [c | {"item": next(i for r in ITEMS.values() for i in r if i["item_id"] == c["item_id"])} for c in rows]
    return page(rows, request)


@app.post("/api/v1/checkouts/{cid}/renewal")
def renewal(cid: int, request: Request):
    auth(request)
    c = next(c for c in CHECKOUTS if c["checkout_id"] == cid)
    c["due_date"] = "2026-12-04T23:59:00+05:30"
    c["renewals_count"] += 1
    return {"due_date": c["due_date"]}


@app.get("/api/v1/holds")
def holds(request: Request, patron_id: int):
    auth(request)
    return page([h for h in HOLDS if h["patron_id"] == patron_id], request)


@app.post("/api/v1/holds", status_code=201)
async def add_hold(request: Request):
    auth(request)
    b = await request.json()
    h = {"hold_id": 300 + len(HOLDS) + 1, "status": None, "priority": 1, "hold_date": "2026-11-06", **b}
    HOLDS.append(h)
    return h


@app.delete("/api/v1/holds/{hid}", status_code=204)
def del_hold(hid: int, request: Request):
    auth(request)
    HOLDS[:] = [h for h in HOLDS if h["hold_id"] != hid]
