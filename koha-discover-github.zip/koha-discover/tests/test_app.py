"""Run with:  pytest -q   (from the koha-discover folder)

Demo-mode tests use the built-in sample catalogue. Koha-mode tests start the mock Koha server in tests/mock_koha.py.
"""
import importlib
import os
import socket
import sys
import threading
import time
from pathlib import Path

import pytest
import uvicorn
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def fresh_app(tmp_path, **env):
    os.environ.update({"DATA_DIR": str(tmp_path), "ADMIN_TOKEN": "staff", "ANTHROPIC_API_KEY": "", **env})
    for m in [m for m in sys.modules if m == "app" or m.startswith("app.")]:
        del sys.modules[m]
    return importlib.import_module("app.main").app


# ---------------------------------------------------------------- demo mode
@pytest.fixture
def demo(tmp_path):
    with TestClient(fresh_app(tmp_path, DISCOVER_MODE="demo")) as c:
        yield c


def titles(r):
    return [x["t"] for x in r.json()["results"]]


def test_spelling_is_fixed_and_filters_understood(demo):
    r = demo.get("/api/search", params={"q": "books on artifical inteligence published after 2015"}).json()
    assert r["note"]["kind"] == "auto" and "artificial intelligence" in r["note"]["corr"]
    assert r["understood"]["f"]["ymin"] == 2016
    assert "Life 3.0" in [x["t"] for x in r["results"]]


def test_cover_description_search(demo):
    assert titles(demo.get("/api/search", params={"q": "black cover with a gold bird"}))[:2] == ["Catching Fire", "The Hunger Games"]
    assert titles(demo.get("/api/search", params={"q": "book with a red train on the cover"}))[0].startswith("Harry Potter")


def test_author_series_language_isbn(demo):
    assert set(titles(demo.get("/api/search", params={"q": "books by harrari"}))) == {"Sapiens", "21 Lessons for the 21st Century"}
    assert titles(demo.get("/api/search", params={"q": "hindi books"})) == ["Godaan (गोदान)"]
    assert titles(demo.get("/api/search", params={"q": "978-0-375-86902-0"})) == ["Wonder"]


def test_record_has_recommendations_and_reviews(demo):
    r = demo.get("/api/records/8").json()
    kinds = [x["k"] for x in r["recs"]]
    assert kinds[0] == "series" and "also" in kinds
    assert {s["name"] for s in r["sources"]} == {"Goodreads", "Amazon", "Google Books", "Open Library"}
    assert r["member_reviews"]


def test_patron_flow_and_review_moderation(demo):
    assert demo.get("/api/me").status_code == 401
    assert demo.post("/api/login", json={"card": "LIB1024", "pin": "nope"}).status_code == 401
    assert demo.post("/api/login", json={"card": "LIB1024", "pin": "1234"}).status_code == 200
    me = demo.get("/api/me").json()
    assert len(me["loans"]) == 3 and me["loans"][0]["book"]["t"] == "Atomic Habits"
    assert demo.post("/api/me/renew/502").status_code == 200
    assert demo.post("/api/me/renew/999").status_code == 403  # not this patron's loan
    assert demo.post("/api/me/holds", json={"biblio_id": 27}).status_code == 200
    assert demo.post("/api/records/27/reviews", json={"rating": 5, "text": "Great"}).status_code == 200
    assert demo.get("/api/admin/reviews").status_code == 401
    pending = demo.get("/api/admin/reviews", headers={"X-Admin-Token": "staff"}).json()
    assert pending and pending[0]["text"] == "Great"
    demo.post(f"/api/admin/reviews/{pending[0]['rid']}/approve", headers={"X-Admin-Token": "staff"})
    demo.post("/api/logout")
    assert any(m["text"] == "Great" for m in demo.get("/api/records/27").json()["member_reviews"])


# ---------------------------------------------------------------- koha mode, against the mock server
def _free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


@pytest.fixture(scope="module")
def mock_koha():
    sys.path.insert(0, str(Path(__file__).parent))
    from mock_koha import app as koha_app
    port = _free_port()
    server = uvicorn.Server(uvicorn.Config(koha_app, port=port, log_level="warning"))
    threading.Thread(target=server.run, daemon=True).start()
    while not server.started:
        time.sleep(0.05)
    yield f"http://127.0.0.1:{port}"
    server.should_exit = True


@pytest.mark.parametrize("auth", ["oauth", "basic"])
def test_against_koha(tmp_path, mock_koha, auth):
    env = dict(DISCOVER_MODE="koha", KOHA_URL=mock_koha, KOHA_CLIENT_ID="cid", KOHA_CLIENT_SECRET="secret", KOHA_DEFAULT_PICKUP_LIBRARY="MAIN",
               KOHA_AUTH=auth, KOHA_API_USER="discover-api", KOHA_API_PASSWORD="pw")
    app = fresh_app(tmp_path, **env)
    import asyncio
    from app.catalog import Catalog
    from app.sync import sync_koha
    import mock_koha
    mock_koha.CALLS.clear()
    asyncio.run(sync_koha(Catalog()))
    assert not [p for p in mock_koha.CALLS if p.startswith("/api/v1/biblios/")], "sync should read records in bulk"
    with TestClient(app) as c:
        r = c.get("/api/search", params={"q": "atomik habbits"}).json()
        assert r["results"][0]["t"] == "Atomic habits" and r["results"][0]["av"] == 1 and r["results"][0]["tot"] == 2
        g = c.get("/api/search", params={"q": "hindi novels"}).json()
        assert [x["t"] for x in g["results"]] == ["Godaan"]
        hg = c.get("/api/records/103").json()
        assert hg["ser"] == ["The Hunger Games", 1] and hg["aud"] == "Young adult" and hg["av"] == 0
        assert c.post("/api/login", json={"card": "23529000123", "pin": "pass"}).json()["name"] == "Asha Rao"
        me = c.get("/api/me").json()
        assert me["loans"][0]["book"]["t"] == "Atomic habits" and me["fines"][0]["amt"] == 20
        assert c.get("/api/me/history").json()[0]["book"]["t"] == "Godaan" and me["holds"][0]["at"] == "Main Library"
        assert c.get("/api/me/who").json()["name"] == "Asha Rao"
        assert c.post("/api/me/renew/77").json()["due"] == "2026-12-04"
        assert c.post("/api/me/renew/78").status_code == 403  # someone else's loan
        before = len(c.get("/api/me").json()["holds"])
        assert c.post("/api/me/holds", json={"biblio_id": 102}).status_code == 200
        holds = c.get("/api/me").json()["holds"]
        assert len(holds) == before + 1
        assert c.delete(f"/api/me/holds/{holds[-1]['hold_id']}").status_code == 200


def test_connection_check(tmp_path, mock_koha, capsys):
    fresh_app(tmp_path, DISCOVER_MODE="koha", KOHA_URL=mock_koha, KOHA_AUTH="basic", KOHA_API_USER="discover-api", KOHA_API_PASSWORD="pw",
              KOHA_DEFAULT_PICKUP_LIBRARY="MAIN")
    import asyncio
    from app.check import main
    assert asyncio.run(main("23529000123", "pass")) == 0
    assert "All checks passed" in capsys.readouterr().out
    fresh_app(tmp_path, DISCOVER_MODE="koha", KOHA_URL=mock_koha, KOHA_AUTH="basic", KOHA_API_USER="discover-api", KOHA_API_PASSWORD="wrong")
    from app.check import main as main2
    assert asyncio.run(main2(None, None)) == 1


def test_sync_skips_a_broken_record_and_resumes(tmp_path, mock_koha):
    import asyncio
    import mock_koha as mk
    fresh_app(tmp_path, DISCOVER_MODE="koha", KOHA_URL=mock_koha, KOHA_AUTH="basic", KOHA_API_USER="discover-api", KOHA_API_PASSWORD="pw")
    from app.catalog import Catalog
    from app.sync import sync_koha
    mk.BROKEN.add(102)
    try:
        cat = Catalog()
        asyncio.run(sync_koha(cat))
        assert sorted(cat.books) == [101, 103]
        assert cat.cache_get("sync_progress") is None
        mk.BROKEN.clear()
        asyncio.run(sync_koha(cat, from_page=1))  # a later run picks the record up
        assert sorted(cat.books) == [101, 102, 103]
    finally:
        mk.BROKEN.clear()


def test_availability_skips_items_with_bad_dates(tmp_path, mock_koha):
    import asyncio
    import mock_koha as mk
    fresh_app(tmp_path, DISCOVER_MODE="koha", KOHA_URL=mock_koha, KOHA_AUTH="basic", KOHA_API_USER="discover-api", KOHA_API_PASSWORD="pw")
    from app.catalog import Catalog
    from app.sync import sync_koha, sync_availability
    mk.BAD_ITEM_DATES.add(2)
    try:
        cat = Catalog()
        asyncio.run(sync_koha(cat))
        assert cat.books[101]["tot"] == 1 and cat.books[102]["av"] == 1
        mk.BAD_ITEM_DATES.clear()
        asyncio.run(sync_availability(cat))
        assert cat.books[101]["tot"] == 2
    finally:
        mk.BAD_ITEM_DATES.clear()


def test_marc_cleanup_and_reparse(tmp_path, mock_koha):
    import asyncio
    fresh_app(tmp_path, DISCOVER_MODE="koha", KOHA_URL=mock_koha, KOHA_AUTH="basic", KOHA_API_USER="discover-api", KOHA_API_PASSWORD="pw")
    from app.marc import marc_to_record
    junk = {"leader": "00000nam a2200000 a 4500", "fields": [{"008": "240101s9788    ii            000 0 ||| d"},
            {"245": {"ind1": "0", "ind2": "0", "subfields": [{"a": "Biophysics"}]}},
            {"260": {"ind1": " ", "ind2": " ", "subfields": [{"c": "c2099, 2003"}]}}]}
    r = marc_to_record(1, junk)
    assert r["y"] == 2003 and r["l"] == ""
    from app.catalog import Catalog
    from app.sync import sync_koha, reparse
    cat = Catalog()
    asyncio.run(sync_koha(cat))
    cat.db.execute("UPDATE records SET data=json_set(data, '$.t', 'stale')"); cat.db.commit()
    reparse(cat)
    assert cat.books[101]["t"] == "Atomic habits" and cat.books[101]["tot"] == 2


def test_links_dewey_home_and_picks(demo):
    # clickable author / subject / Dewey links are plain filters on the search
    r = demo.get("/api/search", params={"who": "Yuval Noah Harari"}).json()
    assert r["results"] and all("Harari" in x["a"] for x in r["results"])
    rec = demo.get("/api/records/23").json()   # The Gene, 576.5
    assert [p["num"] for p in rec["ddc_path"]] == ["500", "570", "576"]
    assert rec["ddc_path"][1]["name"] == "Life sciences and biology"
    sj = rec["subj"][0]
    assert any(x["id"] == 23 for x in demo.get("/api/search", params={"subj": sj}).json()["results"])
    sci = demo.get("/api/search", params={"ddc": "5"}).json()
    assert sci["count"] >= 3 and all(x["dd"].startswith("5") for x in sci["results"])
    # semantic search: related Dewey sections are offered and add titles the words missed
    r = demo.get("/api/search", params={"q": "genetics"}).json()
    assert r["related"] and r["related"][0]["code"].startswith("57")
    # home page: new arrivals and the subject tree
    h = demo.get("/api/home").json()
    assert len(h["new"]) >= 10 and {c["num"] for c in h["classes"]} >= {"500", "800", "900"}
    b = demo.get("/api/browse", params={"ddc": "5"}).json()
    assert b["path"][0]["name"] == "Science" and any(c["num"] == "570" for c in b["children"])
    # picked for you needs a signed-in reader and leaves out what they already borrowed
    assert demo.get("/api/me/picks").status_code == 401
    demo.post("/api/login", json={"card": "LIB1024", "pin": "1234"})
    picks = demo.get("/api/me/picks").json()
    assert picks and all(p["note"].startswith("Because you borrowed") for p in picks)
    assert not {23, 1, 4, 16, 6, 12, 9} & {p["id"] for p in picks}


# ---------------------------------------------------------------- v3: reports, export, lists, saved searches
def test_staff_reports_are_anonymous_and_export(demo):
    demo.get("/api/search", params={"q": "chemistry"})
    demo.get("/api/search", params={"q": "chemistry"})
    demo.get("/api/search", params={"q": "zzqx unknownword"})
    demo.get("/api/records/23")
    assert demo.get("/api/admin/reports").status_code == 401
    H = {"X-Admin-Token": "staff"}
    info = demo.get("/api/admin/reports", headers=H).json()
    assert {r["kind"] for r in info["reports"]} >= {"top_searches", "zero_results", "demand", "display", "new_by_subject", "age"}
    top = demo.get("/api/admin/reports/top_searches", params={"days": 7}, headers=H).json()
    assert top["rows"][0][:2] == ["chemistry", 2]
    zero = demo.get("/api/admin/reports/zero_results", headers=H).json()
    assert any("zzqx" in r[0] for r in zero["rows"])
    for kind in ("demand", "display", "new_by_subject", "age"):
        r = demo.get(f"/api/admin/reports/{kind}", params={"days": 365}, headers=H).json()
        assert r["columns"] and isinstance(r["rows"], list)
    x = demo.get("/api/admin/reports/demand", params={"fmt": "xlsx"}, headers=H)
    assert x.content[:2] == b"PK" and "attachment" in x.headers["content-disposition"]
    c = demo.get("/api/admin/reports/demand", params={"fmt": "csv"}, headers=H)
    assert c.content.decode("utf-8-sig").startswith("Subject area,")
    s = demo.post("/api/admin/saved-reports", json={"kind": "demand", "days": 90, "name": "Busy shelves"}, headers=H).json()
    assert demo.get("/api/admin/reports", headers=H).json()["saved"][0]["id"] == s["id"]
    demo.delete(f"/api/admin/saved-reports/{s['id']}", headers=H)
    assert demo.get("/api/admin/reports", headers=H).json()["saved"] == []


def test_reader_export_and_citation(demo):
    r = demo.get("/api/records/23").json()
    assert r["cite"] and "(" in r["cite"]
    ris = demo.get("/api/export", params={"fmt": "ris", "ids": "23"}).text
    assert ris.startswith("TY  - ") and "ER  - " in ris
    bib = demo.get("/api/export", params={"fmt": "bib", "q": "harry potter"}).text
    assert bib.count("@book{") >= 2
    x = demo.get("/api/export", params={"fmt": "xlsx", "q": "chemistry"})
    assert x.content[:2] == b"PK"
    assert demo.get("/api/export", params={"fmt": "exe", "q": "x"}).status_code == 400


def test_reading_list_share_and_edit_key(demo):
    L = demo.post("/api/lists", json={"name": "Semester 3", "biblio_id": 23}).json()
    assert L["key"] and [b["id"] for b in L["items"]] == [23]
    demo.post(f"/api/lists/{L['id']}", json={"key": L["key"], "add": 1})
    shared = demo.get(f"/api/lists/{L['id']}").json()
    assert "key" not in shared and len(shared["items"]) == 2
    assert demo.post(f"/api/lists/{L['id']}", json={"key": "wrong", "add": 2}).status_code == 403
    assert demo.get(f"/api/lists/{L['id']}/export", params={"fmt": "csv"}).text.count("\n") == 3
    demo.post(f"/api/lists/{L['id']}", json={"key": L["key"], "delete": True})
    assert demo.get(f"/api/lists/{L['id']}").status_code == 404


def test_saved_search_counts_new_titles_and_emails(demo, monkeypatch):
    assert demo.get("/api/me/saved").status_code == 401
    demo.post("/api/login", json={"card": "LIB1024", "pin": "1234"})
    r = demo.post("/api/me/saved", json={"name": "Space", "params": {"q": "space"}, "alert": True}).json()
    assert r["ok"] and r["email"]
    saved = demo.get("/api/me/saved").json()
    assert saved[0]["new"] == 0 and saved[0]["total"] > 0
    from app import alerts, main
    cat = main.cat()
    book = dict(next(iter(cat.books.values())), id=999999, t="New space handbook", subj=["Space"])
    cat.upsert([book])
    cat.reindex()
    assert demo.get("/api/me/saved").json()[0]["new"] == 1
    sent = []

    class FakeSMTP:
        def __init__(self, *a, **k): pass
        def __enter__(self): return self
        def __exit__(self, *a): pass
        def starttls(self): pass
        def login(self, *a): pass
        def send_message(self, m): sent.append(m)
    monkeypatch.setattr(alerts.smtplib, "SMTP", FakeSMTP)
    monkeypatch.setattr(alerts.settings, "smtp_host", "mail.example.org")
    monkeypatch.setattr(alerts.settings, "smtp_from", "library@example.org")
    assert alerts.send_alerts(cat) == 1 and "New space handbook" in sent[0].get_content()
    assert alerts.send_alerts(cat) == 0  # not emailed twice
    demo.post(f"/api/me/saved/{saved[0]['id']}/seen")
    assert demo.get("/api/me/saved").json()[0]["new"] == 0


def test_official_ddc_names_from_summaries(tmp_path):
    from_pdf_text = "500 Natural sciences & mathematics\n520 Astronomy & allied sciences\n523 Specific celestial bodies & phenomena\n"
    sys.path.insert(0, str(ROOT))
    (tmp_path / "ddc-names.csv").write_text("", encoding="utf-8")
    with TestClient(fresh_app(tmp_path, DISCOVER_MODE="demo")) as c:
        assert c.get("/api/config").json()["ddc_notice"] == ""  # empty file: built-in names, no notice
    from app.ddcnames import parse
    names = parse(from_pdf_text)
    (tmp_path / "ddc-names.csv").write_text("".join(f"{k},{v}\n" for k, v in names.items()), encoding="utf-8")
    with TestClient(fresh_app(tmp_path, DISCOVER_MODE="demo")) as c:
        assert "OCLC" in c.get("/api/config").json()["ddc_notice"]
        home = c.get("/api/home").json()
        assert any(x["name"] == "Natural sciences & mathematics" for x in home["classes"])
        path = c.get("/api/records/4").json()["ddc_path"]
        assert [p["name"] for p in path] == ["Natural sciences & mathematics", "Astronomy & allied sciences",
                                             "Specific celestial bodies & phenomena"]


def test_account_page_survives_missing_fines_permission(demo):
    from app import main
    from app.koha import KohaError

    async def no(pid):
        raise KohaError("Koha refused access to /patrons/1/account (403).", 502)
    demo.post("/api/login", json={"card": "LIB1024", "pin": "1234"})
    main.state["koha"].fines = no
    me = demo.get("/api/me").json()
    assert me["unavailable"] == ["fines"] and len(me["loans"]) == 3


def test_circulation_reports_between_two_dates(demo):
    H = {"X-Admin-Token": "staff"}
    info = demo.get("/api/admin/reports", headers=H).json()
    assert info["loans"] > 0 and info["loans_copied"]
    groups = {r["group"] for r in info["reports"]}
    assert groups == {"Searches and displays", "Circulation", "Borrowers and fines"}
    from datetime import date, timedelta
    start, end = (date.today() - timedelta(days=365)).isoformat(), date.today().isoformat()
    P = {"start": start, "end": end}
    s = demo.get("/api/admin/reports/circ_summary", params=P, headers=H).json()
    assert s["rows"][0][0] == "All" and s["rows"][0][1] == sum(r[1] for r in s["rows"][1:]) and "titles" in s["about"]
    top = demo.get("/api/admin/reports/top_titles", params=P, headers=H).json()["rows"]
    assert 0 < len(top) <= 20 and top[0][0] == 1 and top[0][4] >= top[-1][4]
    least = demo.get("/api/admin/reports/least_titles", params=P, headers=H).json()
    assert len(least["rows"]) <= 20 and "were not borrowed" in least["about"]
    uf = demo.get("/api/admin/reports/use_factor", params=P, headers=H).json()
    assert {r[9] for r in uf["rows"]} <= {"Well used", "Average", "Under-used"}
    assert demo.get("/api/admin/reports/use_by_class", params=P, headers=H).json()["rows"]
    b = demo.get("/api/admin/reports/borrowers", params=P, headers=H).json()
    assert b["rows"][0][1] and b["rows"][0][2].startswith("LIB") and b["rows"][0][3] in {"Student", "Faculty", "Staff"}
    cats = demo.get("/api/admin/reports/by_category", params=P, headers=H).json()["rows"]
    assert {r[0] for r in cats} >= {"Student", "Faculty"}
    assert demo.get("/api/admin/reports/by_department", params=P, headers=H).json()["rows"]
    f = demo.get("/api/admin/reports/fines", params={"start": f"{date.today().year - 1}-01-01", "end": end}, headers=H).json()
    assert [r[0] for r in f["rows"]] == [date.today().year - 1, date.today().year, "Total"]
    x = demo.get("/api/admin/reports/borrowers", params={**P, "fmt": "xlsx"}, headers=H)
    assert x.content[:2] == b"PK"
    assert demo.get("/api/admin/reports/top_titles", params={"start": "31-12-2025"}, headers=H).status_code == 400
    sv = demo.post("/api/admin/saved-reports", json={"kind": "top_titles", **P, "name": "Last year"}, headers=H).json()
    saved = demo.get("/api/admin/reports", headers=H).json()["saved"]
    assert saved[0]["id"] == sv["id"] and saved[0]["params"]["start"] == start
    assert demo.get("/api/admin/reports/borrowers", params=P).status_code == 401


def test_circulation_copy_from_koha(tmp_path, mock_koha):
    """The first copy reads loans out and returned; names are not stored."""
    import asyncio
    app_ = fresh_app(tmp_path, DISCOVER_MODE="koha", KOHA_URL=mock_koha, KOHA_AUTH="basic",
                     KOHA_API_USER="discover-api", KOHA_API_PASSWORD="pw")
    from app.catalog import Catalog
    from app.sync import sync_circulation
    cat = Catalog()
    asyncio.run(sync_circulation(cat, "2000-01-01"))
    rows = cat.run("SELECT checkout_id, pid, out, back FROM circ")
    assert rows and any(r[3] for r in rows) and any(not r[3] for r in rows)
    cols = [c[1] for c in cat.run("PRAGMA table_info(patron_min)")]
    assert "name" not in cols and "surname" not in cols


def test_circulation_skips_damaged_loans_and_broken_filter(tmp_path, mock_koha, monkeypatch):
    import asyncio
    import mock_koha as mk
    old = [{"checkout_id": 100 + i, "patron_id": 5, "item_id": 3, "checkout_date": f"2025-0{1 + i % 9}-01",
            "checkin_date": "2025-12-01"} for i in range(25)] + [{"checkout_id": 1, "patron_id": 5, "item_id": 3,
                                                                   "checkout_date": "2019-01-01", "checkin_date": "2019-02-01"}]
    old.sort(key=lambda c: c["checkout_id"])
    monkeypatch.setattr(mk, "OLD", old)
    monkeypatch.setattr(mk, "MAX_PAGE", 1000)
    monkeypatch.setattr(mk, "BAD_LOANS", {107})
    monkeypatch.setattr(mk, "Q_CRASHES", True)
    fresh_app(tmp_path, DISCOVER_MODE="koha", KOHA_URL=mock_koha, KOHA_AUTH="basic",
              KOHA_API_USER="discover-api", KOHA_API_PASSWORD="pw")
    from app.catalog import Catalog
    from app.sync import sync_circulation
    cat = Catalog()
    asyncio.run(sync_circulation(cat, "2023-01-01"))
    ids = {r[0] for r in cat.run("SELECT checkout_id FROM circ")}
    assert 107 not in ids and 1 not in ids  # damaged one skipped, 2019 loan left out by date
    assert len(ids & {100 + i for i in range(25)}) == 24



def test_circulation_retries_disconnects_and_resumes(tmp_path, mock_koha, monkeypatch):
    import asyncio
    import httpx
    import mock_koha as mk
    old = [{"checkout_id": 100 + i, "patron_id": 5, "item_id": 3, "checkout_date": "2025-03-01",
            "checkin_date": "2025-04-01"} for i in range(30)]
    monkeypatch.setattr(mk, "OLD", old)
    monkeypatch.setattr(mk, "MAX_PAGE", 1000)
    fresh_app(tmp_path, DISCOVER_MODE="koha", KOHA_URL=mock_koha, KOHA_AUTH="basic",
              KOHA_API_USER="discover-api", KOHA_API_PASSWORD="pw")
    from app.catalog import Catalog
    from app.koha import KohaClient, KohaError
    from app.sync import sync_circulation
    KohaClient.RETRY_WAITS = (0, 0)
    KohaClient.LOAN_PAGE = 10
    cat = Catalog()

    def flaky(fail_on_page, times):
        k = KohaClient()
        real, left = k.http.request, [times]

        async def request(method, url, **kw):
            p = kw.get("params") or {}
            if p.get("checked_in") == 1 and p.get("_page") == fail_on_page and p.get("_per_page") == 10 and left[0]:
                left[0] -= 1
                raise httpx.RemoteProtocolError("Server disconnected without sending a response.")
            return await real(method, url, **kw)
        k.http.request = request
        return k

    asyncio.run(sync_circulation(cat, "2024-01-01", k=flaky(2, 1)))  # one drop: retried, nothing lost
    assert cat.run("SELECT COUNT(*) FROM circ WHERE back != ''")[0][0] == 30
    cat.run("DELETE FROM circ", commit=True)
    with pytest.raises(KohaError, match="carries on"):  # Koha stays down on page 3: stops, keeps pages 1-2
        asyncio.run(sync_circulation(cat, "2024-01-01", k=flaky(3, 99)))
    assert cat.run("SELECT COUNT(*) FROM circ WHERE back != ''")[0][0] == 20
    assert cat.cache_get("circ_progress")["page"] == 2
    calls = []
    k = KohaClient()
    real = k.http.request

    async def spy(method, url, **kw):
        calls.append(dict(kw.get("params") or {}))
        return await real(method, url, **kw)
    k.http.request = spy
    asyncio.run(sync_circulation(cat, "2024-01-01", k=k))  # same command again: carries on at page 3
    assert cat.run("SELECT COUNT(*) FROM circ WHERE back != ''")[0][0] == 30
    old_pages = [c["_page"] for c in calls if c.get("checked_in") == 1 and c.get("_per_page") == 10]
    assert old_pages == [3] and cat.cache_get("circ_progress") is None
    KohaClient.LOAN_PAGE = 1000


def test_circulation_reads_newest_first_and_stops_at_cutoff(tmp_path, mock_koha, monkeypatch):
    import asyncio
    import mock_koha as mk
    old = [{"checkout_id": i, "patron_id": 5, "item_id": 3, "checkout_date": f"{2010 + i // 10}-06-01",
            "checkin_date": f"{2010 + i // 10}-07-01"} for i in range(160)]  # 2010 ... 2025, 10 a year
    monkeypatch.setattr(mk, "OLD", old)
    monkeypatch.setattr(mk, "MAX_PAGE", 1000)
    fresh_app(tmp_path, DISCOVER_MODE="koha", KOHA_URL=mock_koha, KOHA_AUTH="basic",
              KOHA_API_USER="discover-api", KOHA_API_PASSWORD="pw")
    from app.catalog import Catalog
    from app.koha import KohaClient
    from app.sync import sync_circulation
    KohaClient.LOAN_PAGE = 10
    k, pages = KohaClient(), []
    real = k.http.request

    async def spy(method, url, **kw):
        p = kw.get("params") or {}
        if p.get("checked_in") == 1:
            pages.append(p["_page"])
        return await real(method, url, **kw)
    k.http.request = spy
    cat = Catalog()
    asyncio.run(sync_circulation(cat, "2024-01-01", k=k))
    KohaClient.LOAN_PAGE = 1000
    assert cat.run("SELECT COUNT(*) FROM circ WHERE back != ''")[0][0] == 20  # 2024 and 2025 only
    assert pages == [1, 2, 3]  # 16 pages of history, but it stops after the first page older than 2024


# ---------------------------------------------------------------- v5: intelligent search, themes, course readings, chat
def test_books_by_versus_books_on(demo):
    by = demo.get("/api/search", params={"q": "books by gandhi"}).json()
    assert set(titles(demo.get("/api/search", params={"q": "books by gandhi"}))) == {"Hind Swaraj", "An Autobiography", "Mohandas"}
    assert {c["name"] for c in by["choices"]} == {"M. K. Gandhi", "Rajmohan Gandhi"}
    on = titles(demo.get("/api/search", params={"q": "books on gandhi"}))
    assert "Hind Swaraj" not in on  # written by Gandhi, not about him
    assert set(on[:3]) == {"Gandhi Before India", "An Autobiography", "Mohandas"}  # subject heading matches first
    assert on.index("India After Gandhi") > 2  # only the title mentions him
    assert titles(demo.get("/api/search", params={"q": "biography of gandhi"}))[:3] == on[:3]
    bare = demo.get("/api/search", params={"q": "gandhi"}).json()
    assert [i["q"] for i in bare["intents"]] == ["books by gandhi", "books about gandhi"]
    one = demo.get("/api/search", params={"q": "books by ramachandra guha"}).json()
    assert one["understood"]["f"]["author"] == "Ramachandra Guha" and not one["choices"]


def test_meaning_search_and_themes(demo):
    h = demo.get("/healthz").json()["meaning"]
    assert h["ready"] and h["backend"] == "lsa" and h["themes"] >= 2
    r = demo.get("/api/search", params={"q": "protest movement"}).json()  # no title or subject has these words
    assert r["semantic"] and r["results"]
    assert all(x["why"] == [["close in meaning", "meaning"]] for x in r["results"])
    assert "Gandhi Before India" in [x["t"] for x in r["results"]]
    themes = demo.get("/api/home").json()["themes"]
    gt = next(t for t in themes if "Gandhi" in t["name"])
    got = titles(demo.get("/api/search", params={"theme": gt["id"]}))
    assert "Gandhi Before India" in got and "Cosmos" not in got
    assert demo.get("/api/records/34").json()["theme"]["id"] == gt["id"]
    rep = demo.get("/api/admin/reports/themes", params={"days": 30}, headers={"X-Admin-Token": "staff"}).json()
    assert rep["columns"][0] == "Theme" and any(row[1] for row in rep["rows"])


def test_course_readings_upload_search_and_export(demo):
    H = {"X-Admin-Token": "staff"}
    assert demo.get("/api/config").json()["courses"]  # demo loads a sample semester
    csv_text = ("﻿Sr. No.,Name of Faculty,Course Code,Course Name,Title,Author,Publisher,Year,Print ISBN,Call No.,Acc. No.,"
                "\"Textbook/\nReference Books\",Lending Policy,Status,Remarks,e-book Link,CR Ordered Numbers,Biblio no.\n"
                "1,Sushobhan Sen,CE 404,Transportation Engineering,Gandhi Before India,Guha,,2013,,954 GUH,000001,Textbook,CR,Available,,http://x,,34\n"
                "2,Sushobhan Sen,CE 404,Transportation Engineering,Gandhi Before India,Guha,,2013,,954 GUH,000002,Textbook,SL,Available,,,,34\n"
                "3,Sushobhan Sen,CE404,Transportation Engineering,Missing book,Someone,,2010,,629 X,000003,Reference,SL,Available,,,,99999\n"
                "4,Asha Rao,,,Mohandas,Gandhi,,2006,,954 GAN,000004,Textbook,SL,Available,,,,35\n")
    assert demo.post("/api/admin/courses", files={"file": ("cr.csv", csv_text.encode())}, data={"label": "Semester I"}).status_code == 401
    up = demo.post("/api/admin/courses", files={"file": ("cr.csv", csv_text.encode())}, data={"label": "Semester I"}, headers=H).json()
    assert up["rows"] == 4 and up["no_course_code"] == 1 and [x["biblio_id"] for x in up["not_in_catalogue"]] == [99999]
    for q in ("CE 404", "readings for ce404", "transportation engineering course"):
        r = demo.get("/api/search", params={"q": q}).json()
        assert r["course"]["strong"] and r["course"]["semester"] == "Semester I", q
        items = r["course"]["items"]
        assert [i["title"] for i in items] == ["Gandhi Before India", "Missing book"]
        assert items[0]["copies"] == {"CR": 1, "SL": 1} and items[0]["card"]["id"] == 34 and not items[0]["ebook"]
        assert not items[1]["in_catalogue"] and titles(demo.get("/api/search", params={"q": q})) == ["Gandhi Before India"]
    fac = demo.get("/api/search", params={"q": "Asha Rao readings"}).json()["course"]
    assert fac["strong"] and [i["title"] for i in fac["items"]] == ["Mohandas"]
    assert demo.get("/api/search", params={"q": "transportation engineering"}).json()["course"]["strong"] is False
    page = demo.get("/api/courses", params={"code": "ce 404"}).json()
    assert page["label"] == "Semester I" and len(page["items"]) == 2 and "Sushobhan Sen" in page["pickers"]["faculty"]
    assert [s["label"] for s in page["semesters"]] == ["Semester I", "Sample semester"]
    out = demo.get("/api/courses/export", params={"code": "CE 404"})
    assert out.status_code == 200 and "Course Reserve copies" in out.text and "000001, 000002" in out.text
    old = page["semesters"][1]["id"]
    assert demo.get("/api/courses", params={"sem": old, "q": "algorithms"}).json()["items"][0]["code"] == "CS 201"
    demo.post(f"/api/admin/courses/{old}/current", headers=H)
    assert demo.get("/api/search", params={"q": "CS 201"}).json()["course"]["semester"] == "Sample semester"
    bad = demo.post("/api/admin/courses", files={"file": ("x.csv", b"Name,Thing\n1,2\n")}, data={"label": "x"}, headers=H)
    assert bad.status_code == 400 and "Title" in bad.json()["detail"]


def test_ask_the_librarian(tmp_path, monkeypatch):
    with TestClient(fresh_app(tmp_path, DISCOVER_MODE="demo", ANTHROPIC_API_KEY="test", AI_QUERY_PARSING="false", ASK_PER_HOUR="3")) as c:
        import app.ai as ai
        seen = {}

        def fake(history, cands, library):
            seen.update(history=history, cands=cands)
            return {"reply": "Try these.", "picks": [{"id": cands[0]["id"], "why": "Good start."}, {"id": 999999, "why": "made up"}],
                    "try_search": None}
        monkeypatch.setattr(ai, "ask", fake)
        r = c.post("/api/ask", json={"messages": [{"role": "user", "content": "books on gandhi"}]}).json()
        assert r["reply"] == "Try these." and [p["id"] for p in r["picks"]] == [seen["cands"][0]["id"]]  # invented ids dropped
        assert seen["cands"][0]["title"].startswith("Gandhi Before India") and "pid" not in str(seen)
        r = c.post("/api/ask", json={"messages": [{"role": "user", "content": "books on gandhi"}, {"role": "assistant", "content": "Try these."},
                                                  {"role": "user", "content": "anything shorter?"}]}).json()
        assert r["searched"] == "books on gandhi anything shorter?"
        c.post("/api/ask", json={"messages": [{"role": "user", "content": "readings for HS 210"}]})
        assert seen["cands"][0].get("note", "").startswith("HS 210")
        assert c.post("/api/ask", json={"messages": [{"role": "user", "content": "x"}]}).status_code == 429


def test_meaning_model_backend_only_encodes_new_titles(tmp_path, monkeypatch):
    """With sentence-transformers, titles are encoded once; a refresh encodes only new or changed ones."""
    os.environ.update({"DATA_DIR": str(tmp_path), "SEMANTIC": "model"})
    for m in [m for m in sys.modules if m == "app" or m.startswith("app.")]:
        del sys.modules[m]
    import numpy as np
    from app import semantic
    from app.koha import SAMPLE
    calls = []

    class Fake:
        def encode(self, texts, **kw):
            calls.append(len(texts))
            return np.array([[hash(w) % 7 for w in (t + " " * 8)[:8]] for t in texts], dtype=np.float32) + 1

    monkeypatch.setattr(semantic, "backend_wanted", lambda: "model")
    s = semantic.Semantic()
    monkeypatch.setattr(s, "model", lambda: Fake())
    books = {b["id"]: dict(b, au=[b["a"]]) for b in SAMPLE["books"]}
    s.build(books)
    books[1] = dict(books[1], t="Sapiens (new edition)")
    s.build(books)
    assert calls == [len(books), 1]
    s2 = semantic.Semantic()
    monkeypatch.setattr(s2, "model", lambda: Fake())
    assert s2.load() and s2.backend == "model" and len(s2.search("history")) >= 1
    os.environ.pop("SEMANTIC")
